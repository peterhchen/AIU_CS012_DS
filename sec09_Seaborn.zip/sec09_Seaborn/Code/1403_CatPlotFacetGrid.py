import pandas as pd
import seaborn as sb
from matplotlib import pyplot as plt
df = sb.load_dataset('exercise')
sb.catplot(x = "time", y = "pulse", hue = "kind", kind = 'violin', col = "diet", data = df)
plt.show()