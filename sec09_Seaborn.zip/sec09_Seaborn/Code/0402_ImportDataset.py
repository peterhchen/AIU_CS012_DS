# Pandas for managing datasets
import pandas as pd
# Matplotlib for additional customization
from matplotlib import pyplot as plt
# Seaborn for plotting and styling
import seaborn as sb

# Seaborn for plotting and styling
import seaborn as sb
df = sb.load_dataset('tips')
print('df.head:')
print(df.head())
print()

print('sb.get_dataset_names():')
print(sb.get_dataset_names())