import pandas as pd
import seaborn as sb
from matplotlib import pyplot as plt
df = sb.load_dataset('iris')
sb.displot(df['petal_length'], kde=True)
plt.show()