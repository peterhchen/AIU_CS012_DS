1. Intialize git directory
> git init test-project
>>> Intialized empty Git repository in C:/../test-project/.git
2. git config --global init.defaultBranch <name>
> git config --global init.defaultBranch main
3. 6:45/3:26:42
To fo the second command in git, we need to change directory to working directory test-project
rename the branch to new repository.
> cd test-project
> git branch -m main
4. 
> git branch 
>> should be empty.
5. 7:21/3:26:42
> ls 
We will not see anything.
> ls -al
should see .git