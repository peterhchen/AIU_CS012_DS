#!/usr/bin/python

print(u'Hello, world!')
# Hello, world!