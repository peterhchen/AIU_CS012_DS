#!/usr/bin/python
# Print string with backslash n (\n)
# Put extra backslash (\)
print('C:\\nowhere')
# or 
print(r'C:\nowhere')
# C:\nowhere
print(r'C:\\nowhere')
# C:\\nowhere