#!/usr/bin/python

print("abs(-45) : ", abs(-45))
print("abs(100.12) : ", abs(100.12))
# print("abs(119L) : ", abs(119L))   # Error
# https://stackoverflow.com/questions/54358939/how-to-indicate-a-long-integer-in-python
# In Python you don't need to worry with long integers. 
# You only need to declare an integer and forget the memory allocation and 
# if the integer will be short or long.
print("abs(119) : ", abs(119))