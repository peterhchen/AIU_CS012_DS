#!/usr/bin/python
# Pyhton 3 does not have cmp function. We have to define
def cmp (a, b):
    print('a > b:', a > b)
    print('a < b:', a < b)
    return (a > b) - (a < b)

print("cmp(80, 100) : ", cmp(80, 100))
# cmp(80, 100) :  -1
print()
print("cmp(180, 100) : ", cmp(180, 100))
# cmp(180, 100) :  1
print()
print("cmp(-80, 100) : ", cmp(-80, 100))
# cmp(-80, 100) :  -1
print()
print("cmp(80, -100) : ", cmp(80, -100))
# cmp(80, -100) :  1