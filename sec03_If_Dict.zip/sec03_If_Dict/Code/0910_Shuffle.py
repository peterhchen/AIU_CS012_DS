#!/usr/bin/python
import random

list = [20, 16, 10, 5];
random.shuffle(list)
print("Reshuffled list : ",  list)
# Reshuffled list :  [5, 16, 10, 20]
random.shuffle(list)
print("Reshuffled list : ",  list)
# Reshuffled list :  [20, 16, 10, 5]