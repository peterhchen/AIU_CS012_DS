#!/usr/bin/python

aList = [123, 'xyz', 'zara', 'abc'];
print("List : ", aList)
# List :  [123, 'xyz', 'zara', 'abc']
aList.append(2009);
print("Updated List : ", aList)
# Updated List :  [123, 'xyz', 'zara', 'abc', 2009]