#!/usr/bin/python

dict = {['Name']: 'Zara', 'Age': 7}
# Traceback (most recent call last):
#  File "1304_DictKeyProp_b.py", line 3, in <module>
#    dict = {['Name']: 'Zara', 'Age': 7}
# TypeError: unhashable type: 'list'
print("dict['Name']: ", dict['Name'])