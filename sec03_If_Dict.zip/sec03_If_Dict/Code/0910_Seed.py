#!/usr/bin/python
import random

random.seed (10)
print("Random number with seed 10 : ", random.random())
# Random number with seed 10 :  0.5714025946899135

# It will generate same random number
random.seed (10)
print("Random number with seed 10 : ", random.random())
# Random number with seed 10 :  0.5714025946899135

# It will generate same random number
random.seed (10)
print("Random number with seed 10 : ", random.random())
# Random number with seed 10 :  0.5714025946899135