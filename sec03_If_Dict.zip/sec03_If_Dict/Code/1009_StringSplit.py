#!/usr/bin/python

str = "Line1-abcdef \nLine2-abc \nLine4-abcd";
print(str.split())
# split by space (" ") and Newline("\n")
# ['Line1-abcdef', 'Line2-abc', 'Line4-abcd']
print(str.split(' ', 1))
# Split by space (' '), count = 1, only space (' ') is ocunted. 
# ['Line1-abcdef', '\nLine2-abc \nLine4-abcd']