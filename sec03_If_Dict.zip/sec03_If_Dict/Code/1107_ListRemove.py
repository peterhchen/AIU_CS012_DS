#!/usr/bin/python

aList = [123, 'xyz', 'zara', 'abc', 'xyz'];
print("List : ", aList)
# List :  [123, 'xyz', 'zara', 'abc', 'xyz']
aList.remove('xyz');
print("remove xyz => List : ", aList)
# remove xyz => List :  [123, 'zara', 'abc', 'xyz']
aList.remove('abc');
print("remove abc => List : ", aList)
# remove abc => List :  [123, 'zara', 'xyz']