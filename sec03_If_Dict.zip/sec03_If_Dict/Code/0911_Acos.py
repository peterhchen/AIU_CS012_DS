#!/usr/bin/python
import math

print("acos(0.64) : ",  math.acos(0.64))
# acos(0.64) :  0.8762980611683406
print("acos(0) : ",  math.acos(0))
# acos(0) :  1.5707963267948966
# cos (pi /2) = 0 => acos (0) = pi/2 = 3.14 /2 = 1.57 
print("acos(-1) : ",  math.acos(-1))
# acos(-1) :  3.141592653589793
print("acos(1) : ",  math.acos(1))
# acos(1) :  0.0