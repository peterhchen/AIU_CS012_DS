#!/usr/bin/python
import math   # This will import math module

print("math.exp(-45.17) : ", math.exp(-45.17))
# math.exp(-45.17) :  2.4150062132629406e-20

print("math.exp(100.12) : ", math.exp(100.12))
# math.exp(100.12) :  3.0308436140742566e+43

print("math.exp(100.72) : ", math.exp(100.72))
# math.exp(100.72) :  5.522557130248187e+43

# print("math.exp(119L) : ", math.exp(119L))
print("math.exp(119) : ", math.exp(119))
# math.exp(119) :  4.797813327299302e+51

print("math.exp(math.pi) : ", math.exp(math.pi))
# math.exp(math.pi) :  23.140692632779267