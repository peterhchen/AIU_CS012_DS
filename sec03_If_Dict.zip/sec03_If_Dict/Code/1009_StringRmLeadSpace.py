#!/usr/bin/python

# Remove Leading space
str = "     this is string example....wow!!!     ";
print(str)
#      this is string example....wow!!![SAPCE ]
print(str.lstrip())
#this is string example....wow!!!
str = "88888888this is string example....wow!!!8888888";
print(str.lstrip('8'))
# this is string example....wow!!!8888888

# Remove sapces reverse (end) of string.
str = "     this is string example....wow!!!     ";
print(str.rstrip())
#      this is string example....wow!!![SPACE is removed]
str = "88888888this is string example....wow!!!8888888";
print(str.rstrip('8'))
# 88888888this is string example....wow!!!