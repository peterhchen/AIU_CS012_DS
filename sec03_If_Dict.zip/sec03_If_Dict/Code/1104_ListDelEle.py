#!/usr/bin/python

list1 = ['physics', 'chemistry', 1997, 2000];
print(list1)
# ['physics', 'chemistry', 1997, 2000]
del list1[2];
print("After deleting value at index 2 : ")
print(list1)
# After deleting value at index 2 :
# ['physics', 'chemistry', 2000]