#!/usr/bin/python

str = "this is string example....wow!!!"
print("str.center(40, 'a') : ", str.center(40, 'a'))
# str.center(40, 'a') :  aaaathis is string example....wow!!!aaaa