# Zip Loop Examle:
numbers = [1, 2, 3]
letters = ['a', 'b', 'c']
zipped = zip(numbers, letters)
print('zipped:')
print(zipped)
print()
# zipped:
# <zip object at 0x0000020DBB82F888>

print('type(zipped):')
print(type(zipped))
print()
# type(zipped):
# <class 'zip'>

print('list(zipped):')
print(list(zipped))
print()
# list(zipped):
[(1, 'a'), (2, 'b'), (3, 'c')]

for x, y in zip(numbers, letters):
    print('x:', x, 'y:', y)
# x: 1 y: a
# x: 2 y: b
# x: 3 y: c