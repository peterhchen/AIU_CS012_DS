#!/usr/bin/python

str = "this is string example....wow!!!";
print("str.capitalize() : ", str.capitalize())
# str.capitalize() :  This is string example....wow!!!