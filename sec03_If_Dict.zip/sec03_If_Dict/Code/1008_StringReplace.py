#!/usr/bin/python

str = "this is string example....wow!!! this is really string"
print(str.replace("is", "was"))
# thwas was string example....wow!!! thwas was really string
print(str.replace("is", "was", 3))
# thwas was string example....wow!!! thwas is really string