#!/usr/bin/python

dict = {'Name': 'Zara', 'Age': 7}
print("Keys : %s" %  dict.keys())
# keys : dict_keys(['Name', 'Age'])
for key in dict.keys():
    print('key:', key)
# key: Name
# key: Age