#!/usr/bin/python

Str = "German ß, ♬; this is string example....wow!!!";
# Str = "this is string example....wow!!!";
Str = Str.encode(encoding='UTF-8', errors='strict')

print("Encoded String: ", Str)
# Encoded String:  b'German \xc3\x9f, \xe2\x99\xac; this is string example....wow!!!'
print("Decoded String: ", Str.decode(encoding='UTF-8', errors='strict'))
# Decoded String:  German ß, ♬; this is string example....wow!!!