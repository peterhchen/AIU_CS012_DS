#!/usr/bin/python
import math   # This will import math module

print("math.ceil(-45.17) : ", math.ceil(-45.17))
# math.ceil(-45.17) :  -45
print("math.ceil(100.12) : ", math.ceil(100.12))
# math.ceil(100.12) :  101
print("math.ceil(100.72) : ", math.ceil(100.72))
# math.ceil(100.72) :  101
# print("math.ceil(119L) : ", math.ceil(119L))
print("math.ceil(119) : ", math.ceil(119))
# math.ceil(119) :  119
print("math.ceil(math.pi) : ", math.ceil(math.pi))
# math.ceil(math.pi) :  4