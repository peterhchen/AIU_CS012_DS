#!/usr/bin/python

dict = {'Name': 'Zara', 'Age': 7, 'Class': 'First'}
print("dict['Name']: ", dict['Name'])
# dict['Name']:  Zara
print("dict['Age']: ", dict['Age'])
# dict['Age']:  7