integers = [1, 2, 3]
letters = ['a', 'b', 'c']
floats = [4.0, 5.0, 6.0]
# Three input iterables
zipped = zip(integers, letters, floats)  
print('list(zipped):')
print(list(zipped))