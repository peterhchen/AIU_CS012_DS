#!/usr/bin/python

var1 = 'Hello World!'
var2 = var1[:6] + 'Python'
# var2 = "Hello " + 'Python'
print("Updated String :", var2)
# Updated String : Hello Python