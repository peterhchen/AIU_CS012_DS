#!/usr/bin/python

dict = {'Name': 'Zara', 'Age': 7}
print("Values : %s" %  dict.values())
# Values : dict_values(['Zara', 7])

for val in dict.values():
    print('val:', val)
# val: Zara
# val: 7