#!/usr/bin/python

dict = {'Name': 'Zara', 'Age': 7, 'Class': 'First'}
del dict['Name']; # remove entry with key 'Name'
dict.clear();     # remove all entries in dict
del dict;        # delete entire dictionary

print("dict['Age']: ", dict['Age'])
# Traceback (most recent call last):
#  File "1303_DictDel.py", line 8, in <module>
#    print("dict['Age']: ", dict['Age'])
#TypeError: 'type' object is not subscriptable
print("dict['School']: ", dict['School'])