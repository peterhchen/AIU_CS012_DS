# Import math Library
import math

# Print the value of pi
print('math.pi:', math.pi)
# math.pi: 3.141592653589793

# Print the value of pi
print('math.e:', math.e)
# math.e: 2.718281828459045
