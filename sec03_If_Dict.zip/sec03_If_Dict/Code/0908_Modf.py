#!/usr/bin/python
import math   # This will import math module

print("math.modf(100.12) : ", math.modf(100.12))
# math.modf(100.12) :  (0.12000000000000455, 100.0)

print("math.modf(100.72) : ", math.modf(100.72))
# math.modf(100.72) :  (0.7199999999999989, 100.0)

# print "math.modf(119L) : ", math.modf(119L)
print("math.modf(119) : ", math.modf(119))
# math.modf(119) :  (0.0, 119.0)

print("math.modf(math.pi) : ", math.modf(math.pi))
# math.modf(math.pi) :  (0.14159265358979312, 3.0)