#!/usr/bin/python
import math   # This will import math module

print("math.fabs(-45.17) : ", math.fabs(-45.17))
# math.fabs(-45.17) :  45.17

print("math.fabs(100.12) : ", math.fabs(100.12))
print("math.fabs(100.72) : ", math.fabs(100.72))
# math.fabs(100.12) :  100.12

# print "math.fabs(119L) : ", math.fabs(119L)
print("math.fabs(119) : ", math.fabs(119))
# math.fabs(119) :  119.0

print("math.fabs(math.pi) : ", math.fabs(math.pi))
# math.fabs(math.pi) :  3.141592653589793