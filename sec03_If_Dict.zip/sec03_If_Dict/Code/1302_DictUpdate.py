#!/usr/bin/python

dict = {'Name': 'Zara', 'Age': 7, 'Class': 'First'}
dict['Age'] = 8; # update existing entry
dict['School'] = "SVU"; # Add new entry

print("dict['Age']: ", dict['Age'])
# dict['Age']:  8
print("dict['School']: ", dict['School'])
# dict['School']:  SVU