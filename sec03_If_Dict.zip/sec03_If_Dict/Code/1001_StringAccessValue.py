#!/usr/bin/python

var1 = 'Hello World!'
var2 = "Python Programming"

print("var1[0]: ", var1[0])
# var1[0]:  H
print("var2[1:5]: ", var2[1:5])
# var2[1:5]:  ytho