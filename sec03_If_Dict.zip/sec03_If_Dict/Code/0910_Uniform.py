#!/usr/bin/python
import random

print("Random Float uniform(5, 10) : ",  random.uniform(5, 10))
# Random Float uniform(5, 10) :  6.99401787823527
# Return a random number between (5, 10)
print("Random Float uniform(7, 14) : ",  random.uniform(7, 14))
# Random Float uniform(7, 14) :  12.839364356374158
# Return a random number between (7, 14)