#!/usr/bin/python

# We assign key "Name" to "Zara"
# Then reassign key "Name" to "Manni".
dict = {'Name': 'Zara', 'Age': 7, 'Name': 'Manni'}

print("dict['Name']: ", dict['Name'])
# dict['Name']:  Manni
# Finame key "name" is "Manni"