def convert(list):
    return tuple(list)
  
# Driver function
list = [1, 2, 3, 4]
print(convert(list))
# (1, 2, 3, 4)