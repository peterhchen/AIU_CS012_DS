total_sales = [10100.00, 20200.00, 30300.00]
prod_cost = [100.00, 200.00, 300.00]
for sales, costs in zip(total_sales, prod_cost):
    profit = sales - costs
    print(f'   Profit: { profit }')