#!/usr/bin/python

dict = {'Name': 'Zara', 'Age': 7};
print("Length : %d" % len (dict))
# Length : 2