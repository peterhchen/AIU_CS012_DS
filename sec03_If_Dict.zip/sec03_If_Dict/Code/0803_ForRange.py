#!/usr/bin/python
"""
File Name: For Range
"""

FRUITS = ['banana', 'apple', 'mango']
# for index in range(len(FRUITS)):
for index, _ in enumerate(FRUITS):
    print('index:', index)
    print('Current fruit :', FRUITS[index])
    # print('ele:', ele)

print("Good bye!")
