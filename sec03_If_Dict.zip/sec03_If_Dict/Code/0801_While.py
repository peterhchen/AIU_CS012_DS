#!/usr/bin/python

count = 0
while (count < 9):
   print('The count is:', count)
   count = count + 1

print("Good bye!")