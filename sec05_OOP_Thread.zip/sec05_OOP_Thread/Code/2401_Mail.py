#!/usr/bin/python

import smtplib

sender = 'peter.hp.chen@gmail.com'
receivers = ['peter.hp.chen@gmail.com']

message = """From: From Person <peter.hp.chen@gmail.com>
To: To Person <peter.hp.chen@gmail.com>
Subject: SMTP e-mail test

This is a test e-mail message.
"""

try:
   smtpObj = smtplib.SMTP('localhost')
   smtpObj.sendmail(sender, receivers, message)         
   print("Successfully sent email")
except SMTPException:
   print("Error: unable to send email")