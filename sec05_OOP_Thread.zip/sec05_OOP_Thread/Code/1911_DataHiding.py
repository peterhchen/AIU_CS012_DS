#!/usr/bin/python

class JustCounter:
   __secretCount = 0
  
   def count(self):
      self.__secretCount += 1
      print('self.__secretCount:', self.__secretCount)

print('1. counter = JustCounter():')
counter = JustCounter()
# Replace object._className__attrName.
print('counter._JustCounter__secretCount:', counter._JustCounter__secretCount)
# 1. counter = JustCounter():
# counter._JustCounter__secretCount: 0
print('2. counter.count():')
counter.count()
# 2. counter.count():
# self.__secretCount: 1
print('3. counter.count():')
counter.count()
# 3. counter.count():
# self.__secretCount: 2
print('4. counter.count():')
counter.count()
# 4. counter.count():
# self.__secretCount: 3
# print(5. counter.__secretCount:', counter.__secretCount)
print('5. counter._JustCounter__secretCount:', counter._JustCounter__secretCount)
# 5. counter._JustCounter__secretCount: 3