def myFunc():
  print("Hello, World!")

myFunc()
# Hello, World!