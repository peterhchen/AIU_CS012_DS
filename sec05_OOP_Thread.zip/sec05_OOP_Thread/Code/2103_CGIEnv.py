#!/usr/bin/python

import os

print("Content-type: text/html\r\n\r\n")
print("<font size=+1>Environment</font><\br>")
for param in os.environ.keys():
   print("<b>%20s</b>: %s<\br>" % (param, os.environ[param]))
# Content-type: text/html
#
#
#<font size=+1>Environment</font>r>
#<b>     ALLUSERSPROFILE</b>: C:\ProgramDatar>
#<b>       ANACONDA_HOME</b>: C:\Tools\Anaconda3r>
#<b>            ANT_HOME</b>: C:\Tools\apache-ant-1.10.5r>
#<b>             APPDATA</b>: C:\Users\14088\AppData\Roamingr>
#<b>          BOOST_ROOT</b>: C:\Program Files\boost\boost_1_65_0r>
#<b>   CHOCOLATEYINSTALL</b>: C:\ProgramData\chocolateyr>
#<b>CHOCOLATEYLASTPATHUPDATE</b>: 132651474148293147r>
# ...
# <b>USERDOMAIN_ROAMINGPROFILE</b>: LAPTOP-N568KP11r>
#<b>            USERNAME</b>: 14088r>
#<b>         USERPROFILE</b>: C:\Users\14088r>
#<b>VBOX_MSI_INSTALL_PATH</b>: C:\Program Files\Oracle\VirtualBox\r>
#<b>             VB_HOME</b>: C:\Program Files\Oracle\VirtualBoxr>
#<b>            VIM_HOME</b>: C:\Tools\Vim\vim81r>
#<b>   VS160COMCOMNTOOLS</b>: C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\Tools\r>
#<b>              WINDIR</b>: C:\WINDOWSr>