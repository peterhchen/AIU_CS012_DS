#!/usr/bin/python
# In python 3, thread is change to _thread.
import _thread
import time

# Define a function for the thread
def print_time(threadName, delay):
    count = 0
    while count < 2:
      time.sleep(delay)
      count += 1
      print('count:', count)
      print("%s: %s" % (threadName, time.ctime(time.time())))
 
# Create two threads as follows
try:
   _thread.start_new_thread (print_time, ("Thread-1", 2,) )
   _thread.start_new_thread (print_time, ("Thread-2", 4,) )
except:
   print("Error: unable to start thread")

while 1:
   pass

# count: 1
# Thread-1: Mon May 23 12:30:05 2022
# count: 1
# Thread-2: Mon May 23 12:30:07 2022
# count: 2
# Thread-1: Mon May 23 12:30:07 2022
# count: 2
# Thread-2: Mon May 23 12:30:11 2022