def myWrapper(func):
  def myInnerFunc():
    print("Inside wrapper.")
    func()
  return myInnerFunc
 
def myFunc():
  print("Hello, World!")

c=myWrapper(myFunc)
c()
# Inside wrapper.
# Hello, World!