def decorateFun(func): 
    def sumOfSquare(x, y): 
        print('Inside Wrapper')
        return func(x**2, y**2) 
    return sumOfSquare 

@decorateFun
def addTwoNumbers(a, b): 
    print('c = a + b')
    c = a + b 
    return c 

c = addTwoNumbers(4,5) 
print("Addition of two numbers=", c)
# Inside Wrapper
# c = a + b
# Addition of two numbers= 41