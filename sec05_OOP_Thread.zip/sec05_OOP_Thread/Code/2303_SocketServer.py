import socket

def server_program():
    # get the hostname
    host = socket.gethostname()
    port = 5000  # initiate port no above 1024
    print('host:', host)
    print('port:', port)
    print('server_socket = socket.socket():')
    server_socket = socket.socket()  # get instance
    print('server_socket:', server_socket)
    # look closely. The bind() function takes tuple as argument
    print('server_socket.bind((', host, ',', port, '):')
    server_socket.bind((host, port))  # bind host address and port together
    # configure how many client the server can listen simultaneously
    print('server_socket.listen(2):')
    server_socket.listen(2)
    print('conn, address = server_socket.accept()')
    conn, address = server_socket.accept()  # accept new connection
    print('conn:', conn)
    print('address:', address)
    print("Connection from: " + str(address))
    while True:
        # receive data stream. it won't accept data packet greater than 1024 bytes
        print('data = conn.recv(1024).decode():')
        data = conn.recv(1024).decode()
        print('data:', data)
        # when client type "bye" or "exit", then the server will be closed.
        if not data or data == "exit":
            # if data is not received break
            break
        print("from connected user: " + str(data))
        data = input(' -> ')
        print('conn.send(data.encode()):')
        conn.send(data.encode())  # send data to the client

    conn.close()  # close the connection

if __name__ == '__main__':
    server_program()