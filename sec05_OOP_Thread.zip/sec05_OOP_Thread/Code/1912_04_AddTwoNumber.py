def addTwoNumbers(a, b):
    c=a+b
    return c

c=addTwoNumbers(4, 5)
 
print("Addition of two numbers=", c)
# Addition of two numbers= 9