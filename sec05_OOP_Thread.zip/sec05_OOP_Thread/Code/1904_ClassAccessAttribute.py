class Employee:
   """
   Description: Common base class for all employees
   """
   _empCount = 0

   def __init__(self, name, salary):
      self.name = name
      self.salary = salary
      Employee._empCount += 1
   
   def _displayCount(self):
      print("Total Employee %d" % Employee._empCount)

   def _displayEmployee(self):
      print("Name: ", self.name,  ", Salary: ", self.salary)

"Create first object of Employee class..."
emp1 = Employee("Zara", 2000)
"Create second object of Employee class..."
emp2 = Employee("Manni", 5000)
emp1._displayEmployee()
emp2._displayEmployee()
emp1._displayCount()
# print("Total Employee %d" % Employee._empCount)
# Name :  Zara , Salary:  2000
# Name :  Manni , Salary:  5000
# Total Employee 2