#!/usr/bin/python
import re

phone = "2004-959-559 # This is Phone Number"

# Delete Python-style comments
# Comment start with # and .* (any characters) to the end ('$').
# Replace to empy ("").
num = re.sub(r'#.*$', "", phone)
print("Phone Num:", num)
# Phone Num: 2004-959-559

# Remove anything other than digits
# '\d' means digit
# '\D' mean non-digit.
num = re.sub(r'\D', "", phone)    
print("Phone Num:", num)
# Phone Num: 2004959559