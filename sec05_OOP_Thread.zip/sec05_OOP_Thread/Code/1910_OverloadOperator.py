#!/usr/bin/python

class Vector:
    def __init__(self, a, b):
        print('__init__(a, b):', a, b)
        self.a = a
        self.b = b

    def __str__(self):
        print('__str__:')
        return 'Vector (%d, %d)' % (self.a, self.b)
   
    def __add__(self, other):
        print ("__add__(self, other): ", other)
        return Vector(self.a + other.a, self.b + other.b)
print ('v1 = Vector(2, 10)')
v1 = Vector(2, 10)
# v1 = Vector(2, 10)
# __init__(a, b): 2 10
print ('v2 = Vector(5, -2)')
v2 = Vector(5, -2)
# v2 = Vector(5, -2)
# __init__(a, b): 5 -2
print('v1 + v2:')
print(v1 + v2)
# v1 + v2:
# __add__(self, other):  __str__:
# Vector (5, -2)
# __init__(a, b): 7 8
# __str__:
# Vector (7, 8)