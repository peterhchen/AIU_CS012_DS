class Box:
    pass
box = Box()
box.sides = 6

#a) NG box2 has no sides
# box2 = Box()
# print (box2.sides)

#d) will crash
box2 = Box()
print (box2.sides)
