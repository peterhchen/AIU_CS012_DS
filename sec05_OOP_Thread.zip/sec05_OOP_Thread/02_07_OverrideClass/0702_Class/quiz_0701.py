class Cloud(object):
    pass

cloud = Cloud()
the_cloud_string = "%s" % (cloud)