import numpy as np 
a = np.array([[0.0,0.0,0.0],[10.0,10.0,10.0],[20.0,20.0,20.0],[30.0,30.0,30.0]]) 
b = np.array([0., 1.0, 2.0])  
   
print('a =') 
print(a)
print('a.shape =', a.shape)
# a =
# [[ 0.  0.  0.]
#  [10. 10. 10.]
#  [20. 20. 20.]
#  [30. 30. 30.]]
# a.shape = (4, 3) 
   
print('b =', b)   
print('b.shape =', b.shape)
# b = [0. 1. 2.]
# b.shape = (3,)
# Array is broadcasting to the same as arrary a   
print('a + b =')
print(a + b)
# a + b =
#[[ 0.  1.  2.]
# [10. 11. 12.]
# [20. 21. 22.]
# [30. 31. 32.]]