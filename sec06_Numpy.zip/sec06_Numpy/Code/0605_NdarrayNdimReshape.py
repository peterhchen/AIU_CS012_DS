# this is one dimensional array 
import numpy as np 
a = np.arange(24)
print('a:')
print(a)
print('a.ndim:')
print(a.ndim) 

# now reshape it 
b = a.reshape(2,4,3)
print('a.reshape(2, 4, 3):') 
print(b)
# b is having three dimensions