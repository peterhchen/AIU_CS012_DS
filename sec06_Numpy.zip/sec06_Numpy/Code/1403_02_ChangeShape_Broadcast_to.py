import numpy as np 
a = np.arange(4).reshape(1,4) 
print('a = np.arange(4).reshape(1,4) => a:')
print(a) 
# a = np.arange(4).reshape(1,4) => a:
# [[0 1 2 3]]
print("np.broadcast_to(a,(4,4)):")
print(np.broadcast_to(a,(4,4)))
#np.broadcast_to(a,(4,4)):
#[[0 1 2 3]
# [0 1 2 3]
# [0 1 2 3]
# [0 1 2 3]]