# It creates 3 dimensional ndarray 
import numpy as np 
a = np.arange(4).reshape(2, 2) 
print('The original array:') 
print('a:')
print(a) 
#The original array:
# a:
#[[0 1]
# [2 3]]
print('To roll axis-1 to axis-0 (along horizontal to along vertical):') 
print('After applying rollaxis function:')
print('np.rollaxis(a, 1):') 
print(np.rollaxis(a, 1))
#To roll axis-1 to axis-0 (along horizontal to along vertical):
#After applying rollaxis function:
#np.rollaxis(a, 1):
#[[0 2]
# [1 3]]
