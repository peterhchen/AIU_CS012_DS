import numpy as np 
a = np.array([1, 255, 256, 8755], dtype = np.int16) 
print('a:', a)
# a: [   1  255  256 8755]
print('Representation of data in memory in hexadecimal form:')
print('list(map(hex, a)):')
print(list(map(hex, a)))
print()
# Representation of data in memory in hexadecimal form:
# list(map(hex, a)):
# ['0x1', '0xff', '0x100', '0x2233']

# byteswap() function swaps in place by passing True parameter 
print('Applying byteswap() function:') 
print('a.byteswap(inplace=True):')
print(a.byteswap(inplace=True))
print()
# Applying byteswap() function:
# a.byteswap(inplace=True):
# [  256  -256     1 13090]

# We can see the bytes being swapped
print('In hexadecimal form:')
print('list(map(hex, a)):') 
print(list(map(hex, a)))
print() 
#In hexadecimal form:
# list(map(hex, a)):
# ['0x100', '-0x100', '0x1', '0x3322']