import numpy as np 
a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 
print('a:')
print(a)
print()  
#a:
#[[1 2 3]
# [3 4 5]
# [4 5 6]]
print('np.mean(a):', np.mean(a)) 
print()
# (1+ 2+ 3+ ...+ 4 + 5 + 6)/9 = 3.66
# np.mean(a): 3.6666666666666665

print('np.mean(a, axis = 0):')
print(np.mean(a, axis = 0))
print() 
# np.mean(a, axis = 0)
# aix = 0 => veriticaly:
# 1) (1+3+4)/3 = 2.66
# 2) (2+4+5)/3 = 3.66
# 3) (3+5+6)/3 = 4.66
#[2.66666667 3.66666667 4.66666667]
print('np.mean(a, axis = 1):') 
print(np.mean(a, axis = 1))
#np.mean(a, axis = 1):
# axix = 1 => Horizontally:
# (1+2+3)/3 = 2
# (3+4+5)/3 = 4
# (4+5+6)/3 = 5
#[2. 4. 5.]