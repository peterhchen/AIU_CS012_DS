import numpy as np 
first_name = \
    ('Jerry', 'Peter', 'Irene', 'Jessica', 'Jason', 
    'Jasmine', 'Jonathn', 'Gong', 'Simon')
last_name = \
    ('Shiao','Chen','Chen', 'Chen', 'Chen', 
    'Chen', 'Chen', 'Lei','Au')
# The last column "last_name" is the primary keys 
ind = np.lexsort((first_name, last_name)) 

print('ind = np.lexsort((first_name, last_name)) => ind:')
print(ind)
print()
# ind = np.lexsort((first_name, last_name)) => ind:
# [3 1 2 0]

print('Use this index to get sorted data:')
print([last_name[i] + ", " +first_name[i] for i in ind]) 
# Use this index to get sorted data:
# ['Au, Simon', 'Chen, Peter', 'Lei, Gong', 'Shiao, Jerry']