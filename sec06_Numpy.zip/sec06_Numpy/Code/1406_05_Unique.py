import numpy as np 
a = np.array([5,2,6,2,7,5,6,8,2,9]) 
print ('a:')
print(a)  
#a:
#[5 2 6 2 7 5 6 8 2 9]

print('Unique values of array a:') 
u = np.unique(a)
print('u = np.unique(a):')
print(u)
# Unique values of array a:
# u = np.unique(a):
# [2 5 6 7 8 9]

print('Unique array and Indices array:') 
print('We can see each number corresponds to index in original array:') 
u, indices = np.unique(a, return_index = True) 
print('u,indices = np.unique(a, return_index = True):')
print('indices:', indices)  
# Unique array and Indices array:
# We can see each number corresponds to index in original array:
# u,indices = np.unique(a, return_index = True):
# indices: [1 0 2 4 7 9]

print('Indices of unique array:') 
u, indices = np.unique(a, return_inverse = True) 
print('u,indices = np.unique(a,return_inverse = True):')
print('u:')
print(u) 
print('indices:')
print(indices) 
#Indices of unique array:
#u,indices = np.unique(a,return_inverse = True):
#u:
#[2 5 6 7 8 9]
#indices:
#[1 0 2 0 3 1 2 4 0 5] 

print('Reconstruct the original array using indices:')
print('u[indices]:') 
print(u[indices])   
#Reconstruct the original array using indices:
#u[indices]:
#[5 2 6 2 7 5 6 8 2 9]
print('Return the count of repetitions of unique elements:') 
u, indices = np.unique(a, return_counts = True)
print('u, indices = np.unique(a, return_counts = True):')
print(u) 
print(indices)
# Return the count of repetitions of unique elements:
# u, indices = np.unique(a, return_counts = True):
# [2 5 6 7 8 9]
# [3 2 2 1 1 1]