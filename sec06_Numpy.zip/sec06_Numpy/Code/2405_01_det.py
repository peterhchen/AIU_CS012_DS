import numpy as np
a = np.array([[1,2], [3,4]])
print('a:')
print(a)
print('np.linalg.det(a):')
print(np.linalg.det(a))
# a:
#[[1 2]
# [3 4]]
#np.linalg.det(a):
# [a b]
# [c d]
# a x d - b x c
# 1 x 4 - 2 x 3 = 4 - 6 = -2
#-2.0000000000000004