import numpy.matlib 
import numpy as np 

a = np.array([[1,2],[3,4]])
b = np.array([[11,12],[13,14]])
print('a:')
print(a)
print()
#a:
#[[1 2]
# [3 4]]

print('b:')
print(b)
print()
#b:
#[[11 12]
# [13 14]]

print('np.dot(a, b):')
print(np.dot(a, b))
# dot result: 
# [[1 * 11 + 2 * 13, 1 * 12 + 2 * 14], 
# [ 3 * 11 + 4 * 13, 3 * 12 + 4 * 14]]
#np.dot(a, b):
#[[37 40]
# [85 92]]