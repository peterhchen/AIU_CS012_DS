import numpy as np 
a = np.array([0,30,45,60,90]) 
print('a', a)
print()
# a [ 0 30 45 60 90]

print('Array containing sine values:') 
sin = np.sin(a*np.pi/180) 
print(sin)
print()
#Array containing sine values:
#[0.         0.5        0.70710678 0.8660254  1.        ]

print('Compute sine inverse of angles. Returned values are in radians.') 
inv = np.arcsin(sin) 
print(inv) 
print()
# Compute sine inverse of angles. Returned values are in radians.
# [0.         0.52359878 0.78539816 1.04719755 1.57079633] 

print('Check result by converting to degrees:') 
print(np.degrees(inv))
print()
# Check result by converting to degrees:
# [ 0. 30. 45. 60. 90.]

print('arccos and arctan functions behave similarly:') 
cos = np.cos(a*np.pi/180) 
print(cos) 
print()
# arccos and arctan functions behave similarly:
# [1.00000000e+00 8.66025404e-01 7.07106781e-01 5.00000000e-01
#  6.12323400e-17]

print('Inverse of cos:') 
inv = np.arccos(cos) 
print(inv) 
print()  
# Inverse of cos:
# [0.         0.52359878 0.78539816 1.04719755 1.57079633]

print('In degrees:') 
print(np.degrees(inv)) 
print()
# In degrees:
# [ 0. 30. 45. 60. 90.]

print('Tan function:') 
tan = np.tan(a*np.pi/180) 
print(tan)
print()  
# Tan function:
# [0.00000000e+00 5.77350269e-01 1.00000000e+00 1.73205081e+00
#  1.63312394e+16]

print('Inverse of tan:') 
inv = np.arctan(tan) 
print(inv) 
print()  
# Inverse of tan:
# [0.         0.52359878 0.78539816 1.04719755 1.57079633]

print('In degrees:')
print(np.degrees(inv))
# In degrees:
# [ 0. 30. 45. 60. 90.]