import numpy as np 
a = np.arange(8).reshape(2,4) 

print('The original array is:') 
print('a:')
print(a)   
# The original array is:
# a:
# [[0 1 2 3]
# [4 5 6 7]]

print('After applying ravel function:')
print('a.ravle():') 
print(a.ravel())  
# After applying ravel function:
# a.ravle():
# [0 1 2 3 4 5 6 7]

print('Applying ravel function in F-style ordering:')
print("a.ravel(order = 'F'):")
print(a.ravel(order = 'F'))
# Applying ravel function in F-style ordering:
# a.ravel(order = 'F'):
# [0 4 1 5 2 6 3 7]