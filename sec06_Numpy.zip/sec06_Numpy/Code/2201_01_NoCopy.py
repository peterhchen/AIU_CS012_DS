import numpy as np 
a = np.arange(6) 
print ('a:', a)
print('Applying id() function:')
print('id(a):', id(a))  
print()
#a: [0 1 2 3 4 5]
#Applying id() function:
#id(a): 2464734393424

print('a is assigned to b:')
b = a 
print('b:', b)  
print()
# a is assigned to b:
#b: [0 1 2 3 4 5]

print('b has same id():')
print('id:', id(b))  
print()
# b has same id():
# id: 2464734393424

print('Change shape of b:') 
b.shape = 3,2
print('b:')
print(b)
print('b has same id():')
print('id:', id(b))
print() 
# Change shape of b:
#b:
#[[0 1]
# [2 3]
# [4 5]]
#b has same id():
#id: 1162617652784
 
print('Shape of a also gets changed:') 
print('a:')
print(a)
print('a has same id():')
print('id:', id(a))
#Shape of a also gets changed:
#a:
#[[0 1]
# [2 3]
# [4 5]]
#a has same id():
#id: 1162617652784