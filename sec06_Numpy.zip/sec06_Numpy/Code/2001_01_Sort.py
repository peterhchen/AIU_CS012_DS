import numpy as np  
a = np.array([[3,7],[9,1]]) 
print('a:')
print(a)
print('1) Deafult sort is alogn the array.')
print('2) Deafult algorithm is quicksort => np.sort(a):') 
print(np.sort(a)) 
print()
#a:
#[[3 7]
# [9 1]]
#1) Deafult sort is along the array.
#2) Deafult algorithm is quicksort => np.sort(a):
#[[3 7]
# [1 9]]

print('a:')
print(a)
print('np.sort(a, axis = 0):')
print(np.sort(a, axis = 0))
print()
#a:
#[[3 7]
# [9 1]]
# np.sort(a, axis = 0):
#[[3 1]
# [9 7]]

# Order parameter in sort function 
dt = np.dtype([('name', 'S10'), ('age', int)]) 
a = np.array([("raju",21),("anil",25),("ravi", 17), ("amar",27)], dtype = dt) 
print('a:')
print(a)
print("Order by name =>np.sort(a, order = 'name'):") 
print(np.sort(a, order = 'name'))
#a:
#[(b'raju', 21) (b'anil', 25) (b'ravi', 17) (b'amar', 27)]
#Order by name =>np.sort(a, order = 'name'):
#[(b'amar', 27) (b'anil', 25) (b'raju', 21) (b'ravi', 17)]