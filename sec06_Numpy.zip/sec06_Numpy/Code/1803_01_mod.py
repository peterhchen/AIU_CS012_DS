import numpy as np 
a = np.array([10,20,30]) 
b = np.array([3,5,7]) 

print('a:', a)
print('b:', b) 
print()  
#a: [10 20 30]
#b: [3 5 7]

print('np.mod(a,b):')
print(np.mod(a,b))
print()
#np.mod(a,b):
#[1 0 2]

print('np.remainder(a,b):')
print(np.remainder(a,b))
#np.remainder(a,b):
#[1 0 2]