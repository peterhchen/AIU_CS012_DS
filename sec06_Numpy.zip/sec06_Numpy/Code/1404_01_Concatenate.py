import numpy as np 
a = np.array([[1,2],[3,4]]) 
print('a:')
print(a) 
b = np.array([[5,6],[7,8]]) 
print('b:')
print(b)
# a:
#[[1 2]
# [3 4]]
#b:
#[[5 6]
# [7 8]]

# both the arrays are of same dimensions 
print('Joining the two arrays along axis 0:') 
print('np.concatenate((a,b)):') 
print(np.concatenate((a,b))) 
# Joining the two arrays along axis 0:
#np.concatenate((a,b)):
#[[1 2]
# [3 4]
# [5 6]
# [7 8]]
print('Joining the two arrays along axis 1:') 
print('np.concatenate((a,b),axis = 1):')
print(np.concatenate((a,b),axis = 1))
# Joining the two arrays along axis 1:
# np.concatenate((a,b),axis = 1):
#[[1 2 5 6]
# [3 4 7 8]]