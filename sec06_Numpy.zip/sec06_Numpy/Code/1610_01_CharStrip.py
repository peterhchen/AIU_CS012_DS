import numpy as np 
print(np.char.strip('San Jose, California','a'))
print(np.char.strip(['arora','admin','java'],'a'))
#San Jose, Californi
#['ror' 'dmin' 'jav']