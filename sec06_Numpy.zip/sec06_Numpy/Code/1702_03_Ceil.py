import numpy as np 
a = np.array([-1.7, 1.5, -0.2, 0.6, 10]) 

print('a:', a)
print()
# a: [-1.7  1.5 -0.2  0.6 10. ]

print('np.ceil(a):')
print(np.ceil(a))
# np.ceil(a):
# [-1.  2. -0.  1. 10.]