import numpy as np 
a = np.array([10,100,1000]) 

print('a:', a)
print()
# a: [  10  100 1000]
print('np.power(a,2):')
print(np.power(a,2))
print()
# np.power(a,2):
# [    100   10000 1000000] 

print('a:', a)
b = np.array([1,2,3]) 
print('b:', b)
print()
# a: [  10  100 1000]
# b: [1 2 3]
print('np.power(a,b):')
print(np.power(a,b))
#np.power(a,b):
#[        10      10000 1000000000]