import numpy as np 
print(np.char.replace ('He is a good boy', 'is', 'was'))
# He was a good boy