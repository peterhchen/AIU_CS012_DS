import numpy as np 
x = np.zeros((5), dtype = int) 
print('x:', x)
# np.int is decprecated, use int instead
# x: [0 0 0 0 0]