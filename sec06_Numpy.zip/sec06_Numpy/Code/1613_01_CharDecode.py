import numpy as np 

a = np.char.encode('string to be encode', 'cp500') 
print(a) 
# b'\xa2\xa3\x99\x89\x95\x87@\xa3\x96@\x82\x85@\x85\x95\x83\x96\x84\x85'
print(np.char.decode(a,'cp500'))
# string to be encode