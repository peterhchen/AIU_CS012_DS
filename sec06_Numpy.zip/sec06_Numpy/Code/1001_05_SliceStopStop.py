# slice items between indexes 
import numpy as np 
a = np.arange(10) 
print('a:', a)
# a: [0 1 2 3 4 5 6 7 8 9]
print('a[2:5] =', a[2:5])
# start at index = 2, stop at befofe index = 5 (open bracket)
#a[2:5] = [2 3 4]