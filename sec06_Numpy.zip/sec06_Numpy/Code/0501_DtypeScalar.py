# using array-scalar type 
import numpy as np 
dt = np.dtype(np.int32)
print('dt:')
print(dt)