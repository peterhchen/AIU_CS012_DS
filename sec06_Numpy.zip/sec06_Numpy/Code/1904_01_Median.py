import numpy as np 
a = np.array([[30,65,70],[80,95,10],[50,90,60]]) 
print('a:')
print(a)
print()
#a:
#[[30 65 70]
# [80 95 10]
# [50 90 60]]

print('np.median(a):', np.median(a))
print()
# np.median(a): 65.0

print('np.median(a, axis = 0):')
print(np.median(a, axis = 0))
print()  
# np.median(a, axis = 0):
# Go vertically, 
# 1) column 1: 50
# 2) column 2: 90
# 3) column 3: 60
# [50. 90. 60.]

print('np.median(a, axis = 1):')
print(np.median(a, axis = 1))
#np.median(a, axis = 1):
# Go horizontally, 65, 80, 60
#[65. 80. 60.]