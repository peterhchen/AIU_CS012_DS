import numpy as np 
x = np.array([3, 1, 2]) 
print('x:', x)
y = np.argsort(x)
print('y = np.argsort(x) => y:')
print(y) 
print()
#x: [3 1 2]
#y = np.argsort(x) => y:
#[1 2 0]

print('Reconstruct original array in sorted order:')
print('x[y]:')
print(x[y]) 
print()  
#Reconstruct original array in sorted order:
#x[y]:
#[1 2 3]

print('Reconstruct the original array using loop:') 
for i in y: 
   print(x[i], end=" ")
#Reconstruct the original array using loop:
#1 2 3