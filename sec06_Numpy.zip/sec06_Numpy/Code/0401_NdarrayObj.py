"""
File Name: test.py
"""

import numpy as np
A_1 = np.array([1, 2, 3])
print('A_1:')
print(A_1)
