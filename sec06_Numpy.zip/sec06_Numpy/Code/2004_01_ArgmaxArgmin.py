import numpy as np
a = np.array([[30,40,70],[80,20,10],[50,90,60]])
print('a:')
print(a)
print('np.argmax(a):')
print(np.argmax(a))
print()
#a:
#[[30 40 70]
# [80 20 10]
# [50 90 60]]
#np.argmax(a):
#7

print('Index of maximum number in flattened array:')
print('a.flatten():')
print(a.flatten())
print()
#Index of maximum number in flattened array:
#a.flatten():
#[30 40 70 80 20 10 50 90 60]

print('Array containing indices of maximum along axis 0:') 
print('maxindex = np.argmax(a, axis = 0) => maxindex:')
maxindex = np.argmax(a, axis = 0) 
print(maxindex)
print()
#Array containing indices of maximum along axis 0:
#maxindex = np.argmax(a, axis = 0) => maxindex:
#[1 2 0]
print('Array containing indices of maximum along axis 1:')
print('maxindex = np.argmax(a, axis = 0) => maxindex:')
maxindex = np.argmax(a, axis = 1)
print(maxindex)
print()
#Array containing indices of maximum along axis 1:
#maxindex = np.argmax(a, axis = 0) => maxindex:
#[2 0 1]

print('Applying argmin() function:')
print('minindex = np.argmin(a) => minindex:') 
minindex = np.argmin(a) 
print(minindex)
print()  
#Applying argmin() function:
#minindex = np.argmin(a) => minindex:
#5

print('Flattened array:')
print('a.flatten()[minindex]:')
print(a.flatten()[minindex])
print()
#Flattened array:
#a.flatten()[minindex]:
#10
print('Flattened array along axis 0:') 
minindex = np.argmin(a, axis = 0) 
print('minindex = np.argmin(a, axis = 0) => minindex:')
print(minindex)
print()
#Flattened array along axis 0:
#minindex = np.argmin(a, axis = 0) => minindex:
#[0 1 1]

print('Flattened array along axis 1:')
print('minindex = np.argmin(a, axis = 1) => minindex:')
minindex = np.argmin(a, axis = 1) 
print(minindex)
#Flattened array along axis 1:
#minindex = np.argmin(a, axis = 1) => minindex:
#[0 2 0]   