# int8, int16, int32, int64 can be replaced by 
# equivalent string 'i1', 'i2','i4', etc. 
import numpy as np 

dt = np.dtype('i4')
print('dt:')
print(dt)