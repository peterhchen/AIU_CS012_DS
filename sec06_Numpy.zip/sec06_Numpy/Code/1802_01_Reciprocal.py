import numpy as np 
a = np.array([0.25, 1.33, 1, 0, 100]) 

print('a:', a)
print()
# a: [  0.25   1.33   1.     0.   100.  ]

print('np.reciprocal(a):')
print(np.reciprocal(a))
print()
# RuntimeWarning: divide by zero encountered in reciprocal
# print(np.reciprocal(a))
# [4.        0.7518797 1.              inf 0.01     ]

b = np.array([100], dtype = int)  
print('b:', b)
print()  
#b: [100]

print('np.reciprocal(b):')
print(np.reciprocal(b))
#np.reciprocal(b):
#[0]