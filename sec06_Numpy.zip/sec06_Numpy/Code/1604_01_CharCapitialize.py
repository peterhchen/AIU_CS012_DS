import numpy as np 
print(np.char.capitalize('hello world'))
# Hello world