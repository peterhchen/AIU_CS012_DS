import numpy as np 
print(np.char.join(':','dmy')) 
print(np.char.join([':','-'],['dmy','ymd']))