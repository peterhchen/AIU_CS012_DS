import numpy as np 
a = np.arange(9, dtype = np.float_).reshape(3,3) 
print('a:')
print(a)  
b = np.array([10,10,10]) 
print('b:')
print(b) 
print() 
#a:
#[[0. 1. 2.]
# [3. 4. 5.]
# [6. 7. 8.]]
#b:
#[10 10 10]

print('np.add(a,b):')
print(np.add(a,b))
print()
# np.add(a,b):
#[[10. 11. 12.]
# [13. 14. 15.]
# [16. 17. 18.]]

print('np.subtract(a,b):') 
print(np.subtract(a,b)) 
print()

#np.subtract(a,b):
#[[-10.  -9.  -8.]
# [ -7.  -6.  -5.]
# [ -4.  -3.  -2.]]

print('np.multiply(a,b):') 
print(np.multiply(a,b))
print()
np.multiply(a,b):
[[ 0. 10. 20.]
 [30. 40. 50.]
 [60. 70. 80.]]

print('np.divide(a,b):')
print(np.divide(a,b))
#np.divide(a,b):
#[[0.  0.1 0.2]
# [0.3 0.4 0.5]
# [0.6 0.7 0.8]]