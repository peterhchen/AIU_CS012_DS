import numpy as np 
a = np.array([[1,2],[3,4]]) 
print ('a:')
print(a)
b = np.array([[5,6],[7,8]]) 
print('b:')
print(b)
#a:
#[[1 2]
# [3 4]]
#b:
#[[5 6]
# [7 8]]
print('Stack the two arrays along axis 0:') 
print('np.stack((a,b),0):') 
print(np.stack((a,b),0))  
#Stack the two arrays along axis 0:
#np.stack((a,b),0):
#[[[1 2]
#  [3 4]]
#
# [[5 6]
#  [7 8]]]

print('Stack the two arrays along axis 1:')
print('np.stack((a,b),1):')
print(np.stack((a,b),1))
#Stack the two arrays along axis 1:
#np.stack((a,b),1):
#[[[1 2] [5 6]]
#
# [[3 4] [7 8]]]