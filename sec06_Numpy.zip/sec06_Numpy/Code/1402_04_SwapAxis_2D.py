# It creates a 3 dimensional ndarray 
import numpy as np 
a = np.arange(4).reshape(2,2) 
print('The original array:') 
print('a:')
print(a)
# The original array:
# a:
#[[0 1]
# [2 3]]
print('now swap numbers between axis 0 (vertical) and axis 1 (horizontal))') 
print('The array after applying the swapaxes function:')
print('np.swapaxes(a, 1, 0):')
print(np.swapaxes(a, 1, 0))
#now swap numbers between axis 0 (vertical) and axis 1 (horizontal)
#The array after applying the swapaxes function:
#np.swapaxes(a, 1, 0):
#[[0 2]
# [1 3]]
