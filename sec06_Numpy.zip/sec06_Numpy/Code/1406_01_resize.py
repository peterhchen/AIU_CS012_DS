import numpy as np 
a = np.array([[1,2,3],[4,5,6]]) 
print('a:')
print(a)
print('a.shape:')
print(a.shape)   
#a:
#[[1 2 3]
# [4 5 6]]
#a.shape:
#(2, 3)
b = np.resize(a, (3, 2)) 
print('b = np.resize(a, (3, 2)):')
print(b) 
print('b.shape:')
print(b.shape)
# b = np.resize(a, (3, 2)):
#[[1 2]
# [3 4]
# [5 6]]
#b.shape:
#(3, 2)
print('Observe that first row of a is repeated in b since size is bigger') 
print('Resize the second array:') 
b = np.resize(a,(3,3)) 
print('b = np.resize(a,(3,3)):')
print(b)
#Observe that first row of a is repeated in b since size is bigger
#Resize the second array:
#b = np.resize(a,(3,3)):
#[[1 2 3]
# [4 5 6]
# [1 2 3]]