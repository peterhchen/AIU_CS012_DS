import numpy as np 
a = np.array([[10,10], [2,3], [4,5]]) 

print('a:')
print(a)
print()
#a:
#[[10 10]
# [ 2  3]
# [ 4  5]]

print('Create a slice:') 
s = a[:1, :]
print('s = a[:1, :] => s') 
print(s)
print()
#Create a slice:
#s = a[:1, :] => s
#[[10 10]]

s = a[:2, :]
print('s = a[:2, :] => s') 
print(s)
print()
#s = a[:2, :] => s
#[[10 10]
# [ 2  3]]

s = a[:, :1]
print('s = a[:, :1] => s') 
print(s)
print()
#s = a[:, :1] => s
#[[10]
# [ 2]
# [ 4]]
 
s = a[:, :2]
print('s = a[:, :2] => s') 
print(s)
#s = a[:, :2] => s
#[[10 10]
# [ 2  3]
# [ 4  5]]