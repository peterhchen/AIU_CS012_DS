import numpy as np 
# default base is 10 
a = np.logspace(1.0, 2.0, num = 10) 
# start = 10^1 = 10, stop = 10^2 = 100, num = 10 
print('a:')
print(a)
# a:
# [ 10.          12.91549665  16.68100537  21.5443469   27.82559402
#  35.93813664  46.41588834  59.94842503  77.42636827 100.        ]