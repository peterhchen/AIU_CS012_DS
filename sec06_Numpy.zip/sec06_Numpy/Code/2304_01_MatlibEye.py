import numpy.matlib
import numpy as np
print('np.matlib.eye(n = 3, M = 4, k = 0, dtype = float):')
print(np.matlib.eye(n = 3, M = 4, k = 0, dtype = float))
#np.matlib.eye(n = 3, M = 4, k = 0, dtype = float):
#[[1. 0. 0. 0.]
# [0. 1. 0. 0.]
# [0. 0. 1. 0.]]