import numpy as np 
a = np.array([[3,7,5],[8,4,3],[2,4,9]]) 
print('a:')
print(a)  
print()
#a:
#[[3 7 5]
# [8 4 3]
# [2 4 9]]

print('Apply to Axis 1 => np.amin(a, axis=1):')
print(np.amin(a, axis = 1))
print('np.amin(a, 1):')
print(np.amin(a, 1))
print()
# Apply to Axis 1 => np.amin(a, axis=1):
#[3 3 2]
#np.amin(a, 1):
#[3 3 2]

print('Apply to axis 0 => np.amin(a, 0):') 
print(np.amin(a, axis = 0)) 
print('np.amin(a, 0):') 
print(np.amin(a, 0)) 
print()
# Apply to axis 0 => np.amin(a, 0):
#[2 4 3]
#np.amin(a, 0):
#[2 4 3]

print('Apply to all => np.amin(a):') 
print(np.amin(a)) 
print()
#Apply to all => np.amin(a):
#2

print('Apply to axis 0 => np.amax(a, 0):') 
print(np.amax(a, 0)) 
print()
# Apply to axis 0 => np.amax(a, 0):
#[8 7 9]

print('Apply to axis 1 => np.amax(a, 1):') 
print(np.amax(a, 1)) 
print()
#Apply to axis 1 => np.amax(a, 1):
#[7 8 9]

print('Apply to all => np.amax(a):')
print(np.amax(a))
print()
#Apply to all => np.amax(a):
#9