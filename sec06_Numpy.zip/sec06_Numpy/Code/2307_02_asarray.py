import numpy.matlib
import numpy as np
i = np.matrix('1, 2; 3, 4')
print('i:')
print(i)
print()
#i:
#[[1 2]
# [3 4]]
j = np.asarray(i)
print('j:')
print(j)
#j:
#[[1 2]
# [3 4]]