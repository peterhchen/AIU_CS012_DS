# It creates 3 dimensional ndarray 
import numpy as np 
a = np.arange(8).reshape(2, 2, 2) 
print('The original array:') 
print('a:')
print(a) 
#The original array:
#a:
#[[[0 1]
#  [2 3]]
#
# [[4 5]
#  [6 7]]]
print('To roll axis-2 to axis-0 (along width to along depth):') 
print('After applying rollaxis function:')
print('np.rollaxis(a, 2):') 
print(np.rollaxis(a, 2))
#To roll axis-2 to axis-0 (along width to along depth):
#After applying rollaxis function:
#np.rollaxis(a,2):
#[[[0 2]
#  [4 6]]
#
# [[1 3]
#  [5 7]]]
print('To roll axis 0 to 1 (along width to height):') 
print ('After applying rollaxis function:')
print('np.rollaxis(a,2,1):')
print(np.rollaxis(a, 2, 1))
# To roll axis 0 to 1 (along width to height):
#After applying rollaxis function:
#np.rollaxis(a,2,1):
#[[[0 2]
#  [1 3]]
#
# [[4 6]
#  [5 7]]]