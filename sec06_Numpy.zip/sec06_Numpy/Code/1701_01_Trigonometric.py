import numpy as np 
a = np.array([0,30,45,60,90]) 
# a: [ 0 30 45 60 90]
print('a:', a) 
# Convert to radians by multiplying with pi/180
print('Sine values for angles in array:')
print('np.sin(a*np.pi/180):') 
print(np.sin(a*np.pi/180))
print()
# Sine values for angles in array:
#np.sin(a*np.pi/180):
#[0.         0.5        0.70710678 0.8660254  1.        ]

print('Cosine values for angles in array:') 
print('np.cos(a*np.pi/180):')
print(np.cos(a*np.pi/180))
print()
# Cosine values for angles in array:
#np.cos(a*np.pi/180):
#[1.00000000e+00 8.66025404e-01 7.07106781e-01 5.00000000e-01
# 6.12323400e-17]
print('Tangent values for given angles in array:')
print('np.tan(a*np.pi/180):')
print(np.tan(a*np.pi/180))
print()
# Tangent values for given angles in array:
#np.tan(a*np.pi/180):
#[0.00000000e+00 5.77350269e-01 1.00000000e+00 1.73205081e+00
# 1.63312394e+16]