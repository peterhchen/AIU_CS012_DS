import numpy as np 

x = np.array([[1,2],[3,4]]) 
y = np.linalg.inv(x) 
print('x:')
print(x)
print('y:')
print(y)
print('np.dot(x,y):')
print(np.dot(x,y))
#x:
#[[1 2]
# [3 4]]
#y:
#[[-2.   1. ]
# [ 1.5 -0.5]]
#np.dot(x,y):
#[[1.00000000e+00 1.11022302e-16]
# [0.00000000e+00 1.00000000e+00]]