import numpy as np 
a = np.arange(8).reshape(2,4) 
print ('a:')
print(a) 
#a:
#[[0 1 2 3]
# [4 5 6 7]]

# returns element corresponding to index in flattened array 
print('a.flat[5]') 
print(a.flat[5])
# a.flat[5]
# 5

# print flat array
print('x in a.flat')
for x in a.flat:
    print(x, end=" ")
# x in a.flat
# 0 1 2 3 4 5 6 7