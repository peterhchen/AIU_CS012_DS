import numpy.matlib 
import numpy as np 
print('np.matlib.empty((2,2)):') 
print(np.matlib.empty((2,2))) 
# filled with random data
# np.matlib.empty((2,2)):
#[[1.33511562e-306 1.69121775e-306]
# [9.34611827e-307 9.34601641e-307]]