import numpy as np 
a = np.arange(12).reshape(3,4) 

print('The original array is:') 
print('a:')
print(a)
# a:
# [[ 0  1  2  3]
#  [ 4  5  6  7]
#  [ 8  9 10 11]]

print('Array after applying the function:')
print('a.T:')
print(a.T)
# Array after applying the function:
# a.T:
# [[ 0  4  8]
#  [ 1  5  9]
#  [ 2  6 10]
#  [ 3  7 11]]