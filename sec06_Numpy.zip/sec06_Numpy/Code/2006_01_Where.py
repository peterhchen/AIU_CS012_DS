import numpy as np 
x = np.arange(9.).reshape(3, 3) 
print('x:') 
print(x)

print('Indices of elements > 3') 
y = np.where(x > 3)
print ('y = np.where(x > 3) => y:')
print(y)
print()  
#x:
#[[0. 1. 2.]
# [3. 4. 5.]
# [6. 7. 8.]]
#Indices of elements > 3
#y = np.where(x > 3) => y:
#(array([1, 1, 2, 2, 2], dtype=int64), 
# array([1, 2, 0, 1, 2], dtype=int64))

print('Use these indices to get elements satisfying the condition')
print('x[y]:')
print(x[y])
#Use these indices to get elements satisfying the condition
#x[y]:
#[4. 5. 6. 7. 8.]