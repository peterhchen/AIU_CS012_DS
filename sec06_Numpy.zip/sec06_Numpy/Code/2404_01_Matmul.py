# For 2-D array, it is matrix multiplication 
import numpy.matlib 
import numpy as np 

a = [[1,0],[0,1]] 
b = [[4,1],[2,2]] 
print('a:')
print(a)
print()
# a:
#[[1, 0], 
# [0, 1]]

print('b:')
print(b)
print()
# b:
#[[4, 1], 
# [2, 2]]

print('np.matmul(a,b):')
print(np.matmul(a,b))
#np.matmul(a,b):
# [1 x 4 + 0 x 2, 1 x x + 0 x 1]
# [0 x 4 + 1 x 2, 0 x 1 + 1 x 2]
#   
#[[4 1]
# [2 2]]
