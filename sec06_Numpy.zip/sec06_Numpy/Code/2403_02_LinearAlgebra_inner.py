# Multi-dimensional array example 
import numpy as np
a = np.array([[1,2], [3,4]])
print('a:')
print(a)
#a:
#[[1 2]
# [3 4]]

b = np.array([[11, 12], [13, 14]]) 
print('b:')
print(b)
#b:
#[[11 12]
# [13 14]]

print('Inner product:') 
print('np.inner(a,b):')
print(np.inner(a,b))
#Inner product:
# np.inner(a,b):
# 1 * 11 + 2 * 12 = 35, 1 * 13 + 2 * 14 = 41
# 3 * 11 + 4 * 12 = 81, 3 * 13 + 4 * 14 = 95
#[[35 41]
# [81 95]]