# It creates a 3 dimensional ndarray 
import numpy as np 
a = np.arange(8).reshape(2,2,2) 
print('The original array:') 
print('a:')
print(a)
# The original array:
# a:
#[[[0 1]
#  [2 3]]
#
# [[4 5]
#  [6 7]]]
print('now swap numbers between axis 0 (along depth) and axis 2 (along width)') 
print('The array after applying the swapaxes function:')
print('np.swapaxes(a, 2, 0):')
print(np.swapaxes(a, 2, 0))
#now swap numbers between axis 0 (along depth) and axis 2 (along width)
#The array after applying the swapaxes function:
#np.swapaxes(a, 2, 0):
#[[[0 4]
#  [2 6]]
#
# [[1 5]
#  [3 7]]]