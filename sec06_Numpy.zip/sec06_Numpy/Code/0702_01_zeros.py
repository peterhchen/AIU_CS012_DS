# array of five zeros. Default dtype is float 
import numpy as np 
x = np.zeros(5) 
print('x:', x)
# Default is float array
# x: [0. 0. 0. 0. 0.]