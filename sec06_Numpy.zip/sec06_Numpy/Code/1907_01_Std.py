import numpy as np 
print('np.std
# np.std([1,2,3,4]): 1.118033988749895