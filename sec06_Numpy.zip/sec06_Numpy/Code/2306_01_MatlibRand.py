import numpy.matlib
import numpy as np 
print('np.matlib.rand(3, 3):')
print(np.matlib.rand(3, 3))
# np.matlib.rand(3,3):
#[[0.43160354 0.20074364 0.07644498]
# [0.45909958 0.46284767 0.62297809]
# [0.47386021 0.87961773 0.0307362 ]]