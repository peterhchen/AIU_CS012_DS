import numpy as np 
a = np.array([[1,2],[3,4]])
print('a:')
print(a)
print()
#a:
#[[1 2]
# [3 4]]

print('b:')
print(b)
print()
#b:
#[[11 12]
# [13 14]]

print('np.vdot(a,b):')
print(np.vdot(a,b))
# 1 * 11 + 2 * 12 + 3 * 13 + 4 * 14 = 130
# np.vdot(a,b):
# 130