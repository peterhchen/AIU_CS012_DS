# dtype of array is now float32 (4 bytes) 
import numpy as np 
x = np.array([1,2,3,4,5], dtype = np.float32) 
print('x: Each Array Element is float32 (4 bytes)')
print(x)
# float32
print('x.itemsize:')
print(x.itemsize)
# 4