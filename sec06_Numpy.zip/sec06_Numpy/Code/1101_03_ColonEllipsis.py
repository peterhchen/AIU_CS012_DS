import numpy as np 
x = np.array([ [0,  1,  2], [3,  4,  5], [6,  7,  8], [9, 10, 11] ]) 

print('x:')
print(x)   
# x:
# [[ 0  1  2]
#  [ 3  4  5]
#  [ 6  7  8]
#  [ 9 10 11]]

# slicing 
z = x[1:4, 1:3] 

print('Slicing: z = x[1:4, 1:3] =>') 
print(z)
# x [1:4, 1:3] => x [1 to 3, 1 to 2]
# change column number first, and then change row number
# 1) row = 1, col = 1 to 2 => x[1, 1] = 4, x[1, 2] = 5
# 2) row = 2, col = 1 to 2 => x[2, 1] = 7, x[2, 2] = 8
# 3) row = 3, col = 1 to 2 => x[3, 1] = 10, x[3, 2] = 11 
# Slicing: z = x[1:4, 1:3] =>
# [[ 4  5]
#  [ 7  8]
#  [10 11]]
# using advanced index for column 
y = x[1:4, [1, 2]] 
# x[1:4, [1, 2]] => x[1 to 3, 1] and x[1 to 3, 2]
# 1) row = 1, col = [1, 2] => x[1, 1] = 4, x[1, 2] = 5
# 2) row = 2, col = [1, 2] => x[2, 1] = 7, x[2, 2] = 8
# 3) row = 3, col = [1, 2] => x[3, 1] = 10, x[3, 2] = 11
print('y = x [1:4, [1, 2]] =>') 
print(y)
# y = x [1:4, [1, 2]] =>
# [[ 4  5]
#  [ 7  8]
#  [10 11]]