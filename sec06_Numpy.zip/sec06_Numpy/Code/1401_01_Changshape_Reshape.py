import numpy as np
a = np.arange(8)
print('a:', a)
# a: [0 1 2 3 4 5 6 7]
b = a.reshape(4,2)
print('b:')
print(b)
# b:
# [[0 1]
# [2 3]
# [4 5]
# [6 7]]