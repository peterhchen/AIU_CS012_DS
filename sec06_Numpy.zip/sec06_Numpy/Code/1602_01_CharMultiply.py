import numpy as np 
print(np.char.multiply('Hello ',3))
# Hello Hello Hello