import numpy as np 
a = np.array([1, 2+6j, 5, 3.5+5j]) 
print('a => ', a)
# a =>  [1. +0.j 2. +6.j 5. +0.j 3.5+5.j]
print('a[np.iscomplex(a)] =>', a[np.iscomplex(a)])
# a[np.iscomplex(a)] => [2. +6.j 3.5+5.j]