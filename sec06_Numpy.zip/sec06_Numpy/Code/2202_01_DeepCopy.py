import numpy as np 
a = np.array([[10,10], [2,3], [4,5]]) 
 
print('a:')
print(a)  
print('Create a deep copy of a:')
b = a.copy() 
print('b = a.copy() => b:') 
print(b)
print('id of a and b are different:')
print('id (a):', id(a))
print('id (b):', id(b)) 
print()
#a:
#[[10 10]
# [ 2  3]
# [ 4  5]]
#Create a deep copy of a:
#b = a.copy() => b:
#[[10 10]
# [ 2  3]
# [ 4  5]]
#id of a and b are different:
#id (a): 2193376031824
#id (b): 2193422541808

#b does not share any memory of a 
print('Can we write b is a') 
print('b is a:', b is a)  
print()
#Can we write b is a
#b is a: False

print('Change the contents of b:')
b[0][0] = 100
print('Modified array b:') 
print(b)
print()  
print('a remains unchanged:') 
print('a:')
print(a)
#Change the contents of b:
#Modified array b:
#[[100  10]
# [  2   3]
#
#a remains unchanged:
#a:
#[[10 10]
# [ 2  3]
# [ 4  5]]
