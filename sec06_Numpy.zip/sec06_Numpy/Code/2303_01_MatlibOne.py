import numpy.matlib
import numpy as np
print('np.matlib.ones((2,2)):')
print(np.matlib.ones((2,2)))
# np.matlib.ones((2,2)):
# [[1. 1.]
# [1. 1.]]