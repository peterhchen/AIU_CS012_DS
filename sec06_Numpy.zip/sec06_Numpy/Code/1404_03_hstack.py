import numpy as np 
a = np.array([[1,2],[3,4]]) 
print('a:')
print(a)
b = np.array([[5,6],[7,8]]) 
print('b:')
print(b)  
#a:
#[[1 2]
# [3 4]]
#b:
#[[5 6]
# [7 8]]
print('Horizontal stacking:') 
c = np.hstack((a,b)) 
print('c = np.hstack((a,b)):') 
print(c) 
#Horizontal stacking:
#c = np.hstack((a,b)):
#[[1 2 5 6]
# [3 4 7 8]]