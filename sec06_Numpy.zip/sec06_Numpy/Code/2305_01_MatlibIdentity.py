import numpy.matlib 
import numpy as np
print('np.matlib.identity(5, dtype = float):')
print(np.matlib.identity(5, dtype = float))
# np.matlib.identity(5, dtype = float):
#[[1. 0. 0. 0. 0.]
# [0. 1. 0. 0. 0.]
# [0. 0. 1. 0. 0.]
# [0. 0. 0. 1. 0.]
# [0. 0. 0. 0. 1.]]