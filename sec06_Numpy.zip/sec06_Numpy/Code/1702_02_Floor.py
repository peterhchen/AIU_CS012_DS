import numpy as np 
a = np.array([-1.7, 1.5, -0.2, 0.6, 10]) 
print('a:', a) 
print()
# a: [-1.7  1.5 -0.2  0.6 10. ]

print('np.floor(a):')
print(np.floor(a))
#np.floor(a):
#[-2.  1. -1.  0. 10.]