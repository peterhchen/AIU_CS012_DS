import numpy as np 
print(np.char.splitlines('Hello\nHow are you?'))
#['Hello', 'How are you?']
print(np.char.splitlines('Hi\rWhat is going on?'))
#['Hi', 'What is going on?']