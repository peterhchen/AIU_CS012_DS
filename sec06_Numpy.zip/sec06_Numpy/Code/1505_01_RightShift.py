import numpy as np 
a = 40
print("a:", a)
shift_result = np.right_shift(a, 2) 
print('shift_result:', shift_result)
print('np.binary_repr(a, width = 8):') 
print(np.binary_repr(a, width = 8))

print('np.binary_repr(shift_result, width = 8):') 
print(np.binary_repr(shift_result, width = 8))
#a: 40
#shift_result: 10
#np.binary_repr(a, width = 8):
#00101000
#np.binary_repr(shift_result, width = 8):
#00001010 