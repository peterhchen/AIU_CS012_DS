import numpy as np
# a * x = b
a = np.array([[1, 2, 1], [2, 2, 2], [3, 1, 1]])
b = np.array([5, 6, 5])
x = np.linalg.solve(a, b)
print('a:')
print(a)
print('b:')
print(b)
print('x:')
print(x)
#a:
#[[1 2 1]
# [2 2 2]
# [3 1 1]]
#b:
#[5 6 5]
#x:
# [1.00000000e+00 2.00000000e+00 3.70074342e-17]