import numpy as np 
a = np.array([[1,2],[3,4],[5,6]]) 
print('a:')
print(a) 
#a:
#[[1 2]
# [3 4]
# [5 6]]
print('Axis parameter not passed. The input array is flattened before insertion.')
print('np.insert(a, 3 [11,12]):')
print(np.insert(a,3,[11,12])) 
#Axis parameter not passed. The input array is flattened before insertion.
#np.insert(a, 3, [11,12]):
#[ 1  2  3 11 12  4  5  6]
print('Axis parameter passed. The values array is broadcast to match input array.')
print('Broadcast along axis 0:') 
print('np.insert(a, 1, [11], axis = 0):')
print(np.insert(a, 1, [11],axis = 0)) 
#Axis parameter passed. The values array is broadcast to match input array.
#Broadcast along axis 0:
#np.insert(a, 1, [11], axis = 0):
#[[ 1  2]
# [11 11]
# [ 3  4]
# [ 5  6]]
print('Broadcast along axis 1:') 
print('np.insert(a,1,11,axis = 1):')
print(np.insert(a, 1, 11, axis = 1))
# Broadcast along axis 1:
#np.insert(a,1,11,axis = 1):
#[[ 1 11  2]
# [ 3 11  4]
# [ 5 11  6]]