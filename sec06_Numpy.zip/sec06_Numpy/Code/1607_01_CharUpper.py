import numpy as np 
print(np.char.upper('hello'))
# HELLO
print(np.char.upper(['hello','world']))
# ['HELLO' 'WORLD']