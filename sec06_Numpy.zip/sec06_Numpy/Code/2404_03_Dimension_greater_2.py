# one array having dimensions > 2 
import numpy.matlib 
import numpy as np 

a = np.arange(8).reshape(2,2,2)
b = np.arange(4).reshape(2,2)
print('a:')
print(a)
print('b:')
print(b)
print('np.matmul(a, b):')
print(np.matmul(a, b))
# a:
#[[[0 1]
#  [2 3]]
# [[4 5]
#  [6 7]]]
#b:
#[[0 1]
# [2 3]]
#np.matmul(a, b):
#[[[ 2  3]
#  [ 6 11]]
# [[10 19]
#  [14 27]]]