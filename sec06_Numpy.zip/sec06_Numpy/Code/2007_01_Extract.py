import numpy as np 
x = np.arange(9.).reshape(3, 3) 

print('x:')
print(x)  
x:
#[[0. 1. 2.]
# [3. 4. 5.]
# [6. 7. 8.]]

# define a condition 
condition = np.mod(x,2) == 0 

print('Element-wise value of condition')
print('condition = np.mod(x,2) == 0 => condition:') 
print(condition)  
print()
#Element-wise value of condition
#condition = np.mod(x,2) == 0 => condition:
#[[ True False  True]
# [False  True False]
# [ True False  True]]

print('Extract elements using condition') 
print('np.extract(condition, x):')
print(np.extract(condition, x))
# Extract elements using condition
#np.extract(condition, x):
#[0. 2. 4. 6. 8.]