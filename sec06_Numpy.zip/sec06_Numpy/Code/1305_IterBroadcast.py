import numpy as np 
a = np.arange(0,60,5) 
a = a.reshape(3,4) 

print('a:') 
print(a) 
# a:
# [[ 0  5 10 15]
#  [20 25 30 35]
#  [40 45 50 55]]

b = np.array([1, 2, 3, 4], dtype = int) 
print('b:', b)  
# b: [1 2 3 4]

print('Broadcasting with nditer:') 
for x, y in np.nditer([a,b]): 
   print("%d:%d" % (x, y), end=" ")
# Broadcasting with nditer:
# 0:1 5:2 10:3 15:4 20:1 25:2 30:3 35:4 40:1 45:2 50:3 55:4