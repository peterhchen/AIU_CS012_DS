import numpy as np 
print('np.var([1,2,3,4]):', np.var([1,2,3,4]))
# np.var([1,2,3,4]): 1.25