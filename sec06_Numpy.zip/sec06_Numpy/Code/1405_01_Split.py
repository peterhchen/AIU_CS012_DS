import numpy as np 
a = np.arange(9) 
print('a:')
print(a) 
#a:
#[0 1 2 3 4 5 6 7 8]

print('Split the array in 3 equal-sized subarrays:')
b = np.split(a,3) 
print('b = np.split(a,3):')
print(b) 
#Split the array in 3 equal-sized subarrays:
#b = np.split(a,3):
#[array([0, 1, 2]), array([3, 4, 5]), array([6, 7, 8])]

print('Split the array at positions indicated in 1-D array:') 
b = np.split(a,[4,7])
print('b = np.split(a,[4,7]):')
print(b) 
#Split the array at positions indicated in 1-D array:
#b = np.split(a,[4,7]):
#[array([0, 1, 2, 3]), array([4, 5, 6]), array([7, 8])]