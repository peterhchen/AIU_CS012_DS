import numpy as np
print(np.char.title('hello how are you?'))
# Hello How Are You?