import numpy as np 
a = np.array([1,2,3,4]) 
print('a:', a)
#a: [1 2 3 4]
print('np.average(a):', np.average(a))
print()
# (1 x 1 + 2 x 1 + 3 x 1 + 4 x 1)/(1+1+1+1) = 10/4 = 2.5 
#np.average(a): 2.5

print('a:', a)
wts = np.array([4,3,2,1]) 
print('Weight array => wts:', wts)
print('np.average(a, weights = wts):')
print(np.average(a, weights = wts))
print()  
#a: [1 2 3 4]
# Weight array => wts: [4 3 2 1]
# np.average(a, weights = wts):
# (1 x 4 + 2 x 3 + 3 x 2 + 4 x 1)/(4 + 3 + 2 + 1) = (4 + 6 + 6 + 4)/10
# = 20/10 = 2
# 2.0
# Returns the sum of weights, if the returned parameter is set to True. 
print('Sum of weights with array and weights:')
print('np.average([1, 2, 3, 4], weights = [4,3,2,1], returned = True):')
print(np.average([1,2,3, 4], weights = [4,3,2,1], returned = True))
#Sum of weights with array and weights:
#np.average([1, 2, 3, 4], weights = [4,3,2,1], returned = True):
# # (1 x 4 + 2 x 3 + 3 x 2 + 4 x 1)/(4 + 3 + 2 + 1) = (4 + 6 + 6 + 4)/10
# = 20/10 = 2
# wirght (4 + 3 + 2 + 1) = 10
#(2.0, 10.0)