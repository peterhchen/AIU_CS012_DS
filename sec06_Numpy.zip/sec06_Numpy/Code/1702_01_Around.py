import numpy as np 
a = np.array([1.0, 5.55, 123, 0.567, 25.532]) 
print('a:', a) 
print()  
# a: [  1.      5.55  123.      0.567  25.532]

print('np.around(a):')
print(np.around(a))
print()
# Default: round to decimal position 0.
#np.around(a):
# 1. => 1., 5.55 => 6., 123. => 123., 0.567 => 1., 25.532 => 26.
#[  1.   6. 123.   1.  26.]

print('np.around(a, decimals = 1):')
print(np.around(a, decimals = 1))
print() 
# 1: round to decimal position 1. 
# 1. => 1., 5.55 => 5.6, 123. => 123., 0.567 => 0.6., 25.532 => 26.5
# Longer than one decimal is cut.
#np.around(a, decimals = 1):
#[  1.    5.6 123.    0.6  25.5]

print('np.around(a, decimals = -1):')
print(np.around(a, decimals = -1))
print()
# -1: round to the decimal position -1 (left of decimal). 
# 1. => 0, 6. => 10., 123 => 120. 26. => 30.
#np.around(a, decimals = -1):
#[  0.  10. 120.   0.  30.]