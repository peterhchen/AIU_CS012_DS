import numpy.matlib 
import numpy as np  
a = np.array([[1, 2], [3, 4]])
print('a:')
print(a)
#a:
#[[1 2]
# [3 4]]
k = np.asmatrix(a)
print('k:')
print(k)
# k:
#[[1 2]
# [3 4]]