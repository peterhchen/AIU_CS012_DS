# minimum dimensions 
import numpy as np 
a = np.array([1, 2, 3,4,5], ndmin = 2)
print('a:')
print(a)