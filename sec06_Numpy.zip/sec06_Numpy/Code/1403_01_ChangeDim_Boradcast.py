import numpy as np 
x = np.array([[1], [2], [3]]) 
y = np.array([4, 5, 6])  
print('x:')
print(x)
print('y:', y)
#x:
#[[1]
# [2]
# [3]]
#y: [4 5 6]
print('To broadcast x against y') 
b = np.broadcast(x,y)
print("It has an iterator property, a tuple of iterators along self's 'components.'") 
print('b = np.broadcast(x,y):')
print(b)
# To broadcast x against y
# It has an iterator property, a tuple of iterators along self's 'components.'
# b = np.broadcast(x,y):
# <numpy.broadcast object at 0x0000028C3148B190>

print('Broadcast x against y:') 
print('Shape attribute returns the shape of broadcast object') 
print('The shape of the broadcast object:')
print('b.shape:')  
print(b.shape) 
#Broadcast x against y:
#Shape attribute returns the shape of broadcast object
#The shape of the broadcast object:
#b.shape:
#(3, 3)
print('To add x and y manually using broadcast') 
b = np.broadcast(x,y)
print('b = np.broadcast(x,y):')
print(b) 
c = np.empty(b.shape) 
print('c = np.empty(b.shape):')
print(c)
print('Add x and y manually using broadcast:')
print('c.shape:')
print(c.shape) 
# To add x and y manually using broadcast
#b = np.broadcast(x,y):
#<numpy.broadcast object at 0x0000028C3148A1D0>
#c = np.empty(b.shape):
#[[4.89544090e-307 6.23041391e-307 3.56033887e-307]
# [8.06623226e-308 1.33509015e-307 9.45697982e-308]
# [2.55896905e-307 3.22649121e-307 1.44635488e-307]]
#Add x and y manually using broadcast:
#c.shape:
#(3, 3)
print('After applying the flat function:')  
c.flat = [u + v for (u,v) in b] 
print('c.flat = [u + v for (u,v) in b]:') 
print (c)
#After applying the flat function:
#c.flat = [u + v for (u,v) in b]:
#[[5. 6. 7.]
# [6. 7. 8.]
# [7. 8. 9.]]  
print("same result obtained by NumPy's built-in broadcasting support") 
print('The summation of x and y:') 
print('x + y:')
print(x + y)
#same result obtained by NumPy's built-in broadcasting support
#The summation of x and y:
#x + y:
#[[5 6 7]
# [6 7 8]
# [7 8 9]]