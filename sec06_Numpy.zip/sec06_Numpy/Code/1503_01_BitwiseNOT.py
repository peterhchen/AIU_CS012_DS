import numpy as np 
a = 13
print('a:', a)
print(np.binary_repr(a, width = 8)) 
result = np.invert(np.array(a, dtype=np.uint8))
print('print(np.binary_repr(result, width = 8):')
print(np.binary_repr(result, width = 8))
print()
b = 242
print('b:', b)
print(np.binary_repr(b, width = 8))
result = np.invert(np.array(b, dtype=np.uint8))
print('print(np.binary_repr(result, width = 8):')
print(np.binary_repr(result, width = 8))