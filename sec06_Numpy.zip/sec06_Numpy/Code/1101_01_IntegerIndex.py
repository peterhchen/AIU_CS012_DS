import numpy as np 

x = np.array([[1, 2], [3, 4], [5, 6]]) 
print('x:')
print(x) 
# x:
# [[1 2]
#  [3 4]
#  [5 6]]
y = x[[0,1,2], [0,1,0]] 
# Selection (0, 0) => 1, (1, 1) => 4, (2, 0) => 5
# => [0, 1, 5]
print('y:', y)
# y: [1 4 5]