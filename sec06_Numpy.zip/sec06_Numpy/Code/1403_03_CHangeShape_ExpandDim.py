import numpy as np 
x = np.array(([1,2],[3,4])) 
print('x:') 
print(x) 
#x:
#[[1 2]
# [3 4]] 
# x.shape (2, 2)
print('x.ndim:', x.ndim) 
#x.ndim: 2
print('x.shape', x.shape)
# x.shape (2, 2)

y = np.expand_dims(x, axis = 0) 
print('y = np.expand_dims(x, axis = 0) => y:') 
print(y) 
#y = np.expand_dims(x, axis = 0) => y:
#[[[1 2]
#  [3 4]]]
print('y.ndim:', y.ndim) 
#y.ndim: 3
print('y.shape:', y.shape)
# y.shape: (1, 2, 2) 

# insert axis at position 1 
y = np.expand_dims(x, axis = 1) 
print('y = np.expand_dims(x, axis = 1)=>y')
print(y)
# y = np.expand_dims(x, axis = 1)=>y
# [[[1 2]]
#
#  [[3 4]]]
print('y.ndim:', y.ndim) 
#y.ndim: 3
print('y.shape:', y.shape)
#y.shape: (2, 1, 2)