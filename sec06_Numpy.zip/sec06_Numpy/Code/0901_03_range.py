# start and stop parameters set 
import numpy as np 
x = np.arange(10,20,2) 
# arange(start, step, step)
print('x:', x)
# x: [10 12 14 16 18]