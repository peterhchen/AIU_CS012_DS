import numpy as np 
a = np.arange(8).reshape(2,4) 

print('a:')
print(a)
# a:
# [[0 1 2 3]
# [4 5 6 7]] 

# default is column-major 
print('default is column-major:')
print('The flattened array is:')
print('a.flatten():')
print(a.flatten()) 
# default is column-major:
# The flattened array is:
# a.flatten():
# [0 1 2 3 4 5 6 7]

print('The flattened array in F-style ordering:') 
print("a.flatten(order = 'F'):")
print(a.flatten(order = 'F'))
# The flattened array in F-style ordering:
# a.flatten(order = 'F'):
# [0 4 1 5 2 6 3 7]