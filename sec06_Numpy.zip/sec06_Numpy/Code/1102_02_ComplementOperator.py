import numpy as np 
a = np.array([np.nan, 1, 2, np.nan, 3, 4, 5]) 
print('a => ', a)
# a =>  [nan  1.  2. nan  3.  4.  5.]
# Use complement operator (~) to select the element.
print('a[~np.isnan(a)] => ', a[~np.isnan(a)])
# a[~np.isnan(a)] =>  [1. 2. 3. 4. 5.]