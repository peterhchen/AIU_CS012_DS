import numpy as np 
a = np.arange(16).reshape(4,4) 
print('a:')
print(a) 
#a:
#[[ 0  1  2  3]
# [ 4  5  6  7]
# [ 8  9 10 11]
# [12 13 14 15]]
print('Horizontal splitting:') 
b = np.hsplit(a,2) 
print('b = np.hsplit(a,2):') 
print(b)
#Horizontal splitting:
#b = np.hsplit(a,2):
#[array([[ 0,  1],
#       [ 4,  5],
#       [ 8,  9],
#       [12, 13]]), 
# array([[ 2,  3],
#       [ 6,  7],
#       [10, 11],
#       [14, 15]])]