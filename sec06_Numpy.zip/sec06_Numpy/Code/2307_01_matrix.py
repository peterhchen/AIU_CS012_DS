import numpy.matlib 
import numpy as np  

i = np.matrix('1, 2; 3, 4') 
print('i:')
print(i)
# i:
#[[1 2]
# [3 4]]