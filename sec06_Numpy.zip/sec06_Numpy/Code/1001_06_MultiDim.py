import numpy as np 
a = np.array([[1,2,3],[3,4,5],[4,5,6]]) 
print('a:')
print(a)  
#a:
#[[1 2 3]
# [3 4 5]
# [4 5 6]]
# print a[0]
print('a[0]:')
print(a[0])
# a[0]:
# [1 2 3]
# print a[1]
print('a[1]:')
print(a[1])
# a[1]:
# [3 4 5]
# print a[2]
print('a[2]:')
print(a[2])
# a[2]:
# [4 5 6]

# slice items starting from index
print('Now we will slice the array from the index a[1:]')
print(a[1:])

#Now we will slice the array from the index a[1:]
#[[3 4 5]
# [4 5 6]]