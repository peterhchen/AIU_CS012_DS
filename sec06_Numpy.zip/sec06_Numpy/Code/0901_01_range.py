import numpy as np 
x = np.arange(5) 
print('x:', x)
# x: [0 1 2 3 4]