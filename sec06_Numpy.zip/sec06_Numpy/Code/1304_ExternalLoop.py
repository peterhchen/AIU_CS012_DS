import numpy as np 
a = np.arange(0,60,5) 
a = a.reshape(3,4) 

print('a:')
print(a)   
# a:
# [[ 0  5 10 15]
#  [20 25 30 35]
#  [40 45 50 55]]
print('Modified array with nditer flags = external_loop:') 
for x in np.nditer(a, flags = ['external_loop'], order = 'F'):
   print(x, end=" ")
# Modified array with nditer flags = external_loop:
# [ 0 20 40] [ 5 25 45] [10 30 50] [15 35 55]