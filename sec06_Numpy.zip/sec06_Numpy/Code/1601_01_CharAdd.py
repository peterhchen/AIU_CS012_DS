import numpy as np 
print('Concatenate two strings:')
print(np.char.add(['hello'],[' xyz']))
print()
# Concatenate two strings:
# ['hello xyz']

print('Concatenation example:') 
print(np.char.add(['hello', 'hi'],[' abc', ' xyz']))
# Concatenation example:
# ['hello abc' 'hi xyz']