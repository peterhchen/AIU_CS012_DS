import numpy as np 
# np.char.center(arr, width,fillchar) 
print(np.char.center('hello', 20, fillchar = '*'))
#*******hello********