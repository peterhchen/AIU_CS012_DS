# 2-D mixed with 1-D 
import numpy.matlib
import numpy as np

a = [[1,0],[0,1]]
print('a:')
print(a)
b = [1,2]
print('b:')
print(b)
print()
#a:
#[[1, 0], 
# [0, 1]]
#b:
#[1, 2]
print('np.matmul(a, b):')
print(np.matmul(a,b))
print('np.matmul(b, a):')
print(np.matmul(b,a))
#np.matmul(a, b):
# #[[1, 0], 
# [0, 1]]
#b:
#[1, 2]
#[1, 1] (extend 1)
# [1 x 1 + 0 x 1, 1 x 2 + 0 x 1] => [1 2]
# [0 x 1 + 1 x 1, 0 x 1 + 1 x 1] => [1 1]
# After calculate, the second append ([1 1]) is removed
# [1 2]
#np.matmul(b,a):
#b:
#[1, 2]
#[1, 1] (extend 1)
# a:
#[[1, 0], 
# [0, 1]]
# [1 x 1 + 2 x 0, 2 x 0 + 2 x 1] => [1, 2]
# [1 x 1 + 1 x 0, 1 x 0 + 1 x 1] => [1, 1] 
# After calculated, the second extend [1, 1] is removed.
#[1 2]