import numpy as np 
a = np.arange(12).reshape(3,4) 

print('The original array is:')
print('a:')
print(a)
# The original array is:
# a:
# [[ 0  1  2  3]
# [ 4  5  6  7]
# [ 8  9 10 11]]


print('The transposed array is:')
print('np.transpose(a):')
print(np.transpose(a))
# The transposed array is:
# np.transpose(a):
# [[ 0  4  8]
# [ 1  5  9]
# [ 2  6 10]
# [ 3  7 11]]