import numpy as np 
a = 10
print('a:', a)
shift_result = np.left_shift(a, 2)
print('shift_result:', shift_result)
a_bin = np.binary_repr(a, width = 8)
print('a_bin:', a_bin)
shift_result_bin = np.binary_repr(shift_result, width = 8)
print('shift_result_bin:', shift_result_bin)
# a: 10
# shift_result: 40
# a_bin: 00001010
# shift_result_bin: 00101000