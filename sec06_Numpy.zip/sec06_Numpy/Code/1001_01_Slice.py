import numpy as np 
a = np.arange(10)
print("a:", a) 
# a: [0 1 2 3 4 5 6 7 8 9]
s = slice(2,7,2) 
# start = 2, steop = 7, step = 2
print('s:', s)
# s: slice(2, 7, 2)
print('a[s]:', a[s])
# start = 2 => a[2] = 2
# stop = 7 => stop at a[7] = 7
# [2, 7) => we have [0, 1, 2, 3, 4, 5, 6], index 7 is open bracket.
# [2, 7, 2) => we have [2, 4, 6] 
# a[s]: [2 4 6]