import numpy as np 
a = np.arange(12).reshape(3,4) 
print('a:')
print(a)  
#a:
#[[ 0  1  2  3]
# [ 4  5  6  7]
# [ 8  9 10 11]]
print('Array flattened before delete operation as axis not used:') 
print(np.delete(a,5)) 
#Array flattened before delete operation as axis not used:
#[ 0  1  2  3  4  6  7  8  9 10 11]
print('Column 2 deleted:')
print('np.delete(a, 1, axis = 1):') 
print(np.delete(a, 1, axis = 1)) 
#Column 2 deleted:
#np.delete(a, 1, axis = 1):
#[[ 0  2  3]
# [ 4  6  7]
# [ 8 10 11]]
print('A slice containing alternate values from array deleted:') 
a = np.array([1,2,3,4,5,6,7,8,9,10])
print('a:', a)
print('np.delete(a, np.s_[::2]):')
print(np.delete(a, np.s_[::2]))
#A slice containing alternate values from array deleted:
#a: [ 1  2  3  4  5  6  7  8  9 10]
#np.delete(a, np.s_[::2]):
#[ 2  4  6  8 10]