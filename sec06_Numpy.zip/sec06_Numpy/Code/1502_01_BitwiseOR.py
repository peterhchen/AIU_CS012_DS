import numpy as np 
a,b = 13,17 
print('a:', a, 'b:', b)
print('np.binary_repr(a, width=8):', np.binary_repr(a, width=8))
print('np.binary_repr(b, width=8):', np.binary_repr(b, width=8))
result = np.bitwise_or(a, b)
print('result:', result) 
print('np.binary_repr(result, width=8):', np.binary_repr(result, width=8))
print()
#a: 13 b: 17
#np.binary_repr(a, width=8): 00001101
#np.binary_repr(b, width=8): 00010001
#result: 29
#np.binary_repr(result, width=8): 00011101

c, d = 2, 17
print('c:', c, 'b:', d)
print('np.binary_repr(c, width=8):', np.binary_repr(c, width=8))
print('np.binary_repr(d, width=8):', np.binary_repr(d, width=8))
result = np.bitwise_or(c, d)
print('result:', result)
print('np.binary_repr(result, width=8):', np.binary_repr(result, width=8))
#c: 2 b: 17
#np.binary_repr(c, width=8): 00000010
#np.binary_repr(d, width=8): 00010001
# result: 19
# np.binary_repr(result, width=8): 000100111