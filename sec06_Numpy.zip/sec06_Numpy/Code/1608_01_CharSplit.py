import numpy as np 
print(np.char.split ('hello how are you?'))
# ['hello', 'how', 'are', 'you?']
print(np.char.split ('SVU,San Jose,California, USA', sep = ','))
# ['SVU', 'San Jose', 'California', ' USA']