import numpy as np 
a = np.array([[1,2,3],[4,5,6]]) 
print('a:')
print(a) 
#a:
#[[1 2 3]
# [4 5 6]]
print('Append elements to array:')
print('np.append(a, [7,8,9]):') 
print(np.append(a, [7,8,9])) 
#Append elements to array:
#np.append(a, [7,8,9]):
#[1 2 3 4 5 6 7 8 9]
print('Append elements along axis 0:') 
print('np.append(a, [[7,8,9]], axis = 0):')
print(np.append(a, [[7,8,9]], axis = 0))
#Append elements along axis 0:
#np.append(a, [[7,8,9]], axis = 0):
#[[1 2 3]
# [4 5 6]
# [7 8 9]]
print('Append elements along axis 1:') 
print('np.append(a, [[5,5,5],[7,8,9]], axis = 1):')
print(np.append(a, [[5,5,5],[7,8,9]], axis = 1))
# Append elements along axis 1:
#np.append(a, [[5,5,5],[7,8,9]], axis = 1):
#[[1 2 3 5 5 5]
# [4 5 6 7 8 9]]