import numpy as np 
a = np.arange(0,60,5) 
a = a.reshape(3,4) 

print('a:')
print(a)
# a:
# [[ 0  5 10 15]
#  [20 25 30 35]
#  [40 45 50 55]]

print('Traverse by nditer in C-style order:') 
for x in np.nditer(a, order = 'C'): 
   print(x, end=" ")  
print()
# Traverse by nditer in C-style order
# 0 5 10 15 20 25 30 35 40 45 50 55

print('Traverse by nditer in F(Fortran)-style order:') 
for x in np.nditer(a, order = 'F'): 
   print(x, end=" ")
# Traverse by nditer in F(Fortran)-style order:
# 0 20 40 5 25 45 10 30 50 15 35 55