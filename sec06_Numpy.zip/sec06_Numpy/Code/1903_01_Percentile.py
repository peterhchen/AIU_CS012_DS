import numpy as np 
a = np.array([[30,40,70],[80,20,10],[50,90,60]]) 
print('a:')
print(a)
print()
#a:
#[[30 40 70]
# [80 20 10]
# [50 90 60]] 

print('np.percentile(a, 0):') 
print(np.percentile(a, 0)) 
print()
#np.percentile(a, 0):
# 0 => 0% to compute
#10.0

print('np.percentile(a, 50):') 
print(np.percentile(a, 50)) 
print()
#np.percentile(a, 50):
# 50 => 50% to compute
#50.0

print('np.percentile(a, 100):') 
print(np.percentile(a, 100)) 
print()
#np.percentile(a, 50):
# 100 => 100% to compute
#90.0

print('np.percentile(a, 50, axis = 1):')
print(np.percentile(a, 50, axis = 1))
print()
# np.percentile(a, 50, axis = 1):
# [40. 20. 60.]

print('np.percentile(a,50, axis = 0):')
print(np.percentile(a, 50, axis = 0))
#np.percentile(a, 50, axis = 0):
#[50. 40. 60.]