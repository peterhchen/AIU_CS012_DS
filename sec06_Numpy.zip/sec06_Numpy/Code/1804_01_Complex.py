import numpy as np 
a = np.array([-5.6j, 0.2j, 11. , 1+1j]) 

print('a:', a) 
print()  
# a: [-0.-5.6j  0.+0.2j 11.+0.j   1.+1.j ]

print('np.real(a):', np.real(a))
print()  
# np.real(a): [-0.  0. 11.  1.]

print('np.imag(a):', np.imag(a))
print()
# np.imag(a): [-5.6  0.2  0.   1. ]

print('np.conj(a):', np.conj(a))
print()
# np.conj(a): [-0.+5.6j  0.-0.2j 11.-0.j   1.-1.j ]

print('Applying angle() function (result in radian):')
print('np.angle(a, deg = True):', np.angle(a))
print()
#Applying angle() function (result in radian):
#np.angle(a, deg = True): [-1.57079633  1.57079633  0.          0.78539816]

print('Applying angle() function (result in degrees):') 
print('np.angle(a, deg = True):', np.angle(a, deg = True))
#Applying angle() function (result in degrees):
#np.angle(a, deg = True): [-90.  90.   0.  45.]