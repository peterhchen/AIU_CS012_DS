import numpy as np 
a = np.array([[30,40,0],[0,20,10],[50,0,60]]) 
print('a:')
print(a) 
print() 
#a:
#[[30 40  0]
# [ 0 20 10]
# [50  0 60]]

print('Applying nonzero() to get nonzero element index:')
print('np.nonzero(a):')
print(np.nonzero(a))
#Applying nonzero() to get nonzero element index:
#np.nonzero(a):
#(array([0, 0, 1, 1, 2, 2], dtype=int64), 
# array([0, 1, 1, 2, 0, 2], dtype=int64))