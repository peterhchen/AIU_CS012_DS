import numpy as np 
a = np.array([[3,7,5],[8,4,3],[2,4,9]]) 

print('a:')
print(a)
print()
#a:
#[[3 7 5]
# [8 4 3]
# [2 4 9]]

print('Point-to-point to all elements => np.ptp(a):')
print(np.ptp(a))
print()
#Point-to-point to all elements => np.ptp(a):
#max element = 9, min element = 2, point-to-point = 9-2 = 7
#7

print('Point-to-point to axis = 1 => np.ptp(a, axis = 1):') 
print(np.ptp(a, axis = 1)) 
print()   
#Point-to-point to axis = 1 => np.ptp(a, axis = 1):
#axis = 1 (horizontal): 
# 1) max-min = 7 - 3 = 4
# 2) max-min = 8 - 3 = 5
# 3) max-min = 9 -2 = 7
#[4 5 7]

print('Point-to-point to axis = 0 => np.ptp(a, axis = 0):') 
print(np.ptp(a, axis = 0))
#Point-to-point to axis = 0 => np.ptp(a, axis = 0):
#axis = 0 (vertical)
# 1) max - min = 8 -2 = 6
# 2) max - min = 7 -4 = 3
# 3) max - min = 9 -3 = 6
#[6 3 6]