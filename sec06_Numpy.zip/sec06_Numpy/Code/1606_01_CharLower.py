import numpy as np 
print(np.char.lower(['HELLO','WORLD']))
# ['hello' 'world']
print(np.char.lower('HELLO'))
# hello