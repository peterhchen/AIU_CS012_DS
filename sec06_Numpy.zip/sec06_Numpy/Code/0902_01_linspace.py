import numpy as np 
x = np.linspace(10,20,5) 
print('x:', x)
# x: [10.  12.5 15.  17.5 20. ]