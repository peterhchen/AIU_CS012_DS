# file name can be used to access content of age column 
import numpy as np 

dt = np.dtype([('age',np.int8)]) 
a = np.array([(10,),(20,),(30,)], dtype = dt)
print('dt:')
print(dt)
print()
print('a:')
print(a)
print()
print("a['age']:")
print(a['age'])