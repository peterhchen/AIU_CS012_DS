#!/usr/bin/python

str = 'Hello World!'

print('str:', str)                   # Prints complete string
# str: Hello Wold!
print('str[0]:', str[0])             # Prints first character of the string
# str[0]: H
print('str[2:5]:', str[2:5])         # Prints characters starting from 3rd to 5th
# str[2:5]: llo
# Python inde started from 0 and end with ')', i.e., [2, 5).
print('str[2:]:', str[2:])           # Prints string starting from 3rd character
# str[2:]: llo World!
# [2: stop at end]
print('str * 2:', str * 2)           # Prints string two times
# str * 2: Hello World!Hello World!
print('str + "TEST":', str + "TEST") # Prints concatenated string
# str + "TEST": Hello World!TEST