#!/usr/bin/python

a = 20
b = 10
c = 15
d = 5
e = 0
print('a =', a)
print('b =', b)
print('c =', c)
print('d =', d)
print('e =', e)
e = (a + b) * c / d       #( 30 * 15 ) / 5
print("Value of (a + b) * c / d =",  e)

e = ((a + b) * c) / d     # (30 * 15 ) / 5
print("Value of ((a + b) * c) / d =",  e)

e = (a + b) * (c / d);    # (30) * (15/5)
print("Value of (a + b) * (c / d) =",  e)

e = a + (b * c) / d;      #  20 + (150/5)
print("Value of a + (b * c) / d =",  e)