#!/usr/bin/python

a = 10; b = 20; list = [1, 2, 3, 4, 5 ]
print('a =', a)
print('b =', b)
print('list =', list); print()
if (a in list):
    print('if (a in list):')
else:
    print('if (a in list) else:')

if (b not in list):
    print('if (b not in list):')
else:
    print('if (b not in list) else:')

print()
a = 2
print('a =', a)
print('list =', list); print()
if (a in list):
    print('if (a in list):')
else:
    print('if (a in list) else:')