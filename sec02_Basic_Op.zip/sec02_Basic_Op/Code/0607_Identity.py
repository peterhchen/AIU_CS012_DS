#!/usr/bin/python
a = 20
b = 20
print('a:', a); print('hex(id(a)):', hex(id(a)))
print('b:', b); print('hex(id(b)):', hex(id(b)))
if (a is b):
    print ("a and b have same identity (same memory location)")
else:
    print ("a and b do not have same identity (same memory location)")
if (id(a) == id(b)):
    print ("a and b have same identity (same memory location)")
else:
    print ("a and b do not have same identity (same memory location)")
b = 30
print('a:', a); print('hex(id(a)):', hex(id(a)))
print('b:', b); print('hex(id(b)):', hex(id(b)))
if (a is b):
    print ("a and b have same identity (same memory location)")
else:
    print ("a and b do not have same identity (same memory location)")

if (a is not b):
    print ("a and b do not have same identity (same memory location)")
else:
    print ("a and b have same identity (same memory location)")