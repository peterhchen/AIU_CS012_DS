#!/usr/bin/python
a = 21; b = 10; c = 0
print("a =", a, '; b =', b, '; c =', c)
c = a + b
print("c = a + b =", c)
c = a - b
print("c = a - b =", c)
c = a * b
print("c = a * b = ", c) 
c = a / b
print("c = a / b =", c) 
c = a % b
print("c = a % b =", c) 
a = 2; b = 3; c = a**b
print("a =", a, '; b =', b)
print('c = a ** b = ', c)
a = 10; b = 5; c = a//b 
print("a =", a, '; b =', b)
print('c = a//b =', c)
print('9//2 =', 9//2)
print('9.0//2.0 =', 9.0//2.0)
print('-11//3 =', -11//3)
print('-11.0//3.0 =', -11.0//3.0)
# a = 21 ; b = 10 ; c = 0
# c = a + b = 31
# c = a - b = 11
# c = a * b =  210
# c = a / b = 2.1
# c = a % b = 1
# a = 2 ; b = 3
# c = a ** b =  8
# a = 10 ; b = 5
# c = a//b = 2
# 9//2 = 4
# 9.0//2.0 = 4.0
# -11//3 = -4
# -11.0//3.0 = -4.0