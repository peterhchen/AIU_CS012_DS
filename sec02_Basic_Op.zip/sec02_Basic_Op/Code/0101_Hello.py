"""
File Name: 0101_Hello.py
"""
print("Hello, Python!")
