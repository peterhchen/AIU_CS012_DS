'''
Telusko 
'''
def topten():
   # yield make funciton into generator
   print ('yield 1')
   yield 1
   print ('yield 2')
   yield 2
   print ('yield 3')
   yield 3
   print ('yield 4')
   yield 4
   print ('yield 5')
   yield 5
   
values = topten()

print('print values.__next__()')
print (values.__next__())
print()

print('print values.__next__()')
print (values.__next__())
print()

print('for i in values')
for i in values:
   print ('i: ', i)

