# content of test_class.py
class Person:
    age = 23
    name = "Adam"

class TestClass:
    def test_one(self):
        x = "this"
        assert "t" in x

    def test_two(self):
        person = Person()
        assert hasattr(person, "age")