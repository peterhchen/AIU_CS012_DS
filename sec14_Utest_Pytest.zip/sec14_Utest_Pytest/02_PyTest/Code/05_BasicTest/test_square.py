import math

def test_sqrt():
   num = 25
   assert math.sqrt(num) == 5

def testsquare():
   num = 7
   assert 7*7 == 49

def tesequality():
   assert 10 == 11

# all files must be test*py or *test.py
# >pytest
#============================= test session starts =============================
#platform win32 -- Python 3.7.6, pytest-7.1.2, pluggy-1.0.0
#rootdir: C:\Work\SVU\012_Python_Data_Science\sec15_Pytest\Code\05_test
#plugins: anyio-2.2.0
#collected 2 items
#
#test_square.py .F                                                        [100%]
#
#================================== FAILURES ===================================
#_________________________________ testsquare __________________________________
#
#    def testsquare():
#       num = 7
#>      assert 7*7 == 40
#E      assert (7 * 7) == 40
#
#test_square.py:9: AssertionError
#=========================== short test summary info ===========================
#FAILED test_square.py::testsquare - assert (7 * 7) == 40
#========================= 1 failed, 1 passed in 0.12s =========================
