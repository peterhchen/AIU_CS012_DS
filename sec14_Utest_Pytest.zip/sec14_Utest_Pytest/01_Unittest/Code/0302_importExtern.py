import unittest
# from funs import * => NG
from funcs.add import *

# import mod.module => NG
from mod import module

class SimpleTest(unittest.TestCase):
   def test_add1(self):
        print('test_add1()')
        self.assertEqual(add(4,5),9)
   def test_add2(self):
        print('test_add2()')
        self.assertEqual(add(10,20),30)
   def test_mod3(self):
        print('test_mod3()')
        object = module.GFG()
        print(object.add(15, 5))
        print(object.sub(15, 5))
        module.method()

if __name__ == '__main__':
   unittest.main()