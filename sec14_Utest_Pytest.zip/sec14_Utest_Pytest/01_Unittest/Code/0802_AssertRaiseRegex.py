import unittest
import re

class raiseTest(unittest.TestCase):
    def testraiseRegex1(self):
        with self.assertRaisesRegex(ValueError, 'literal'):
            int('XYZ')

    def testraiseRegex2(self):
        self.assertRaisesRegex(ValueError, "invalid literal for .*XYZ'$", int, 'XYZ')

    def testraiseRegex3(self):
        self.assertRaisesRegex(ValueError, "invalid literal for XYZ", int, 'XYZ')

    def testraiseRegex4(self):
        self.assertRaisesRegex(ValueError, "invalid literal for .*", int, 'XYZ')

    def testraiseRegex5(self):
        self.assertRaisesRegex(ValueError, "invalid literal for .*", int, 'ABC')

    #def testraiseRegex3(self):
    #    self.assertRaisesRegex(ValueError, reg, "TutorialsPoint", "Point")

    #def testraiseRegex3(self):
    #    self.assertRaisesRegexp(TypeError, "invalid", regex, "Point", "TutorialsPoint")

    #def testraiseRegex4(self):
    #    self.assertRaisesRegexp(TypeError, "invalid", regex, 123, "TutorialsPoint")
      
if __name__ == '__main__':
   unittest.main()