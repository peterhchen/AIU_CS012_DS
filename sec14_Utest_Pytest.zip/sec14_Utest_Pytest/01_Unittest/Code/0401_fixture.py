import unittest

class simpleTest2(unittest.TestCase):
   def setUp(self):
      print('\ndef setup...')
      self.a = 10
      self.b = 20
      # Get description in the test_add/test_sub
      name = self.shortDescription()
      print('  name: ', name)
      if name == "Add":
         print('  if name == Add...')
         self.a = 40
         self.b = 60
         print("  ", name, self.a, self.b)
      if name == "sub":
         print('  if name == sub...')
         self.a = 50
         self.b = 60
         print("  ", name, self.a, self.b)

   def tearDown(self):
      print('\ndef tearDown...')
      # Print end of test funciton name
      print('end of test', self.shortDescription())

   def test_add(self):
      """Add"""
      print('  def test_add...')
      result = self.a+self.b
      self.assertTrue(result == 100)

   def test_sub(self):
      """sub"""
      print('  def test_sub...')
      result = self.a-self.b
      self.assertTrue(result == -10)
      
if __name__ == '__main__':
   print('unittest.main()...')
   unittest.main()