import unittest
class Test1():
   print('Test1')

class Test2():
   print('Test2')

if __name__ == '__main__':
   testList = [Test1, Test2]
   testLoad = unittest.TestLoader()

   TestList = []
   for testCase in testList:
      testSuite = testLoad.loadTestsFromTestCase(testCase)
      TestList.append(testSuite)

   newSuite = unittest.TestSuite(TestList)
   runner = unittest.TextTestRunner()
   runner.run(newSuite)