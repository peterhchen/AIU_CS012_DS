import unittest
def add(x,y):
   return x + y
   
class SimpleTest(unittest.TestCase):
   def test_add1(self):
        print('test_add1()')
        self.assertEqual(add(4,5),9)
   def test_add2(self):
        print('test_add2()')
        self.assertEqual(add(10,20),9)
      
if __name__ == '__main__':
   unittest.main()