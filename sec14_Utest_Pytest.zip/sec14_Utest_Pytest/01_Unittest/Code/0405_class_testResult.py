import unittest
class suiteTest(unittest.TestCase):
   def setUp(self):
      self.a = 10
      self.b = 20
      
   def testadd(self):
      """Add"""
      result = self.a+self.b
      self.assertTrue(result == 30)
   def testsub(self):
      """sub"""
      result = self.a-self.b
      self.assertTrue(result == -10)
      
def suite():
   suite = unittest.TestSuite()
##   suite.addTest (simpleTest3("testadd"))
##   suite.addTest (simpleTest3("testsub"))
   suite.addTest(unittest.makeSuite(suiteTest))
   return suite

if __name__ == '__main__':
   runner = unittest.TextTestRunner()
   test_suite = suite()
   result = runner.run (test_suite)
   
   print("---- START OF TEST RESULTS")
   print()

   print('result:')
   print(result)
   # <unittest.runner.TextTestResult run=2 errors=0 failures=0>
   print()

   # Print error list.
   print("result.errors")
   print(result.errors)
   # []
   print()

   # Print failure list.
   print("result.failures")
   print(result.failures)
   # []
   print()

   print("result.skipped")
   print(result.skipped)
   # []
   print()

   print("result.wasSuccessful")
   print(result.wasSuccessful())
   # True
   print()
   
   print("result.testRun")
   print(result.testsRun)
   # 2
   print()
   print("---- END OF TEST RESULTS")