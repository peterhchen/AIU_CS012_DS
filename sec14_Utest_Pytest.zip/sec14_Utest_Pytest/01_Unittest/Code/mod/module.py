class GFG:
      
    # methods
    def add(self, a, b):
        return a + b
    def sub(self, a, b):
        return a - b
  
# explicit function      
def method():
    print("GFG")