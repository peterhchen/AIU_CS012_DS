import matplotlib.pyplot as plt
fig = plt.figure()
ax1 = fig.add_subplot(111)
#ax1.plot([1, 2, 3, 7, 9])
x = [1, 2, 3, 4, 5]
y = [1, 2, 3, 7, 9]
ax1.scatter(x, y)
ax2 = fig.add_subplot(224, facecolor='y')
# ax2.plot([5, 4 , 3, 2, 1])
x = [1, 2, 3, 4, 5]
y = [5, 4 , 3, 2, 1]
ax2.scatter(x, y)
plt.show()