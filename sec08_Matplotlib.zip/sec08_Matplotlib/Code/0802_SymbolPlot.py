from pylab import *
x = linspace(-3, 3, 30)
y = x**2
plot(x, y, 'r.')
show()