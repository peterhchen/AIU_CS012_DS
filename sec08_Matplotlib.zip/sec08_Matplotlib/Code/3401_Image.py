import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
img = mpimg.imread('mtplogo.png')

plt.imsave("logo.png", img, cmap = 'gray', origin = 'lower')

imgplot = plt.imshow(img)
# Turn off the axis plot
plt.axis('off')
plt.show()