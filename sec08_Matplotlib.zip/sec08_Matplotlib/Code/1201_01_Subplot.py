import matplotlib.pyplot as plt
# plot a line, implicitly creating a subplot(111)
# now create a subplot which represents the top plot of a grid 
# with 2 rows and 1 column.
# Since this subplot will overlap the first, the plot (and its axes) 
# previously created will be removed.
plt.subplot(211)
# plt.plot(range(12))
val1 = [1, 2, 3]
print('val1:', val1)
# val1: [1, 2, 3]
# plt.plot(val1)
plt.scatter(val1, val1)
plt.subplot(212, facecolor='y') # creates 2nd subplot with yellow background
val2 = range(12)
print('val2:', val2)
# val2: range(0, 12)
# plt.plot(val2)
plt.scatter(val2, val2)
plt.show()