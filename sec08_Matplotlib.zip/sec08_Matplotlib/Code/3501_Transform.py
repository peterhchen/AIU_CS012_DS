import matplotlib.pyplot as plt
fig = plt.figure()

ax = fig.add_axes([0.1,0.1,0.8,0.8])
x = 0
y = 0
ax.text(x,y,"my label") 
ax.text(0.5, 0.5, "middle of graph", transform=ax.transAxes)

plt.show()