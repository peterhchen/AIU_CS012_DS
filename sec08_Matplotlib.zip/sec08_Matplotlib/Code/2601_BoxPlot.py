import numpy as np
import matplotlib.pyplot as plt
np.random.seed(10)
collectn_1 = np.random.normal(100, 10, 200)
# mean (center of distribution), std (standard deviation), 
# number of point
collectn_2 = np.random.normal(80, 30, 200)
collectn_3 = np.random.normal(90, 20, 200)
collectn_4 = np.random.normal(70, 25, 200)
# Create 2-D numpy array for above 4 array.
data_to_plot =[collectn_1, collectn_2, collectn_3, collectn_4]
print('len(data_to_plot):', len(data_to_plot))
# 4
fig = plt.figure()
# Create an axes instance
ax = fig.add_axes([0.1,0.1,0.8,0.8])
# Create the boxplot
bp = ax.boxplot(data_to_plot)
plt.show()