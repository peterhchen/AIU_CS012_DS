"""
File Name: run_primes_cython.py
Usage:
> python run_primes_cython.py
"""
import primes
print('primes.primes(10):', primes.primes(10))