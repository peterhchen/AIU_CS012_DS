"""
File Name: setup.py
0722/2022 by Peter Hanping Chen
"""
from setuptools import setup
from Cython.Build import cythonize

setup(
    ext_modules=cythonize("primes.pyx")
)
