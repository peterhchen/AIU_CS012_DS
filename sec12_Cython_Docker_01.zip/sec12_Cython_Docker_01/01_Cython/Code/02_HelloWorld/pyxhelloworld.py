# pyximport
import pyximport; pyximport.install()
import helloworld
# Hello World