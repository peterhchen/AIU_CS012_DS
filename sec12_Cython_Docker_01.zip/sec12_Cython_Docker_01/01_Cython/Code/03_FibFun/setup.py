"""
File Name: setup.py
07/22/2022 by Peter Hanping Chen
"""
from setuptools import setup
from Cython.Build import cythonize

setup(
    ext_modules=cythonize("fib.pyx")
)
