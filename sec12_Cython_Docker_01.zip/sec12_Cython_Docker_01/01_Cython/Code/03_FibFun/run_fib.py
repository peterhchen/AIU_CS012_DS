"""
File Name: run_fib.py
Usage:
 > python run_fib.py
07/22/2022 by Peter Hanping Chen
"""
import fib
fib.fib(2000)
