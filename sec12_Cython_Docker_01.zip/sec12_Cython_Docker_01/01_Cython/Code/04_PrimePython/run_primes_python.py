"""
File Name: run_primes.py
Usage:
> python run_primes.py
"""
import primes
print('primes.primes(10):', primes.primes(10))