# https://cython.readthedocs.io/en/latest/src/tutorial/cython_tutorial.html#the-basics-of-cython
1. conda install Cython
2. Create primes.py
"""
File Name: primes.py
0722/2022 by Peter Hanping Chen
"""
import cython
def primes(nb_primes: cython.bint):
    """
    Description: Find prime number by python.
    bint: big number integer.
    """
    i: cython.bint
    prime_num: cython.bint[1000]

    if nb_primes > 1000:
        nb_primes = 1000

    if not cython.compiled:  # Only if regular Python is running
        prime_num = [0] * 1000       # Make p work almost like a C array

    len_p: cython.bint = 0  # The current number of elements in p.
    num: cython.bint = 2
    while len_p < nb_primes:
        # Is n prime?
        for i in prime_num[:len_p]:
            if num % i == 0:
                break
        # If no break occurred in the loop, we have a prime.
        else:
            prime_num[len_p] = num
            len_p += 1
        num += 1

    # Let's copy the result into a Python list:
    result_as_list = [prime for prime in prime_num[:len_p]]
    return result_as_list
    return result_as_list

2. Create run_primpes.py
"""
File Name: run_primes.py
Usage:
> python run_primes.py
"""
import primes
print('primes.primes(10):', primes.primes(10))

5. run run_primes.py
> python run_primes.py
>> primes.primes(10): [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
