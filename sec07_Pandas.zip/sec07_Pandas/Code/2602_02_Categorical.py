import pandas as pd

cat = pd.Categorical(['a','b','c','a','b','c','d'], ['c', 'b', 'a'])
print("cat = pd.Categorical(['a','b','c','a','b','c','d'], ['c', 'b', 'a']) => cat:")
print(cat)
# cat = pd.Categorical(['a','b','c','a','b','c','d'], ['c', 'b', 'a']) => cat:
# ['a', 'b', 'c', 'a', 'b', 'c', NaN]
# Categories (3, object): ['c', 'b', 'a']