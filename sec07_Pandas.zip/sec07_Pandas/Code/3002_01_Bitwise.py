import pandas as pd

s = pd.Series(range(5))
print('s==4:')
print(s==4)
# s==4:
#0    False
#1    False
#2    False
#3    False
#4     True