import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame(np.random.rand(10,4),columns=['a','b','c','d'])
print('df:')
print(df)

#df.plot.bar()
#df.plot.bar(stacked=True)
df.plot.barh(stacked=True)
plt.legend(loc='best')
plt.show()
#df:
#          a         b         c         d
#0  0.580708  0.448731  0.452601  0.544430
#1  0.660511  0.825601  0.763954  0.251606
#2  0.757377  0.092984  0.617309  0.148957
#3  0.746642  0.989345  0.167670  0.736057
#4  0.418521  0.078570  0.366153  0.822303
#5  0.457671  0.832347  0.414426  0.606060
#6  0.413479  0.890841  0.396959  0.201221
#7  0.678273  0.331890  0.389984  0.603856
#8  0.215558  0.803317  0.144001  0.688245
#9  0.670581  0.995927  0.263743  0.407385