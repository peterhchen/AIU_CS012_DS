import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(6, 4), \
    columns=['one', 'two', 'three','four'],
    index=list('abcdef'))

print('df:')
print(df)
# df.iloc() is for intger
# df.loc() is for string
print("df.loc[['b', 'c', 'e']]:")
print(df.loc[['b', 'c', 'e']])
#df:
#        one       two     three      four
#a  0.255419 -0.374753 -0.416210 -1.298792
#b -0.493146 -1.577486  0.035168 -2.048028
#c  0.159410 -1.126479 -1.753728  0.354041
#d -0.848503 -0.672221  0.887795 -0.069042
#e  1.554566  0.088586 -0.632540  0.917263
#f -0.409462 -0.672316  0.561242 -0.557272
#df.loc[['b', 'c', 'e']]:
#        one       two     three      four
#b -0.493146 -1.577486  0.035168 -2.048028
#c  0.159410 -1.126479 -1.753728  0.354041
#e  1.554566  0.088586 -0.632540  0.917263