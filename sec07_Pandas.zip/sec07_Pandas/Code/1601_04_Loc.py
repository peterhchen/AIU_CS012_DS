# import the pandas library and aliasing as pd
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), \
    index = ['a','b','c'], columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#          A         B         C         D
#a -0.361317  1.320211 -1.692919 -0.594006
#b  1.140091  1.656664  1.593205  0.176645
#c -1.036174  1.119249 -0.349026 -0.664762

# Select range of rows for all columns
print("df.loc['a':'b']:")
print(df.loc['a':'h'])
#df.loc['a':'b']:
#          A         B         C         D
#a -0.361317  1.320211 -1.692919 -0.594006
#b  1.140091  1.656664  1.593205  0.176645
#c -1.036174  1.119249 -0.349026 -0.664762