import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f', 'h'],columns=['one', 'two', 'three'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  0.595480 -1.517846  0.610140
#c -1.635478 -0.461865  1.424152
#e -0.217344 -0.705341 -0.544446
#f  0.473557  0.240591  0.034018
#h  0.455413 -0.005380 -0.289023

df1 = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print('df1:')
print(df1)
print()
#df1:
#        one       two     three
#a  0.595480 -1.517846  0.610140
#b       NaN       NaN       NaN
#c -1.635478 -0.461865  1.424152
#d       NaN       NaN       NaN
#e -0.217344 -0.705341 -0.544446
#f  0.473557  0.240591  0.034018
#g       NaN       NaN       NaN
#h  0.455413 -0.005380 -0.289023

print("df1.fillna(method='backfill'):")
print(df1.fillna(method='backfill'))
#df1.fillna(method='backfill'):
#        one       two     three
#a  0.595480 -1.517846  0.610140
#b -1.635478 -0.461865  1.424152
#c -1.635478 -0.461865  1.424152
#d -0.217344 -0.705341 -0.544446
#e -0.217344 -0.705341 -0.544446
#f  0.473557  0.240591  0.034018
#g  0.455413 -0.005380 -0.289023
#h  0.455413 -0.005380 -0.289023