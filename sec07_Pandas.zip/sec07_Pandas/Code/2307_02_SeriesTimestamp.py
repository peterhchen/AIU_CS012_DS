import pandas as pd
print("pd.to_datetime(['2005/11/23', '2010.12.31', None]):")
print(pd.to_datetime(['2005/11/23', '2010.12.31', None]))
# pd.to_datetime(['2005/11/23', '2010.12.31', None]):
# DatetimeIndex(
# ['2005-11-23', '2010-12-31', 'NaT'], 
# dtype='datetime64[ns]', freq=None)