import pandas as pd

# url = 'https://raw.github.com/pandasdev/pandas/master/pandas/tests/data/tips.csv'
#tips=pd.read_csv(url)
# Remove extra space for the string.
tips = pd.read_csv('tips.csv', delimiter=',', encoding="utf-8", skipinitialspace=True)

print('tips:')
print(tips)
print("tips['time']:")
print(tips['time'])
print("tips[tips['time'] == 'Dinner'].head(5):")
print(tips[tips['time'] == 'Dinner'].head(5))
#tips:
#   total_bill   tip     sex smoker  day    time  size
#0       16.99  1.01  Female     No  Sun  Dinner     2
#1       10.34  1.66    Male     No  Sun  Dinner     3
#2       21.01  3.50    Male     No  Sun  Dinner     3
#3       23.68  3.31    Male     No  Sun  Dinner     2
#4       24.59  3.61  Female     No  Sun  Dinner     4
#tips['time']:
#0    Dinner
#1    Dinner
#2    Dinner
#3    Dinner
#4    Dinner
#Name: time, dtype: object
#tips[tips['time'] == 'Dinner'].head(5):
#   total_bill   tip     sex smoker  day    time  size
#0       16.99  1.01  Female     No  Sun  Dinner     2
#1       10.34  1.66    Male     No  Sun  Dinner     3
#2       21.01  3.50    Male     No  Sun  Dinner     3
#3       23.68  3.31    Male     No  Sun  Dinner     2
#4       24.59  3.61  Female     No  Sun  Dinner     4