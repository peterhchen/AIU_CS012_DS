import pandas as pd
import numpy as np

N=5

df = pd.DataFrame({
   'A': pd.date_range(start='2016-01-01',periods=N,freq='D'),
   'x': np.linspace(0,stop=N-1,num=N),
   'y': np.random.rand(N),
   'C': np.random.choice(['Low','Medium','High'],N).tolist(),
   'D': np.random.normal(100, 10, size=(N)).tolist()  # mean=100, scale=10, size=N
})

print('df:')
print(df)
print()
#df:
#           A    x         y       C           D
#0 2016-01-01  0.0  0.910376  Medium  104.857248
#1 2016-01-02  1.0  0.154090    High  106.323644
#2 2016-01-03  2.0  0.827133    High   95.174018
#3 2016-01-04  3.0  0.564382    High   95.004047
#4 2016-01-05  4.0  0.448345     Low  107.884314

#reindex the DataFrame
df_reindexed = df.reindex(index=[0,2,5], columns=['A', 'C', 'B'])
print('df_reindexed:')
print(df_reindexed)
#df_reindexed:
#           A       C   B
#0 2016-01-01  Medium NaN
#2 2016-01-03    High NaN
#5        NaT     NaN NaN