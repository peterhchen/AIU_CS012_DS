import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 4),
   index = pd.date_range('1/1/2000', periods=5),
   columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#                   A         B         C         D
#2000-01-01  0.037124 -0.083053  0.950747 -0.745525
#2000-01-02  0.075439  1.415283  0.442880  1.749594
#2000-01-03  0.277670 -1.763860 -0.716751  1.648673
#2000-01-04  0.558138  0.089366 -0.855394 -0.401138
#2000-01-05 -1.237622 -0.203914  1.266678 -0.641895

r = df.rolling(window=3,min_periods=1)
print("r['A'].aggregate([np.sum,np.mean]):")
print(r['A'].aggregate([np.sum,np.mean]))
#r['A'].aggregate([np.sum,np.mean]):
#                 sum      mean
#2000-01-01  0.037124  0.037124
#2000-01-02  0.112563  0.056281
#2000-01-03  0.390232  0.130077
#2000-01-04  0.911246  0.303749
#2000-01-05 -0.401815 -0.133938