# import the pandas library and aliasing as pd
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), \
    index = ['a','b','c'], \
    columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#          A         B         C         D
#a  0.171951 -0.714909 -0.872266  0.217798
#b -2.358308 -1.112452 -0.669672 -0.217491
#c -1.438103 -1.926428 -0.402580  0.515564

# Select all rows for multiple columns, say list[]
print("df.loc[:,['A','C']]:")
print(df.loc[:,['A','C']])
#df.loc[:,['A','C']]:
#          A         C
#a  0.171951 -0.872266
#b -2.358308 -0.669672
#c -1.438103 -0.402580