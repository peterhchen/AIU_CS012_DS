import pandas as pd

#cat = pd.Series([1,2,3]).astype("category", categories=[1,2,3], ordered=True)
#cat1 = pd.Series([2,2,2]).astype("category", categories=[1,2,3], ordered=True)
cat = pd.Categorical([1,2,3], dtype="category", categories=[1,2,3], ordered=True)
cat1 = pd.Categorical([2,2,2], dtype="category", categories=[1,2,3], ordered=True)
print("cat > cat1:")
print(cat > cat1)
#cat > cat1:
#[False False  True]