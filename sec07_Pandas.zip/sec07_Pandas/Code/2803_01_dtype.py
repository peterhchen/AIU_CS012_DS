import numpy as np
import pandas as pd

df = pd.read_csv("temp.csv", dtype={'Salary': np.float64})
print('df:')
print(df)
print()
print('df.dtypes:')
print(df.dtypes)
# df:
#   S.No    Name  Age       City   Salary
#0     1     Tom   28    Toronto  20000.0
#1     2     Lee   32   HongKong   3000.0
#2     3  Steven   43   Bay Area   8300.0
#3     4     Ram   38  Hyderabad   3900.0
#
#df.dtypes:
#S.No        int64
#Name       object
#Age         int64
#City       object
#Salary    float64
#dtype: object