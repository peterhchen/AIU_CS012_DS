import pandas as pd
import numpy as np

# My custom function
df = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0 -0.551335 -0.125935  0.414969
#1 -1.318144  2.682857  1.882356
#2 -0.414760 -1.157571  1.076861
#3 -0.004303  0.789826 -1.322770
#4 -1.327291  1.254367 -0.580240

df1 = df.applymap(lambda x:x*100)
print('df1 = df.applymap(lambda x:x*100)=> df1')
print('df1:')
print(df1)
print()
#df1 = df.applymap(lambda x:x*100)=> df1
#df1:
#         col1        col2        col3
#0  -55.133504  -12.593549   41.496935
#1 -131.814415  268.285684  188.235593
#2  -41.476004 -115.757097  107.686109
#3   -0.430303   78.982556 -132.277024
#4 -132.729144  125.436734  -58.023966

print('df1.mean(axis=0):')
print(df1.mean(axis=0))
print()
#df1.mean(axis=0):
#col1   -72.316674
#col2    68.870866
#col3    29.423529
#dtype: float64

print('df1.mean(axis=1):')
print(df1.mean(axis=1))
# df1.mean(axis=1):
#0     -8.743373
#1    108.235621
#2    -16.515664
#3    -17.908257
#4    -21.772125
#dtype: float64