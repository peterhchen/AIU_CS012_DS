# import the pandas library
import pandas as pd
import numpy as np

ipl_data = {'Team': ['Riders', 'Riders', 'Devils', 'Devils', 'Kings',
   'kings', 'Kings', 'Kings', 'Riders', 'Royals', 'Royals', 'Riders'],
   'Rank': [1, 2, 2, 3, 3,4 ,1 ,1,2 , 4,1,2],
   'Year': [2014,2015,2014,2015,2014,2015,2016,2017,2016,2014,2015,2017],
   'Points':[876,789,863,673,741,812,756,788,694,701,804,690]}
df = pd.DataFrame(ipl_data)
print('df:')
print(df)
print()
#df:
#      Team  Rank  Year  Points
#0   Riders     1  2014     876
#1   Riders     2  2015     789
#2   Devils     2  2014     863
#3   Devils     3  2015     673
#4    Kings     3  2014     741
#5    kings     4  2015     812
#6    Kings     1  2016     756
#7    Kings     1  2017     788
#8   Riders     2  2016     694
#9   Royals     4  2014     701
#10  Royals     1  2015     804
#11  Riders     2  2017     690

grouped = df.groupby('Team')
score = lambda x: (x - x.mean()) / x.std()*10
print("grouped.transform(score):")
print(grouped.transform(score))
#grouped.transform(score):
#         Rank       Year     Points
#0  -15.000000 -11.618950  12.843272
#1    5.000000  -3.872983   3.020286
#2   -7.071068  -7.071068   7.071068
#3    7.071068   7.071068  -7.071068
#4   11.547005 -10.910895  -8.608621
#5         NaN        NaN        NaN
#6   -5.773503   2.182179  -2.360428
#7   -5.773503   8.728716  10.969049
#8    5.000000   3.872983  -7.705963
#9    7.071068  -7.071068  -7.071068
#10  -7.071068   7.071068   7.071068
#11   5.000000  11.618950  -8.157595