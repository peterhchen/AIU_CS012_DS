import pandas as pd

s = pd.Series(["a","b","c","a"], dtype="category")
print('s = pd.Series(["a","b","c","a"], dtype="category") => s:')
print(s)
# s = pd.Series(["a","b","c","a"], dtype="category") => s:
#0    a
#1    b
#2    c
#3    a
#dtype: category
#Categories (3, object): ['a', 'b', 'c']

s.cat.categories = ["Group %s" % g for g in s.cat.categories]
print('s.cat.categories = ["Group %s" % g for g in s.cat.categories] => s.cat.categories')
print(s.cat.categories)
#s.cat.categories = ["Group %s" % g for g in s.cat.categories] => s.cat.categories
#Index(['Group a', 'Group b', 'Group c'], dtype='object')