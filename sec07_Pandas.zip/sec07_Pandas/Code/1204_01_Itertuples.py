import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3,3),columns = ['col1','col2','col3'])
print('df:')
print(df)
print()
# df:
#       col1      col2      col3
#0 -0.232569 -0.589663  0.791413
#1 -0.336428  1.420031  0.061707
#2  0.153770  0.107526  0.792070

for row in df.itertuples():
    print(row)
#Pandas(Index=0, col1=-0.23256942237346298, col2=-0.5896633423895739, col3=0.7914134666295003)
#Pandas(Index=1, col1=-0.33642812616999945, col2=1.4200313497628683, col3=0.06170744214068075)
#Pandas(Index=2, col1=0.15377031651684325, col2=0.10752563992814139, col3=0.7920695364897458)