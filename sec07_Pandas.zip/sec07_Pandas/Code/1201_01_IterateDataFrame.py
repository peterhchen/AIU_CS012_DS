import pandas as pd
import numpy as np
 
N=5
df = pd.DataFrame({
   'A': pd.date_range(start='2016-01-01',periods=N,freq='D'),
   'x': np.linspace(0,stop=N-1,num=N),
   'y': np.random.rand(N),
   'C': np.random.choice(['Low','Medium','High'],N).tolist(),
   'D': np.random.normal(100, 10, size=(N)).tolist()
   })
print('df:')
print(df)
print()
# df:
#           A    x         y     C           D
#0 2016-01-01  0.0  0.958339  High  105.611232
#1 2016-01-02  1.0  0.289819   Low  111.118493
#2 2016-01-03  2.0  0.006969   Low   95.490117
#3 2016-01-04  3.0  0.094138   Low   96.857927
#4 2016-01-05  4.0  0.851828  High   97.014832

for col in df:
   print('col:', col, end=" ")
# col: A col: x col: y col: C col: D