import pandas as pd
import numpy as np

cat = pd.Categorical(["a", "c", "c", np.nan], categories=["b", "a", "c"])
df = pd.DataFrame({"cat": cat, "s":["a", "c", "c", np.nan]})
print('cat:')
print(cat)
print('df:')
print(df)
print('df.describe():')
print(df.describe())
print('df["cat"].describe():')
print(df["cat"].describe())

#cat:
#['a', 'c', 'c', NaN]
#Categories (3, object): ['b', 'a', 'c']

#df:
#   cat    s
#0    a    a
#1    c    c
#2    c    c
#3  NaN  NaN

#df.describe():
#       cat  s
#count    3  3
#unique   2  2
#top      c  c
#freq     2  2

#df["cat"].describe():
#count     3
#unique    2
#top       c
#freq      2
#Name: cat, dtype: object