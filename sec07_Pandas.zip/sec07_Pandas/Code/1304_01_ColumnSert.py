import pandas as pd
import numpy as np
 
unsorted_df = pd.DataFrame(np.random.randn(5,2),index=[1,4,5,2,3],
columns = ['col2','col1'])
print('unsorted_df:')
print(unsorted_df)
print()
#unsorted_df:
#       col2      col1
#1 -0.405157  2.244861
#4  0.445541  0.226343
#5 -0.340116 -1.899017
#2  0.133372  0.900689
#3 -0.107401  0.285773

sorted_df=unsorted_df.sort_index(axis=1)
print('sorted_df:')
print(sorted_df)
#sorted_df:
#       col1      col2
#1  2.244861 -0.405157
#4  0.226343  0.445541
#5 -1.899017 -0.340116
#2  0.900689  0.133372
#3  0.285773 -0.107401