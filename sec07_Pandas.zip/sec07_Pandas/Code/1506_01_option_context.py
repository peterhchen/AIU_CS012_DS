import pandas as pd
with pd.option_context("display.max_rows", 10):
    print(pd.get_option("display.max_rows"))
with pd.option_context("display.max_columns", 20):
    print(pd.get_option("display.max_columns"))