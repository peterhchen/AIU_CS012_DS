import pandas as pd
import numpy as np
 
df1 = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
df2 = pd.DataFrame(np.random.randn(2,3),columns=['col1','col2','col3'])
print('df1:')
print(df1)
print('df2:')
print(df2)
print()
#df1:
#       col1      col2      col3
#0 -0.311001 -0.293799 -0.280518
#1  1.476924 -0.796240 -0.525512
#2  0.958433  0.138626  0.909842
#3 -1.335579 -0.222764  0.730245
#4 -0.445080 -0.241763 -1.392146
#df2:
#       col1      col2      col3
#0 -0.576618  0.042990 -0.545876
#1 -0.970270 -1.639192 -0.120723

# Padding NAN's
print('df2.reindex_like(df1):')
print(df2.reindex_like(df1))
#df2.reindex_like(df1):
#       col1      col2      col3
#0 -0.576618  0.042990 -0.545876
#1 -0.970270 -1.639192 -0.120723
#2       NaN       NaN       NaN
#3       NaN       NaN       NaN
#4       NaN       NaN       NaN

# Now Fill the NAN's with preceding Values
print("Data Frame with Forward Fill limiting to 1:")
print("df2.reindex_like(df1,method='ffill',limit=1):")
print(df2.reindex_like(df1,method='ffill',limit=1))
#Data Frame with Forward Fill limiting to 1:
#df2.reindex_like(df1,method='ffill',limit=1):
#       col1      col2      col3
#0 -0.576618  0.042990 -0.545876
#1 -0.970270 -1.639192 -0.120723
#2 -0.970270 -1.639192 -0.120723
#3       NaN       NaN       NaN
#4       NaN       NaN       NaN