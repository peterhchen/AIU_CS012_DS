import pandas as pd
import numpy as np

s = pd.Series(np.random.randn(5), index=list('abcde'))
print('s:')
print(s)
print()
#s:
#a   -1.288616
#b   -0.796138
#c   -0.420076
#d   -0.643183
#e   -0.074045
#dtype: float64

s['d'] = s['b'] # so there's a tie
print("s['d'] = s['b'] => s:")
print(s)
print()
#s['d'] = s['b'] => s:
#a   -1.288616
#b   -0.796138
#c   -0.420076
#d   -0.796138
#e   -0.074045
#dtype: float64

print('s.rank():')
print(s.rank())
#s.rank():
#a    1.0
#b    2.5
#c    4.0
#d    2.5
#e    5.0
#dtype: float64