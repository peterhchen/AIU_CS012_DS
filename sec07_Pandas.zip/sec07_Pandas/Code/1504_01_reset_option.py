import pandas as pd
print('pd.reset_option("display.max_rows"):')
pd.reset_option("display.max_rows")
print('pd.get_option("display.max_rows"):')
print(pd.get_option("display.max_rows"))
print('pd.reset_option("display.max_columns"):')
pd.reset_option("display.max_columns")
print('pd.get_option("display.max_columns"):')
print(pd.get_option("display.max_columns"))
# pd.reset_option("display.max_rows"):
#pd.get_option("display.max_rows"):
#60
#pd.reset_option("display.max_columns"):
#pd.get_option("display.max_columns"):
#0