import pandas as pd

print("pd.date_range('1/1/2011', periods=5):")
print(pd.date_range('1/1/2011', periods=5))
# pd.date_range('1/1/2011', periods=5):
# DatetimeIndex(
# ['2011-01-01', 
#  '2011-01-02', 
#  '2011-01-03', 
#  '2011-01-04',
#  '2011-01-05'],
# dtype='datetime64[ns]', freq='D')