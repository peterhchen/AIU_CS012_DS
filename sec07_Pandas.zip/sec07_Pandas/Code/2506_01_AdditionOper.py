import pandas as pd

s = pd.Series(pd.date_range('2012-1-1', periods=3, freq='D'))
td = pd.Series([ pd.Timedelta(days=i) for i in range(3) ])
df = pd.DataFrame(dict(A = s, B = td))
print('s:')
print(s)
print('td:')
print(td)
print("df = pd.DataFrame(dict(A = s, B = td)) => df:")
print(df)
df['C'] = df['A'] + df['B']

print("df['C'] = df['A'] + df['B'] => df:")
print(df)

#s:
#0   2012-01-01
#1   2012-01-02
#2   2012-01-03
#dtype: datetime64[ns]
#td:
#0   0 days
#1   1 days
#2   2 days
#dtype: timedelta64[ns]
#df = pd.DataFrame(dict(A = s, B = td)) => df:
#           A      B
#0 2012-01-01 0 days
#1 2012-01-02 1 days
#2 2012-01-03 2 days
#df['C'] = df['A'] + df['B'] => df:
#           A      B          C
#0 2012-01-01 0 days 2012-01-01
#1 2012-01-02 1 days 2012-01-03
#2 2012-01-03 2 days 2012-01-05