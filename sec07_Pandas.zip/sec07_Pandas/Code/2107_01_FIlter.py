import pandas as pd
import numpy as np

ipl_data = {'Team': ['Riders', 'Riders', 'Devils', 'Devils', 'Kings',
   'kings', 'Kings', 'Kings', 'Riders', 'Royals', 'Royals', 'Riders'],
   'Rank': [1, 2, 2, 3, 3,4 ,1 ,1,2 , 4,1,2],
   'Year': [2014,2015,2014,2015,2014,2015,2016,2017,2016,2014,2015,2017],
   'Points':[876,789,863,673,741,812,756,788,694,701,804,690]}
df = pd.DataFrame(ipl_data)
print('df:')
print(df)
print()
# df:
#      Team  Rank  Year  Points
#0   Riders     1  2014     876
#1   Riders     2  2015     789
#2   Devils     2  2014     863
#3   Devils     3  2015     673
#4    Kings     3  2014     741
#5    kings     4  2015     812
#6    Kings     1  2016     756
#7    Kings     1  2017     788
#8   Riders     2  2016     694
#9   Royals     4  2014     701
#10  Royals     1  2015     804
#11  Riders     2  2017     690
print("df.groupby('Team').filter(lambda x: len(x) >= 3):")
print(df.groupby('Team').filter(lambda x: len(x) >= 3))
#df.groupby('Team').filter(lambda x: len(x) >= 3):
#      Team  Rank  Year  Points
#0   Riders     1  2014     876
#1   Riders     2  2015     789
#4    Kings     3  2014     741
#6    Kings     1  2016     756
#7    Kings     1  2017     788
#8   Riders     2  2016     694
#11  Riders     2  2017     690