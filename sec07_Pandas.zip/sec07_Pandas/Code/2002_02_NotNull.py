import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f', 'h'],
    columns=['one', 'two', 'three'])

df = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  1.609864  1.803421  1.215396
#b       NaN       NaN       NaN
#c  0.845760  0.975221  0.404301
#d       NaN       NaN       NaN
#e  0.020922 -1.327222  1.384226
#f -0.600460 -0.433437  0.055453
#g       NaN       NaN       NaN
#h -0.124449  2.171253  0.322529

print("df['one'].notnull():")
print(df['one'].notnull())
#df['one'].notnull():
#a     True
#b    False
#c     True
#d    False
#e     True
#f     True
#g    False
#h     True
#Name: one, dtype: bool