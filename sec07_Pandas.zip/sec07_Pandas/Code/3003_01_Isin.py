import pandas as pd

s1 = pd.Series(list('abc'))
print('s1:')
print(s1)
s = s1.isin(['a', 'c', 'e'])
print ('s:')
print(s)
# s1:
#0    a
#1    b
#2    c
#dtype: object
#s:
#0     True
#1    False
#2     True
#dtype: bool