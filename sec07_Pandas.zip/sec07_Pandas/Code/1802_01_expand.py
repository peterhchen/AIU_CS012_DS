import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 4),
   index = pd.date_range('1/1/2000', periods=5),
   columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#                   A         B         C         D
#2000-01-01 -0.014966 -0.273825  0.083425 -0.781571
#2000-01-02 -0.071511 -0.647063 -1.250526 -0.068605
#2000-01-03 -0.600629  1.387822  1.718703 -0.424769
#2000-01-04  1.028448 -0.549327 -1.050256  1.035853
#2000-01-05 -2.349471  1.156761  0.467595 -1.541485

print('df.expanding(min_periods=3).mean():')
print(df.expanding(min_periods=3).mean())
#df.expanding(min_periods=3).mean():
#                   A         B         C         D
#2000-01-01       NaN       NaN       NaN       NaN
#2000-01-02       NaN       NaN       NaN       NaN
#2000-01-03 -0.229035  0.155645  0.183867 -0.424981
#2000-01-04  0.085335 -0.020598 -0.124663 -0.059773
#2000-01-05 -0.401626  0.214873 -0.006212 -0.356115