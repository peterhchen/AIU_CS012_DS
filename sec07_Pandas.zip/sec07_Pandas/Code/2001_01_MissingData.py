# import the pandas library
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f', 'h'],
    columns=['one', 'two', 'three'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  0.564658 -0.099309  0.410023
#c  1.425040 -0.647189  2.151780
#e  0.599921 -0.463499  0.165683
#f  0.278370  0.422956 -0.037622
#h -0.170335  0.718225 -0.242167

df = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print("df = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']) => df:")
print(df)

#df = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']) => df:
#        one       two     three
#a  0.564658 -0.099309  0.410023
#b       NaN       NaN       NaN
#c  1.425040 -0.647189  2.151780
#d       NaN       NaN       NaN
#e  0.599921 -0.463499  0.165683
#f  0.278370  0.422956 -0.037622
#g       NaN       NaN       NaN
#h -0.170335  0.718225 -0.242167