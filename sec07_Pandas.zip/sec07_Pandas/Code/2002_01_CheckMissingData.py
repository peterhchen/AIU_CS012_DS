import pandas as pd
import numpy as np
 
df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f','h'],
    columns=['one', 'two', 'three'])
print("df:")
print(df)
print()
#df:
#        one       two     three
#a  0.671710  1.653654  0.316523
#c -0.471403 -0.923238 -0.393050
#e -1.448317 -0.206094  0.140528
#f -0.229780 -0.316281  2.372614
#h -1.581762 -0.082704 -0.188563

df = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print("df['one'].isnull():")
print(df['one'].isnull())
#df['one'].isnull():
#a    False
#b     True
#c    False
#d     True
#e    False
#f    False
#g     True
#h    False
#Name: one, dtype: bool