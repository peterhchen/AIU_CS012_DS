import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame(np.random.rand(10, 5), columns=['A', 'B', 'C', 'D', 'E'])
df.plot.box()

print('df:')
print(df)

#plt.legend(loc='best')
plt.show()
#df:
#          A         B         C         D         E
#0  0.498300  0.568278  0.581309  0.542958  0.922261
#1  0.532286  0.515577  0.978618  0.781093  0.636230
# ...
#8  0.868703  0.093121  0.708535  0.312337  0.161593
#9  0.238071  0.941007  0.428578  0.197223  0.702795