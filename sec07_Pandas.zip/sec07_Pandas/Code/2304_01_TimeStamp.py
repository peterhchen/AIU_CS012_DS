import pandas as pd

print(pd.Timestamp('2017-03-01'))
# 2017-03-01 00:00:00