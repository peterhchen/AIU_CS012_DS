import pandas as pd
import numpy as np

df = pd.DataFrame(index=[0,1,2,3,4,5],columns=['one','two'])
print('df:')
print(df)
print()
#df:
#   one  two
#0  NaN  NaN
#1  NaN  NaN
#2  NaN  NaN
#3  NaN  NaN
#4  NaN  NaN
#5  NaN  NaN

print("df['one'].sum():")
print(df['one'].sum())
#df['one'].sum():
#0