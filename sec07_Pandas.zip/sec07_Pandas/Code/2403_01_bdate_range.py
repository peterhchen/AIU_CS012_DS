import pandas as pd

print("pd.date_range('06/27/2011', periods=5):")
print(pd.date_range('06/27/2011', periods=5))
# pd.date_range('06/27/2012', periods=5):
# DatetimeIndex(
# ['2011-06-27', 
# '2011-06-28', 
# '2011-06-29', 
# '2011-06-30',
# '2011-07-01'],
# dtype='datetime64[ns]', freq='D')