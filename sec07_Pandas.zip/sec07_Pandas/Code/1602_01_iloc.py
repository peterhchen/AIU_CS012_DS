# import the pandas library and aliasing as pd
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#          A         B         C         D
#0  1.252903  0.197207  0.559041  1.922688
#1 -0.247746  0.100270 -0.341747  0.876021
#2  0.149565  0.171480  0.365050 -0.814507

# select all columns for a specific range of rows.
print('df.iloc[:2]:')
print(df.iloc[:2])
#df.iloc[:2]:
#          A         B         C         D
#0  1.252903  0.197207  0.559041  1.922688
#1 -0.247746  0.100270 -0.341747  0.876021