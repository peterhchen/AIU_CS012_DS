import pandas as pd
pd.set_option('display.max_columns', 30)
print("pd.set_option('display.max_columns', 30):")
# pd.set_option("display.max_columns", 30)
print('pd.get_option("display.max_columns"):')
print(pd.get_option("display.max_columns"))
# print(pd.get_option("display.max_columns"))
# 30