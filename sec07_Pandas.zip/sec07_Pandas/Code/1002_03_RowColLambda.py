import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5,3), columns=['col1','col2','col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0  0.964525 -0.514934 -0.202790
#1  1.338143  1.712780  1.084956
#2 -0.621587 -0.326122 -0.532890
#3 -0.140840 -0.246930  1.277183
#4  0.327504  0.555941 -1.454710

df1 = df.apply(lambda x: x.max() - x.min())
print('df1 = df.apply(lambda x: x.max() - x.min()) => df1:')
print(df1)
print()
# df1 = df.apply(lambda x: x.max() - x.min()) => df1:
#col1    1.959730
#col2    2.227714
#col3    2.731893
#dtype: float64
print('df1.mean(axis=0):')
print(df1.mean(axis=0))
# df1.mean(axis=0):
# 2.952505820872636