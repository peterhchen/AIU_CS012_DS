import pandas as pd
import numpy as np

def adder(ele1,ele2):
   return ele1 + ele2

df = pd.DataFrame (np.random.randn (5, 3), columns=['col1', 'col2', 'col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0 -0.545614  0.483185  1.523186
#1 -0.546308  1.938292  0.787562
#2  1.305886 -0.539594 -0.686861
#3  0.399684 -0.317812 -1.299052
#4  0.368119  0.681112  0.173665

print('df1 = df.pipe(adder,2) => df1:')
df1 = df.pipe(adder,2)
print('df1:')
print(df1)
print()
#df1 = df.pipe(adder,2) => df1:
#df1:
#       col1      col2      col3
#0  1.454386  2.483185  3.523186
#1  1.453692  3.938292  2.787562
#2  3.305886  1.460406  1.313139
#3  2.399684  1.682188  0.700948
#4  2.368119  2.681112  2.173665

print('df1.apply(np.mean):')
print(df1.apply(np.mean))
#df1.apply(np.mean):
#col1    2.196353
#col2    2.449036
#col3    2.099700
#dtype: float64