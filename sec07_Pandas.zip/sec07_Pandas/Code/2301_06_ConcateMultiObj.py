import pandas as pd

one = pd.DataFrame({
   'Name': ['Alex', 'Amy', 'Allen'],
   'subject_id':['sub1','sub2','sub4'],
   'Marks_scored':[98,90,87]},
   index=[1,2,3])

two = pd.DataFrame({
   'Name': ['Billy', 'Brian'],
   'subject_id':['sub2','sub4'],
   'Marks_scored':[89,80]},
   index=[1,2])
print('one:')
print(one)
print('two:')
print(two)
print('one.append([two,one,two]):')
print(one.append([one, two]))
#one:
#    Name subject_id  Marks_scored
#1   Alex       sub1            98
#2    Amy       sub2            90
#3  Allen       sub4            87
#two:
#    Name subject_id  Marks_scored
#1  Billy       sub2            89
#2  Brian       sub4            80
#one.append([two,one,two]):
#    Name subject_id  Marks_scored
#1   Alex       sub1            98
#2    Amy       sub2            90
#3  Allen       sub4            87
#1  Billy       sub2            89
#2  Brian       sub4            80
#1   Alex       sub1            98
#2    Amy       sub2            90
#3  Allen       sub4            87
#1  Billy       sub2            89
#2  Brian       sub4            80