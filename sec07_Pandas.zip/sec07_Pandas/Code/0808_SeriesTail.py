import pandas as pd
import numpy as np

#Create a series with 4 random numbers
s = pd.Series(np.random.randn(4))
print("The original series is:")
print('s:')
print(s)
print()

print("The last two rows of the data series:")
print('s.tail(2):')
print(s.tail(2))