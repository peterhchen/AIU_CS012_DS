import datetime
import pandas as pd
start = datetime.datetime(2022, 6, 27)
end = datetime.datetime(2022, 7, 3)

print('pd.date_range(start, end):')
print(pd.date_range(start, end))
# pd.date_range(start, end):
#DatetimeIndex(
# ['2022-06-27', '2022-06-28', '2022-06-29', 
# '2022-06-30', '2022-07-01', '2022-07-02', 
# '2022-07-03'],
# dtype='datetime64[ns]', freq='D')