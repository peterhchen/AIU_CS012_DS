import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 4),
   index = pd.date_range('1/1/2000', periods=5),
   columns = ['A', 'B', 'C', 'D'])

print('df:')
print(df)
print()
# df:
#                   A         B         C         D
#2000-01-01 -0.559973  0.379641 -0.792921  0.730999
#2000-01-02 -1.262405  0.013895 -1.246120 -1.293238
#2000-01-03 -0.510565 -0.014226 -0.500800 -1.385263
#2000-01-04  1.300175  1.227833  2.039858  0.414744
#2000-01-05  0.743850 -0.527635  0.775894  1.653977

r = df.rolling(window=3,min_periods=1)
print('r:')
print(r)
#r:
#Rolling [window=3,min_periods=1,center=False,axis=0,method=single]