import pandas as pd
import numpy as np
s1 = pd.Series(np.random.randn(5))
s2 = pd.Series(np.random.randn(5))
print('s1:')
print(s1)
print('s2:')
print(s2)
print('s1.cov(s2):')
print(s1.cov(s2))
#s1:
#0   -0.053564
#1    1.465152
#2   -0.718941
#3    0.133049
#4   -0.705935
#dtype: float64
#s2:
#0   -0.290983
#1   -0.020859
#2    1.466392
#3   -2.740409
#4   -0.068456
#dtype: float64
#s1.cov(s2):
#-0.33647100731781077