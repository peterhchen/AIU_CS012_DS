import pandas as pd
print("pd.Series([True]).bool():")
print(pd.Series([True]).bool())
# pd.Series([True]).bool():
# True