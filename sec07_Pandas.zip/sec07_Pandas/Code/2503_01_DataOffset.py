import pandas as pd
print("pd.Timedelta(days=2):")
print(pd.Timedelta(days=2))
# pd.Timedelta(days=2):
# 2 days 00:00:00