import pandas as pd
print("pd.to_datetime(pd.Series(['Jul 31, 2009','2010-01-10', None])):")
print(pd.to_datetime(pd.Series(['Jul 31, 2009','2010-01-10', None])))
#pd.to_datetime(pd.Series(['Jul 31, 2009','2010-01-10', None])):
#0   2009-07-31
#1   2010-01-10
#2          NaT
#dtype: datetime64[ns]