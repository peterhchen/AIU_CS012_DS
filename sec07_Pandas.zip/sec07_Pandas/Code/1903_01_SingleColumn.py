import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 4),
   index = pd.date_range('1/1/2000', periods=5),
   columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
# df:
#                   A         B         C         D
#2000-01-01 -0.071790  1.291453 -0.815269 -0.137610
#2000-01-02  0.518255  1.276039  1.388524 -0.322487
#2000-01-03  0.455716  0.597330 -0.544986 -0.470130
#2000-01-04  1.978058 -0.841368 -1.093730 -0.613426
#2000-01-05  0.056797  0.116258  0.269869 -0.865776

r = df.rolling(window=3,min_periods=1)
print("r['A'].aggregate(np.sum):")
print(r['A'].aggregate(np.sum))
#r['A'].aggregate(np.sum):
#2000-01-01   -0.071790
#2000-01-02    0.446465
#2000-01-03    0.902181
#2000-01-04    2.952028
#2000-01-05    2.490570
#Freq: D, Name: A, dtype: float64