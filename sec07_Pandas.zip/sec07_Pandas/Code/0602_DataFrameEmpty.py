#import the pandas library and aliasing as pd
import pandas as pd
df = pd.DataFrame()
print('df:')
print(df)