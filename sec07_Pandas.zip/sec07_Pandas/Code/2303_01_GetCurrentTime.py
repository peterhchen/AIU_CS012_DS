# Getting current date and time using now().
# https://www.geeksforgeeks.org/get-current-date-and-time-using-python/
# importing datetime module for now()
import datetime
 
# using now() to get current time
current_time = datetime.datetime.now()
 
# Printing value of now.
print("Time now at greenwich meridian is:", current_time)
# Time now at greenwich meridian is: 2022-06-25 11:39:55.146175
