import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 4),
   index = pd.date_range('1/1/2000', periods=5),
   columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#                   A         B         C         D
#2000-01-01  0.367078  0.776532  0.509265 -3.126885
#2000-01-02 -0.134110 -0.556604  1.372728  1.273441
#2000-01-03  1.061830 -0.613294  0.579594 -2.293937
#2000-01-04 -1.255914  0.393790 -0.846575  0.155144
#2000-01-05  0.018358  1.488466  1.673016  0.523597

r = df.rolling(window=3,min_periods=1)
print("r[['A','B']].aggregate(np.sum):")
print(r[['A','B']].aggregate(np.sum))
#r[['A','B']].aggregate(np.sum):
#                   A         B
#2000-01-01  0.367078  0.776532
#2000-01-02  0.232968  0.219928
#2000-01-03  1.294797 -0.393366
#2000-01-04 -0.328194 -0.776108
#2000-01-05 -0.175727  1.268962