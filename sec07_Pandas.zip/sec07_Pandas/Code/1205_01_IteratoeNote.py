import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3),columns = ['col1','col2','col3'])
print('df:')
print(df)
print()

for index, row in df.iterrows():
    print(index, row)
    row['a'] = 10
print('df:')
print(df)