import pandas as pd
import numpy as np
df = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
print("df:")
print(df)
print()
#df:
#       col1      col2      col3
#0  0.630018 -0.367300 -0.124104
#1 -0.516748 -0.249727  0.613852
#2 -2.228508 -0.233567  1.811450
#3 -1.646168  0.745933  0.450453
#4  1.251233 -0.637705 -0.750963
# My custom function
df1 = df['col1'].map(lambda x:x*100)
print("df1 = df['col1'].map(lambda x:x*100) => df1:")
print('df1:')
print(df1)
print()
#df1 = df['col1'].map(lambda x:x*100) => df1:
#df1:
#0     63.001823
#1    -51.674806
#2   -222.850811
#3   -164.616753
#4    125.123302
#Name: col1, dtype: float64

print('df1.mean(axis=0):')
print(df1.mean(axis=0))
print()
#df1.mean(axis=0):
#-50.20344917446622

print('df1.mean():')
print(df1.mean())
#df1.mean():
#-50.20344917446622