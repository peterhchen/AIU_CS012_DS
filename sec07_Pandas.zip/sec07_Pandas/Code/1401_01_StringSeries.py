import pandas as pd
import numpy as np

s = pd.Series(['Tom', 'William Rick', 'John', 'Alber@t', np.nan, '1234','SteveSmith'])
print('s:')
print(s)
# s:
#0             Tom
#1    William Rick
#2            John
#3         Alber@t
#4             NaN
#5            1234
#6      SteveSmith
#dtype: object