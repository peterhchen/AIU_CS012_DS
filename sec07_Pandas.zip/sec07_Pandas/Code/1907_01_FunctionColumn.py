import pandas as pd
import numpy as np
 
df = pd.DataFrame(np.random.randn(3, 4),
   index = pd.date_range('1/1/2000', periods=3),
   columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
# df:
#                   A         B         C         D
#2000-01-01 -0.383341  0.231148  0.180676  0.422169
#2000-01-02 -0.552522 -0.918185 -0.409656 -0.360762
#2000-01-03 -0.104972 -0.923513  0.829061 -0.804445

r = df.rolling(window=3,min_periods=1)
print("r.aggregate({'A' : np.sum,'B' : np.mean}):")
print(r.aggregate({'A' : np.sum,'B' : np.mean}))
#r.aggregate({'A' : np.sum,'B' : np.mean}):
#                   A         B
#2000-01-01 -0.383341  0.231148
#2000-01-02 -0.935863 -0.343519