#import the pandas library and aliasing as pd
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), \
    index = ['a','b','c'], \
    columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
# df:
#          A         B         C         D
#a -0.668752  0.252279 -2.153068  0.353126
#b  0.312900 -0.544136  1.425885  1.932690
#c  0.380104  0.732771  1.261570  0.096294

#select all rows for a specific column
print("df.loc[:,'A']:")
print(df.loc[:,'A'])
# df.loc[:,'A']:
#a   -0.668752
#b    0.312900
#c    0.380104
#Name: A, dtype: float64