import pandas as pd
import numpy as np

unsorted_df = pd.DataFrame(np.random.randn(5,2),index=[1,4,5,2,3],
columns = ['col2','col1'])
print('unsorted_df:')
print(unsorted_df)
print()
#unsorted_df:
#        col2      col1
#1 -0.663603 -0.712848
#4  0.948679  0.730670
#5  0.230344 -0.361902
#2 -0.425024  0.564361
#3  2.051617  0.346228
sorted_df=unsorted_df.sort_index()
print('sorted_df:')
print(sorted_df)
#sorted_df:
#       col2      col1
#1 -0.663603 -0.712848
#2 -0.425024  0.564361
#3  2.051617  0.346228
#4  0.948679  0.730670
#5  0.230344 -0.361902