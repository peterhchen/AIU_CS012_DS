import pandas as pd
import numpy as np

df1 = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
print('df1:')
print(df1)
#df1:
#       col1      col2      col3
#0 -0.241130 -0.736008  0.263537
#1 -0.719492 -0.175096 -0.065471
#2  0.683370  0.534339 -1.620026
#3  0.418613 -0.587240  0.221492
#4  0.240968  0.088937 -0.102105
print("After renaming the rows and columns:")
print("df1.rename(columns={'col1' : 'c1', 'col2' : 'c2'}, \
index = {0 : 'apple', 1 : 'banana', 2 : 'durian'}):")
print(df1.rename(columns={'col1' : 'c1', 'col2' : 'c2'},
index = {0 : 'apple', 1 : 'banana', 2 : 'durian'}))
#After renaming the rows and columns:
#df1.rename(columns={'col1' : 'c1', 'col2' : 'c2'}, 
# index = {0 : 'apple', 1 : 'banana', 2 : 'durian'}):
#              c1        c2      col3
#apple  -0.241130 -0.736008  0.263537
#banana -0.719492 -0.175096 -0.065471
#durian  0.683370  0.534339 -1.620026
#3       0.418613 -0.587240  0.221492
#4       0.240968  0.088937 -0.102105