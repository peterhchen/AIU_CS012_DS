import pandas as pd

s = pd.Series(["a","b","c","a"], dtype="category")
print("Original object:")
print(s)

print("After removal:")
print('s.cat.remove_categories("a"):')
print(s.cat.remove_categories("a"))
#Original object:
#0    a
#1    b
#2    c
#3    a
#dtype: category
#Categories (3, object): ['a', 'b', 'c']

#After removal:
#s.cat.remove_categories("a"):
#0    NaN
#1      b
#2      c
#3    NaN
#dtype: category
#Categories (2, object): ['b', 'c']