import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f', 'h'],
    columns=['one', 'two', 'three'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  0.205042  0.231910  2.311770
#c -0.612057 -0.363450 -1.114007
#e  0.580059 -1.200973 -1.396617
#f  1.162791 -0.742522 -0.035793
#h -0.348401  2.213013 -0.786095

df1 = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print('df1:')
print(df1)
print()
#df1:
#        one       two     three
#a  0.205042  0.231910  2.311770
#b       NaN       NaN       NaN
#c -0.612057 -0.363450 -1.114007
#d       NaN       NaN       NaN
#e  0.580059 -1.200973 -1.396617
#f  1.162791 -0.742522 -0.035793
#g       NaN       NaN       NaN
#h -0.348401  2.213013 -0.786095

print("df1.dropna():")
print(df1.dropna())
#df1.dropna():
#        one       two     three
#a  0.205042  0.231910  2.311770
#c -0.612057 -0.363450 -1.114007
#e  0.580059 -1.200973 -1.396617
#f  1.162791 -0.742522 -0.035793
#h -0.348401  2.213013 -0.786095