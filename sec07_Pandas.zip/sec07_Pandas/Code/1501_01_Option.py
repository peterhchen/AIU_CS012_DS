import pandas as pd

print('pd.get_option("display.max_rows"):')
print(pd.get_option("display.max_rows"))
# pd.get_option("display.max_rows"):
# 60