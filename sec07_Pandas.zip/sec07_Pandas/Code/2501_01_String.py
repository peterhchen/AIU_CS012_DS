import pandas as pd
print("pd.Timedelta('2 days 2 hours 15 minutes 30 seconds'):")
print(pd.Timedelta('2 days 2 hours 15 minutes 30 seconds'))
# pd.Timedelta('2 days 2 hours 15 minutes 30 seconds'):
# 2 days 02:15:30