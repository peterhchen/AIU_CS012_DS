import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame({'a':np.random.randn(1000)+1,'b':np.random.randn(1000),'c':
np.random.randn(1000) - 1}, columns=['a', 'b', 'c'])

df.plot.hist(bins=20)
print('df:')
print(df)

plt.legend(loc='best')
plt.show()
#df:
#            a         b         c
#0    2.402690 -0.625775 -1.088732
#1   -0.412428 -0.040541 -2.090343
#..        ...       ...       ...
#998  0.485637 -0.133320 -0.747012
#999  1.832144  0.672287 -2.510538
#
#[1000 rows x 3 columns]