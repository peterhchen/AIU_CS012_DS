import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame(3 * np.random.rand(4), index=['a', 'b', 'c', 'd'], columns=['x'])
df.plot.pie(subplots=True)

print('df:')
print(df)

#plt.legend(loc='best')
plt.show()
#df:
#          x
#a  2.475386
#b  1.008070
#c  0.776435
#d  2.403125