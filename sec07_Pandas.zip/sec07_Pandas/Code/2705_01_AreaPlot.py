import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
df.plot.area()

print('df:')
print(df)

#plt.legend(loc='best')
plt.show()
#df:
#          a         b         c         d
#0  0.032248  0.493126  0.205891  0.926358
#1  0.730318  0.764642  0.708085  0.642080
#...
#8  0.477513  0.123512  0.432986  0.408594
#9  0.621928  0.141023  0.906665  0.352259