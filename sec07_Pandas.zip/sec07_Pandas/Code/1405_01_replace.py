import pandas as pd
s = pd.Series(['Tom ', ' William Rick', 'John', 'Alber@t'])
print('s:', s)
print()
#s: 0             Tom
#1     William Rick
#2             John
#3          Alber@t
#dtype: object

print("After replacing @ with $:")
print(s.str.replace('@','$'))
#After replacing @ with $:
#0             Tom
#1     William Rick
#2             John
#3          Alber$t
#dtype: object