import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0  1.180461  0.084170 -0.354636
#1 -1.140248  1.114551  0.549630
#2 -0.226819 -0.201601  0.036968
#3 -0.809288 -1.711187  0.138210
#4  0.884005  0.769331  0.488786

df1 = df.apply(np.mean)
print('df1:')
print(df1)
#df1:
#col1   -0.022378
#col2    0.011053
#col3    0.171791
#dtype: float64