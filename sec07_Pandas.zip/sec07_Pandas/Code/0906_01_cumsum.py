import numpy as np
import pandas as pd
s = pd.Series([2, np.nan, 5, -1, 0])
print('s:')
print(s)
print()
# s:
#0    2.0
#1    NaN
#2    5.0
#3   -1.0
#4    0.0
print('s.cumsum():')
print(s.cumsum())
print()
#0    2.0
#1    NaN
#2    7.0
#3    6.0
#4    6.0
#dtype: float64
print('s.cumprod():')
print(s.cumprod())
#0     2.0
#1     NaN
#2    10.0
#3   -10.0
#4    -0.0
#dtype: float64
