import pandas as pd

df=pd.read_csv("temp.csv", index_col=['S.No'])
print('df:')
print(df)
# df:
# df:
#        Name  Age       City  Salary
#S.No
#1        Tom   28    Toronto   20000
#2        Lee   32   HongKong    3000
#3     Steven   43   Bay Area    8300
#4        Ram   38  Hyderabad    3900