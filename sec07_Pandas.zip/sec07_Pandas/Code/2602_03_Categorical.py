import pandas as pd

cat = pd.Categorical(['a','b','c','a','b','c','d'], ['c', 'b', 'a'], ordered=True)
print("cat = pd.Categorical(['a','b','c','a','b','c','d'], ['c', 'b', 'a'], ordered=True) => cat:")
print(cat)
#cat = pd.Categorical(['a','b','c','a','b','c','d'], ['c', 'b', 'a'], ordered=True) => cat:
#['a', 'b', 'c', 'a', 'b', 'c', NaN]
#Categories (3, object): ['c' < 'b' < 'a']