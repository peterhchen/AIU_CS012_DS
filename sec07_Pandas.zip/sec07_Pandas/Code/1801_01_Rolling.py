import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 4),
   index = pd.date_range('1/1/2000', periods=5),
   columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
# df:
#                   A         B         C         D
#2000-01-01 -0.031693 -0.231953  0.081461  0.724989
#2000-01-02 -0.278111 -0.554121  0.014564  1.225930
#2000-01-03  0.303583 -0.065504  1.637036  0.466520
#2000-01-04  0.907631 -1.066102 -0.955149  0.649808
#2000-01-05 -0.482379 -0.010191  1.398239 -0.755367

print('df.rolling(window=3).mean():')
print(df.rolling(window=3).mean())
#df.rolling(window=3).mean():
#                   A         B         C         D
#2000-01-01       NaN       NaN       NaN       NaN
#2000-01-02       NaN       NaN       NaN       NaN
#2000-01-03 -0.002074 -0.283859  0.577687  0.805813
#2000-01-04  0.311034 -0.561909  0.232150  0.780753
#2000-01-05  0.242945 -0.380599  0.693376  0.120320