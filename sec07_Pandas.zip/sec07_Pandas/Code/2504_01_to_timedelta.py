import pandas as pd
print("pd.to_timedelta(days=2):")
print(pd.to_timedelta([1, 2, 3], unit='s'))
# pd.to_timedelta(days=2):
# TimedeltaIndex(
# ['0 days 00:00:01', '0 days 00:00:02', '0 days 00:00:03'], 
# dtype='timedelta64[ns]', freq=None)