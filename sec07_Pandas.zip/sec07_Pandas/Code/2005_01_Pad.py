import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f','h'],columns=['one', 'two', 'three'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  1.295239  1.343611  0.140443
#c  0.343611  2.620314  1.890433
#e  0.844696 -0.628811 -1.900864
#f  0.999177  0.878742  0.872693
#h  0.743654  2.345529 -0.216452

df1 = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print('df1:')
print(df1)
print()
#df1:
#        one       two     three
#a  1.295239  1.343611  0.140443
#b       NaN       NaN       NaN
#c  0.343611  2.620314  1.890433
#d       NaN       NaN       NaN
#e  0.844696 -0.628811 -1.900864
#f  0.999177  0.878742  0.872693
#g       NaN       NaN       NaN
#h  0.743654  2.345529 -0.216452

print("df1.fillna(method='pad'):")
print(df1.fillna(method='pad'))
#df1.fillna(method='pad'):
#        one       two     three
#a  1.295239  1.343611  0.140443
#b  1.295239  1.343611  0.140443
#c  0.343611  2.620314  1.890433
#d  0.343611  2.620314  1.890433
#e  0.844696 -0.628811 -1.900864
#f  0.999177  0.878742  0.872693
#g  0.999177  0.878742  0.872693
#h  0.743654  2.345529 -0.216452