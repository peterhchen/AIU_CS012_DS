import pandas as pd
import numpy as np

df1 = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
df2 = pd.DataFrame(np.random.randn(2,3),columns=['col1','col2','col3'])
print('df1:')
print(df1)
#df1:
#       col1      col2      col3
#0  0.541744 -0.245219  2.044012
#1 -0.730516  1.769222 -0.084411
#2  0.049004  0.296910  0.859785
#3  0.174085  3.030768 -1.331890
#4 -0.767573 -1.715317 -0.088283
print('df2:')
print(df2)
print()
#df2:
#       col1      col2      col3
#0 -0.546415 -0.389128 -0.797401
#1 -0.957783  0.078680  0.111380

df1 = df1.reindex_like(df2)
print('df1 = df1.reindex_like(df2) => df1:')
print(df1)
#df1 = df1.reindex_like(df2) => df1:
#       col1      col2      col3
#0  0.541744 -0.245219  2.044012
#1 -0.730516  1.769222 -0.084411