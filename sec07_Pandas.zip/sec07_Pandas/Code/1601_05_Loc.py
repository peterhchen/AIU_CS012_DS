# import the pandas library and aliasing as pd
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), \
    index = ['a','b','c'], columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#          A         B         C         D
#a  0.321058  0.662535 -0.408499  0.761635
#b -0.142088 -0.086398  0.665316  0.189804
#c -0.044768  0.496268  2.725239 -0.320905

# for getting values with a boolean array
print("df.loc['a'] > 0")
print(df.loc['a'] > 0)
#df.loc['a'] > 0
#A     True
#B     True
#C    False
#D     True
#Name: a, dtype: bool