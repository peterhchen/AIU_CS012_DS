# import the pandas library and aliasing as pd
import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), \
    index = ['a','b','c'], columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#          A         B         C         D
#a  1.185926  0.155168 -0.697801 -1.785801
#b -1.597864 -0.561952 -0.691281 -0.674366
#c  0.434704  0.005517  0.648180  1.032458

# Select few rows for multiple columns, say list[]
print("df.loc[['a','b'],['A','C']]:")
print(df.loc[['a','b'],['A','C']])
#df.loc[['a','b'],['A','C']]:
#          A         C
#a  1.185926 -0.697801
#b -1.597864 -0.691281