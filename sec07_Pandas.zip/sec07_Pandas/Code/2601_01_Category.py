import pandas as pd

s = pd.Series(["a","b","c","a"], dtype="category")
print('s:')
print(s)
# s:
#0    a
#1    b
#2    c
#3    a
#dtype: category
#Categories (3, object): ['a', 'b', 'c']