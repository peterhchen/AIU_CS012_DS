import pandas as pd

cat = pd.Categorical(['a', 'b', 'c', 'a', 'b', 'c'])
print('cat:')
print(cat)
# cat:
#['a', 'b', 'c', 'a', 'b', 'c']
#Categories (3, object): ['a', 'b', 'c']