import pandas as pd
import numpy as np

unsorted_df = pd.DataFrame(np.random.randn(5,2),index=[1,4,5,2,3],
columns = ['col2','col1'])
print('unsorted_df:')
print(unsorted_df)
print()
# unsorted_df:
#       col2      col1
#1  0.393144 -0.219971
#4 -1.010021  0.102024
#5  0.793524 -0.413119
#2  0.329327 -1.535000
#3  0.597568  0.142980
sorted_df = unsorted_df.sort_index(ascending=False)
print('sorted_df:')
print(sorted_df)
#sorted_df:
#       col2      col1
#5  0.793524 -0.413119
#4 -1.010021  0.102024
#3  0.597568  0.142980
#2  0.329327 -1.535000
#1  0.393144 -0.219971