import pandas as pd
import numpy as np

unsorted_df=pd.DataFrame(np.random.randn(5,2),index=[1,4,5,2,3],
columns=['col2','col1'])
print(unsorted_df)
#        col2      col1
#1  1.327476  0.604065
#4 -1.140129  0.255841
#5  0.103124 -1.453308
#2 -0.456984 -1.782340
#3 -0.461177 -0.882786