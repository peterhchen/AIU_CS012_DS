import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3,3),columns = ['col1','col2','col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0 -0.211190  0.657182  1.167732
#1 -0.509968  1.358972  1.259200
#2  0.621950  1.256490  0.756587
for row_index,row in df.iterrows():
   print(row_index, row)
#0 col1   -0.211190
#col2    0.657182
#col3    1.167732
#Name: 0, dtype: float64
#1 col1   -0.509968
#col2    1.358972
#col3    1.259200
#Name: 1, dtype: float64
#2 col1    0.621950
#col2    1.256490
#col3    0.756587
#Name: 2, dtype: float64