import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(6, 4), columns=['one', 'two', 'three',
'four'],index=list('abcdef'))

print('df:')
print(df)
print("df.reindex(['b', 'c', 'e']):")
print(df.reindex(['b', 'c', 'e']))
#df:
#        one       two     three      four
#a  0.305627  0.653816  0.214640  0.062161
#b  1.021970  0.117822  0.490014  1.063108
#c  1.029431 -0.658449  0.801205  0.878961
#d  1.059494  0.053841  0.355783 -0.037607
#e  0.406005  0.557836  0.105894 -0.516295
#f  1.195177 -2.026479 -1.977672  0.667071
#df.reindex(['b', 'c', 'e']):
#        one       two     three      four
#b  1.021970  0.117822  0.490014  1.063108
#c  1.029431 -0.658449  0.801205  0.878961
#e  0.406005  0.557836  0.105894 -0.516295