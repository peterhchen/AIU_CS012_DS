import pandas as pd
import numpy as np
df = pd.DataFrame(np.random.randn(3, 3),columns=['col1', 'col2', 'col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0  1.512718  1.404515  0.600379
#1 -0.130122 -1.018294  0.541897
#2 -0.907800  1.832618  1.094207
for key, value in df.iteritems():
    print(key, value)
#col1 0    1.512718
#1   -0.130122
#2   -0.907800
#Name: col1, dtype: float64
#col2 0    1.404515
#1   -1.018294
#2    1.832618
#Name: col2, dtype: float64
#col3 0    0.600379
#1    0.541897
#2    1.094207
#Name: col3, dtype: float64