import pandas as pd
print('pd.set_option("display.max_rows",80):')
pd.set_option("display.max_rows",80)
print(pd.get_option("display.max_rows"))
print('pd.set_option("display.max_columns",30):')
pd.set_option("display.max_columns",30)
print(pd.get_option("display.max_columns"))
# pd.set_option("display.max_rows",80):
# 80
#pd.set_option("display.max_columns",30):
#30 