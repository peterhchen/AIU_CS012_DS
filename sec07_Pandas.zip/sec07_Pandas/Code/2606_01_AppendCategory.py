import pandas as pd

s = pd.Series(["a","b","c","a"], dtype="category")
print('s:')
print(s)
print('s.cat.categories:')
print(s.cat.categories)
s = s.cat.add_categories([4])
print('s = s.cat.add_categories([4]) => s.cat.categories:')
print(s.cat.categories)
#s:
#0    a
#1    b
#2    c
#3    a
#dtype: category
#Categories (3, object): ['a', 'b', 'c']

#s.cat.categories:
#Index(['a', 'b', 'c'], dtype='object')

#s = s.cat.add_categories([4]) => s.cat.categories:
#Index(['a', 'b', 'c', 4], dtype='object')