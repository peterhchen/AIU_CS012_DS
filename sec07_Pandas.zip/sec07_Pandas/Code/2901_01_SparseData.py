# Python program to convert a matrix to sparse matrix
# https://www.geeksforgeeks.org/python-program-to-convert-a-matrix-to-sparse-matrix/
# Here the Matrix is represented using a 2D list and the Sparse Matrix is represented 
# in the form Row Column Value
# In the Sparse Matrix the first row is 0 1 1 indicates that 
# the value of the Matrix at row 0 and column 1 is 1.  
  
# function display a matrix into a sparse matrix
def displayMatrix(matrix):
    for row in matrix:
        for element in row:
            print(element, end =" ")
        print()

# function to convert the matrix   
def convertToSparseMatrix(matrix):
    # creating an empty sparse 
    # matrix list
    sparseMatrix =[]
    # searching values greater 
    # than zero
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if matrix[i][j] != 0 :
  
                # creating a temporary
                # sublist
                temp = []
  
                # appending row value, column 
                # value and element into the 
                # sublist 
                temp.append(i)
                temp.append(j)
                temp.append(matrix[i][j])
  
                # appending the sublist into
                # the sparse matrix list
                sparseMatrix.append(temp)
    # displaying the sparse matrix
    print("\nSparse Matrix: ") 
    displayMatrix(sparseMatrix)                 
  
# Driver's code
# initializing a normal matrix
normalMatrix =[[1, 0, 0, 0], 
               [0, 2, 0, 0], 
               [0, 0, 3, 0], 
               [0, 0, 0, 4], 
               [5, 0, 0, 0]] 
  
# displaying the matrix
print('Normal Matrix:')
displayMatrix(normalMatrix)
# converting the matrix to sparse 
# displayMatrix 
convertToSparseMatrix(normalMatrix)