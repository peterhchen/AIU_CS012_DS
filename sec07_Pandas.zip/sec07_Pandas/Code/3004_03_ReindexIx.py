import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(6, 4), columns=['one', 'two', 'three',
'four'],index=list('abcdef'))

print('df:')
print(df)
print()
print('df.iloc[[1, 2, 4]]:')
print(df.iloc[[1, 2, 4]])
print()
print('df.reindex([1, 2, 4]):')
print(df.reindex([1, 2, 4]))
# df:
#        one       two     three      four
#a  1.065655  1.201515 -0.025729 -0.598043
#b -1.501088  0.890237 -0.017303  0.215958
#c -1.122282  0.272997  0.696185 -0.344630
#d -1.317752  0.840017  0.859103  0.148992
#e -0.961929  1.101159 -0.057606  0.996142
#f -1.098952 -0.847324 -1.447188 -0.528886

#df.iloc[[1, 2, 4]]:
#        one       two     three      four
#b -1.501088  0.890237 -0.017303  0.215958
#c -1.122282  0.272997  0.696185 -0.344630
#e -0.961929  1.101159 -0.057606  0.996142

#df.reindex([1, 2, 4]):
#   one  two  three  four
#1  NaN  NaN    NaN   NaN
#2  NaN  NaN    NaN   NaN
#4  NaN  NaN    NaN   N