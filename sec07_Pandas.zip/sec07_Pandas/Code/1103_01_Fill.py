import pandas as pd
import numpy as np

df1 = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
df2 = pd.DataFrame(np.random.randn(2,3),columns=['col1','col2','col3'])
print('df1:')
print(df1)
print('df2:')
print(df2)
print()
#df1:
#       col1      col2      col3
#0  1.440633 -1.411172  0.756782
#1 -1.363026 -0.745530 -0.219088
#2 -0.383470  0.171290 -0.588840
#3  0.567233  1.881690 -0.279310
#4  0.993306 -1.173206 -0.694569
#df2:
#       col1      col2      col3
#0 -0.832645  0.487537 -0.285296
#1  0.186494  0.558624 -1.367735

# Padding NAN's
print('df2.reindex_like(df1):')
print(df2.reindex_like(df1))
print()
#df2.reindex_like(df1):
#       col1      col2      col3
#0 -0.832645  0.487537 -0.285296
#1  0.186494  0.558624 -1.367735
#2       NaN       NaN       NaN
#3       NaN       NaN       NaN
#4       NaN       NaN       NaN

# Now Fill the NAN's with preceding Values
print("Data Frame with Forward Fill:")
print("df2.reindex_like(df1, method='ffill'):")
print(df2.reindex_like(df1, method='ffill'))
#Data Frame with Forward Fill:
#df2.reindex_like(df1, method='ffill'):
#       col1      col2      col3
#0 -0.832645  0.487537 -0.285296
#1  0.186494  0.558624 -1.367735
#2  0.186494  0.558624 -1.367735
#3  0.186494  0.558624 -1.367735
#4  0.186494  0.558624 -1.367735