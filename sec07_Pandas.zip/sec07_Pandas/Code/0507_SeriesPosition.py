import pandas as pd
s = pd.Series([1,2,3,4,5],index = ['a','b','c','d','e'])

#retrieve the first element
print('s:')
print(s)
print('s[0]:', s[0])