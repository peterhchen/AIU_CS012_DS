import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5,3),columns=['col1','col2','col3'])
print('df:')
print(df)
print()
#df:
#       col1      col2      col3
#0 -0.523921 -1.578662  0.798152
#1  1.111107  1.310977  1.358613
#2 -1.214849  1.556371  0.554539
#3  0.305322  0.161784  0.056146
#4  0.377840 -1.797589  0.117315

df1 = df.apply(np.mean, axis=1)
print('df1:')
print(df1)
#df1:
#0   -0.434810
#1    1.260233
#2    0.298687
#3    0.174417
#4   -0.434145
#dtype: float64

df2 = df.apply(np.mean)
print('df2 = df.apply(np.mean) => df2:')
print(df2)
#df2:
#df2 = df.apply(np.mean) => df2:
#col1    0.011100
#col2   -0.069424
#col3    0.576953
#dtype: float64