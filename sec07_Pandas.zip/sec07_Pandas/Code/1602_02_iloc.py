import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(3, 4), columns = ['A', 'B', 'C', 'D'])
print('df:')
print(df)
print()
#df:
#          A         B         C         D
#0 -0.706952  0.160732 -1.328539 -1.587964
#1  0.384350 -1.952363  1.116720  0.951720
#2 -0.428585  0.225677  1.203417  0.699197

# Integer slicing
print('df.iloc[:2]:')
print(df.iloc[:2])
print('df.iloc[1:2, 2:4]:')
print(df.iloc[1:2, 2:4])
# df.iloc[:2]:
#          A         B         C         D
#0 -0.706952  0.160732 -1.328539 -1.587964
#1  0.384350 -1.952363  1.116720  0.951720
#df.iloc[1:2, 2:4]:
#         C        D
#1  1.11672  0.95172