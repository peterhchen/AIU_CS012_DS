import pandas as pd
print("pd.Timedelta(6,unit='h'):")
print(pd.Timedelta(6,unit='h'))
# pd.Timedelta(6,unit='h'):
# 0 days 06:00:00