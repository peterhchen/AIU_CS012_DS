import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f', 'h'],columns=['one', 'two', 'three'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  1.630976 -0.313818 -1.257284
#c  1.158572  1.368278  1.473625
#e -0.456400  0.277984  0.604279
#f  1.472509  0.991108 -0.515399
#h -0.026433 -0.139209  0.804227
df1 = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print('df1:')
print(df1)
print()
#df1:
#        one       two     three
#a  1.630976 -0.313818 -1.257284
#b       NaN       NaN       NaN
#c  1.158572  1.368278  1.473625
#d       NaN       NaN       NaN
#e -0.456400  0.277984  0.604279
#f  1.472509  0.991108 -0.515399
#g       NaN       NaN       NaN
#h -0.026433 -0.139209  0.804227

print('df1.dropna(axis=1):')
print(df1.dropna(axis=1))
#df1.dropna(axis=1):
#Empty DataFrame
#Columns: []
#Index: [a, b, c, d, e, f, g, h]