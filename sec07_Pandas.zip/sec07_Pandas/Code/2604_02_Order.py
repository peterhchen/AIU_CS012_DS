import pandas as pd
import numpy as np

cat = pd.Categorical(["a", "c", "c", np.nan], categories=["b", "a", "c"])
print("cat:")
print(cat)
print("cat.ordered:")
print(cat.ordered)

cat1 = pd.Categorical(["a", "c", "c", np.nan], categories=["b", "a", "c"], ordered=True)
print("cat1:")
print(cat1)
print("cat1.ordered:")
print(cat1.ordered)

#cat:
#['a', 'c', 'c', NaN]
#Categories (3, object): ['b', 'a', 'c']
#cat.ordered:
#False

#cat1:
#['a', 'c', 'c', NaN]
#Categories (3, object): ['b' < 'a' < 'c']
#cat1.ordered:
#True