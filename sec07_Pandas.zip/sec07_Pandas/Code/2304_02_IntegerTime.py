import pandas as pd

print("pd.Timestamp(1587687255, unit='s'):")
print(pd.Timestamp(1587687255, unit='s'))
# pd.Timestamp(1587687255, unit='s'):
# 2020-04-24 00:14:15