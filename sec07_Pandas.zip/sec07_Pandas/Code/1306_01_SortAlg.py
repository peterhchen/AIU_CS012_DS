import pandas as pd
import numpy as np

unsorted_df = pd.DataFrame({'col1':[2,1,1,1],'col2':[1,3,2,4]})
print('unsorted_df:')
print(unsorted_df)
print()
#unsorted_df:
#   col1  col2
#0     2     1
#1     1     3
#2     1     2
#3     1     4
sorted_df = unsorted_df.sort_values(by='col1' ,kind='mergesort')
print('sorted_df:')
print(sorted_df)
#sorted_df:
#   col1  col2
#1     1     3
#2     1     2
#3     1     4
#0     2     1