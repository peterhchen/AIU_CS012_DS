import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

N = 100
df = pd.DataFrame({'City': np.random.choice(['London', 'Paris', 'Madrid', 'Berlin'], size=N),
                   'CarTripDuration': np.random.randint(10, 100, N)})
print('df:')
print(df)
# Create subplots 
fig, axes = plt.subplots(nrows=2, ncols=2)
fig.subplots_adjust(hspace=0.5)
fig.suptitle('Distributions of CarTripDuration by City')

# Generate histograms
for ax, (name, subdf) in zip(axes.flatten(), df.groupby('City')):
    subdf.hist('CarTripDuration', ax=ax)
    ax.set_title(name)

plt.show()
#df:
#      City  CarTripDuration
#0   Berlin               62
#1    Paris               10
#2   London               36
# ...
#98  Madrid               10
#99   Paris               67
#
#[100 rows x 2 columns]