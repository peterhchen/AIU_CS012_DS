import pandas as pd
import numpy as np

s = pd.Categorical(["a", "c", "c", np.nan], categories=["b", "a", "c"])
print('s:')
print(s)
print("s.categories:")
print(s.categories)
# s:
#['a', 'c', 'c', NaN]
#Categories (3, object): ['b', 'a', 'c']
#s.categories:
#Index(['b', 'a', 'c'], dtype='object')