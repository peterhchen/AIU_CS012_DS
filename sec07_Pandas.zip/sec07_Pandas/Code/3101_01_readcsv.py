import pandas as pd

url = 'https://raw.github.com/pandasdev/pandas/master/pandas/tests/data/tips.csv'

#tips=pd.read_csv(url)
tips=pd.read_csv('tips.csv')
print('tips=pd.read_csv(url) => tips.head():')
print(tips.head())
# tips=pd.read_csv(url) => tips.head():
#  total_bill tip sex smoker day time size
#0     0 16.99 1.01 Female No Sun Dinner 2
#1       1 10.34 1.66 Male No Sun Dinner 3
#2       2 21.01 3.50 Male No Sun Dinner 3
#3       3 23.68 3.31 Male No Sun Dinner 2
#4     4 24.59 3.61 Female No Sun Dinner 4