import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame(np.random.rand(50, 4), columns=['a', 'b', 'c', 'd'])
df.plot.scatter(x='a', y='b')

print('df:')
print(df)

#plt.legend(loc='best')
plt.show()
#df:
#           a         b         c         d
#0   0.559526  0.275103  0.170782  0.176679
#1   0.891708  0.376382  0.381572  0.873662
# ...