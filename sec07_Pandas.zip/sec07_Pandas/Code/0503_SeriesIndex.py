#import the pandas library and aliasing as pd
import pandas as pd
import numpy as np
data = np.array(['a','b','c','d'])
s = pd.Series(data,index=[100,101,102,103])
print('s:')
print(s)
# s:
# 100    a
# 101    b
# 102    c
# 103    d
# dtype: object

data = np.array(['1.0','2.0','3.0','4.0'])
s = pd.Series(data,index=[100,101,102,103])
print('s:')
print(s)
# s:
# 100    1.0
# 101    2.0
# 102    3.0
# 103    4.0
# dtype: object