import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.DataFrame(np.random.randn(1000, 4), \
    index=pd.date_range('1/1/2000', periods=1000), 
    columns=list('ABCD'))
print('df:')
print(df)
print()
df1 = df.cumsum()
print('df1:')
print(df1)
print()
df1.plot() 
plt.legend(loc='best')
plt.show()

#df:
#                   A         B         C         D
#2000-01-01  1.262543 -0.291835 -1.009161 -0.654008
#2000-01-02 -0.740208 -1.707915 -0.968699  0.646758
#...              ...       ...       ...       ...
#2002-09-25  1.041861  1.787188  0.027988  0.858483
#2002-09-26  0.611687 -1.327119  1.456592 -0.611037
#
#[1000 rows x 4 columns]
#
#df1:
#                    A          B          C         D
#2000-01-01   1.262543  -0.291835  -1.009161 -0.654008
#2000-01-02   0.522334  -1.999750  -1.977860 -0.007250
#...               ...        ...        ...       ...
#2002-09-25 -61.390527  49.696995  26.411771 -0.358859
#2002-09-26 -60.778840  48.369876  27.868363 -0.969897
#
#[1000 rows x 4 columns]