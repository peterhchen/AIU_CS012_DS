import pandas as pd
import numpy as np
s = pd.Series([1,2,3,4,5,4])
print('s:')
print(s)
print()
print('s.pct_change():')
print(s.pct_change())
print()
#s:
#0    1
#1    2
#2    3
#3    4
#4    5
#5    4
#dtype: int64
#
#s.pct_change():
#0         NaN
#1    1.000000
#2    0.500000
#3    0.333333
#4    0.250000
#5   -0.200000
#dtype: float64

df = pd.DataFrame(np.random.randn(5, 2))
print('df:')
print(df)
print()
print('df.pct_change():')
print(df.pct_change())
# df:
#          0         1
#0  1.052276 -0.269863
#1 -0.562034 -1.309587
#2 -0.488423 -1.413824
#3  0.434175 -1.121696
#4 -0.230656  0.746413
#
#df.pct_change():
#          0         1
#0       NaN       NaN
#1 -1.534113  3.852788
#2 -0.130973  0.079596
#3 -1.888933 -0.206623
#4 -1.531251 -1.665432