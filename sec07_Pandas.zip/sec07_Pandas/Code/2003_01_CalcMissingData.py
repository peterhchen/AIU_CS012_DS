import pandas as pd
import numpy as np

df = pd.DataFrame(np.random.randn(5, 3), \
    index=['a', 'c', 'e', 'f','h'],
    columns=['one', 'two', 'three'])

df = df.reindex(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'])
print('df:')
print(df)
print()
#df:
#        one       two     three
#a  0.192865  0.128996  0.471048
#b       NaN       NaN       NaN
#c  0.421578 -1.466279 -0.940495
#d       NaN       NaN       NaN
#e  0.839993  0.427279  2.389422
#f -0.007825 -1.172188 -1.388714
#g       NaN       NaN       NaN
#h -1.066183  0.615958  0.542416

print("df['one'].sum():")
print(df['one'].sum())
#df['one'].sum():
#0.38042723674442136