import pandas as pd
pd.describe_option("display.max_rows")
# display.max_rows : int
#    If max_rows is exceeded, switch to truncate view. Depending on
#    `large_repr`, objects are either centrally truncated or printed as
#    a summary view. 'None' value means unlimited.
#
#    In case python/IPython is running in a terminal and `large_repr`
#    equals 'truncate' this can be set to 0 and pandas will auto-detect
#    the height of the terminal and print a truncated object which fits
#    the screen height. The IPython notebook, IPython qtconsole, or
#    IDLE do not run in a terminal and hence it is not possible to do
#    correct auto-detection.
#    [default: 60] [currently: 60]