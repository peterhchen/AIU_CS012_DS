import pandas as pd

data = pd.read_json('path/input.json')
print (data)