bird_d = {'bird':'ketzal','yellow':'color', 'feathers':'long',
           'ketzal':'bird', 'color':'green'}

print ("%(bird)s has %(color)s feathers" % bird_d)