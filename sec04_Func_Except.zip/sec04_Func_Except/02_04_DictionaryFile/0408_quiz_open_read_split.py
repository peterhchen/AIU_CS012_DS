y = open("my.text").read().split()
x = len (y)
print ('y=', y, 'x=', x)