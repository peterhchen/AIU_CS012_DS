#!/usr/bin/python

# Function definition is here
def printinfo (name, age):
   """
   Description: 
   We have the default parameter age=35.
   It external parameter does not assign the value 
   for parameter age.
   The function will use the defaut age = 35.
   """
   print("Name: ", name)
   print("Age ", age)
   return;

# Call printinfo function.
# We pass the defined aguments (values)
# If we did not pass, the funciton will use defult argument. 
printinfo (age=50, name="miki")
printinfo (name="miki")
# Name:  miki
# Age  50
# 
# Traceback (most recent call last):
#  File "1508_NoDeafultArg.py", line 20, in <module>
#    printinfo (name="miki")
# TypeError: printinfo() missing 1 required positional argument: 'age'
