import fibo
print('fibo.fib(100):')
 # There is a print() command inside function. 
 # We do not need another print(fibo.fib(100))
fibo.fib(100) 
print()
fib = fibo.fib
print('fib(500):')
fib(500)
# fibo.fib(100):
# 0 1 1 2 3 5 8 13 21 34 55 89
# 
# fib(500):
# 0 1 1 2 3 5 8 13 21 34 55 89 144 233 377