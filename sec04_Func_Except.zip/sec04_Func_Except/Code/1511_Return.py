#!/usr/bin/python

# Function definition is here
def sum( arg1, arg2 ):
   # Add both the parameters and return them."
   total = arg1 + arg2
   print("Inside the function : ", total)
   return total;

# Now you can call sum function
total = sum (10, 20);
print("Outside the function : ", total)
# Inside the function :  30
# Outside the function :  30