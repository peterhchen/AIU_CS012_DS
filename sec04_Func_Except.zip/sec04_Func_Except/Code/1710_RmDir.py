#!/usr/bin/python
import os

# This would  remove "test"  directory.
path = "test"
if os.path.exists(path):  
    os.rmdir("test")