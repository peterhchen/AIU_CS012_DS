#!/usr/bin/python
import os
# Create a directory "test"
path = "test"
if os.path.exists(path) is False:  
    os.mkdir(path)

# Changing a directory to "/home/newdir"
os.chdir(path)
# Change back the current directory
os.chdir("..")