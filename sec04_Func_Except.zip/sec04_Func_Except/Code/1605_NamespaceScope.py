#!/usr/bin/python

Money = 2000
def AddMoney():
   # Uncomment the following line to fix the code:
   global Money
   Money = Money + 1

print('Money:', Money)
print()
AddMoney()
print('Money:', Money)