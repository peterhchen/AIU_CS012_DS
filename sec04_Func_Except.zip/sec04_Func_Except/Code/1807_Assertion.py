#!/usr/bin/python
def KelvinToFahrenheit(Temperature):
   assert (Temperature >= 0),"Colder than absolute zero!"
   return ((Temperature-273)*1.8)+32
print(KelvinToFahrenheit(273))
print(int(KelvinToFahrenheit(505.78)))
print(KelvinToFahrenheit(-5))
# 32.0
# 451
# Traceback (most recent call last):
#  File "1807_Assertion.py", line 7, in <module>
#    print(KelvinToFahrenheit(-5))
#  File "1807_Assertion.py", line 3, in KelvinToFahrenheit
#    assert (Temperature >= 0),"Colder than absolute zero!"
# AssertionError: Colder than absolute zero!