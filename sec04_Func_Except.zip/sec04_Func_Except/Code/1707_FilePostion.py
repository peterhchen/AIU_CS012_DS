#!/usr/bin/python

# Open a file
fo = open("foo.txt", "w")
fo.write("Python is a great language.\nYeah its great!!\n")

# Close opend file
fo.close()
# Open a file
fo = open("foo.txt", "r+")
str = fo.read(10)
print("Read String is : ", str)

# Check current position
position = fo.tell()
print("Current file position : ", position)

# Reposition pointer at the beginning once again
# (offset, from) = (0, 0) move from position 0 to offset 0.
position = fo.seek(0, 0);
str = fo.read(15)
print("Again read String is : ", str)
# Check current position
position = fo.tell()
print("Current file position : ", position)
# Close opend file
fo.close()
# Read String is :  Python is
# Current file position :  10
# Again read String is :  Python is a gre
# Current file position :  15