#!/usr/bin/python

# Function definition is here
def printinfo (name, age):
   """
   Description: This prints a passed info into this function
   """
   print("Name: ", name)
   print("Age ", age)
   return;

# We can call printinfo function with matched keyword.
# Keyword order is no important.
# Keyword (age, name) match is important.
printinfo(age=50, name="miki")
# Name:  miki
# Age  50