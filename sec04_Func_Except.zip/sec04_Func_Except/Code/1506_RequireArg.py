#!/usr/bin/python

# Function definition is here
def printme (str):
   "This prints a passed string into this function"
   print(str)
   return;

# Now you can call printme function
printme() # Need one argument.
# Traceback (most recent call last):
#  File "1506_RequireArg.py", line 10, in <module>
#    printme() # Need one argument.
# TypeError: printme() missing 1 required positional argument: 'str'