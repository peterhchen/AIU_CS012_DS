#!/usr/bin/python

str = raw_input("Enter your input: ")
print("Received input is : ", str)
# raw_input() is Python 2.
# Python 3 uses input() instead
# Traceback (most recent call last):
#  File "1703_RawInput.py", line 3, in <module>
#    str = raw_input("Enter your input: ")
# NameError: name 'raw_input' is not define