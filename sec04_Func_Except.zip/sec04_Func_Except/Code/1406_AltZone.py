# import the time module
import time
  
# display altzone
print(time.altzone)
# 25200
# offset of the local DST(Daylight SAvinf Time) timezone, 
# in seconds west of UTC [Universal Time Coordinate or 
# GMT (Greenwich Mean Time)]. 