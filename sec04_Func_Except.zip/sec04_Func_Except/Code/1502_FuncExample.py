"""
File Name: 1502_FuncExample.py
05/21/2022: by Peter H. Chen
"""
def print_func(str):
    """
    Function Descirption: 
    This prints a passed string into this function
    """
    print('str:', str)
    return

if __name__ == "__main__":
    # call print_func() function
    print_func("I'm first call to user defined function!")
    print_func("Again second call to the same function")
    # str: I'm first call to user defined function!
    # str: Again second call to the same function