#!/usr/bin/python

# Import module support
# The Module naming convetion. Not number in the file name.
import Module
# import 1601_Module

# Now you can call defined function that module as follows
Module.print_func("Zara")
# Hello :  Zara