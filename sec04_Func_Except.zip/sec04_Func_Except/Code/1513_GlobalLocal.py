#!/usr/bin/python
"""
File Name: GlobalLocal.py
"""

TOTAL = 0 # This is global variable.
# Function definition is here
def mysum(arg1, arg2, arg3):
    """
    Description: Sum
    """
    # Add both the parameters and return them."
    total = arg1 + arg2 # Here total is local variable.
    arg3[0] = arg1 + arg2
    print("Inside the function local total:", total)
    return total

# Now you can call sum function
ARG3 = [0]
RETURN_TOTAL = mysum(10, 20, ARG3)
print("Outside the function global total:", TOTAL)
print("Outside the function global ARG3:", ARG3)
print("Outside the function global RETURN_TOTAL:", RETURN_TOTAL)
# Inside the function local total: 30
# Outside the function global total: 0
# Outside the function global arg3: [30]
# Outside the function global return_total: 30
