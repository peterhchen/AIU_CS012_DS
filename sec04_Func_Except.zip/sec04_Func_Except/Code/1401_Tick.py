#!/usr/bin/python
import time;  # This is required to include time module.

ticks = time.time()
print("Number of ticks since 12:00am, January 1, 1970:", ticks)
# Number of ticks since 12:00am, January 1, 1970: 1653088120.830008