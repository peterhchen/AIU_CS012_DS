#!/usr/bin/python
import os

# This would give location of the current directory
path = os.getcwd()
print('Current Directory:', path)
# Current Directory: C:\Work\SVU\012_Python_Data_Science\sec04_Dict_Exception\Code