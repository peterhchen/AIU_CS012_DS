#!/usr/bin/python
import os

# Create a directory "test"
path = "test"
if os.path.exists(path) is False:  
    os.mkdir(path)