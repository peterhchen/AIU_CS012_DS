#!/usr/bin/python

# Open a file
fo = open("foo.txt", "w")
fo.write("Python is a great language.\nYeah its great!!\n")

# Close opend file
fo.close()
#open and read the file after the appending:
fi = open("foo.txt", "r")
print('fi.read():')
print(fi.read())
fi.close()
# fi.read():
# Python is a great language.
# Yeah its great!!

# read 10 character
fi = open("foo.txt", "r")
print('fi.read(10):')
print(fi.read(11))
fi.close()
# fi.read(10):
# Python is