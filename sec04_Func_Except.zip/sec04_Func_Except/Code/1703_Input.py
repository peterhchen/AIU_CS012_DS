#!/usr/bin/python

str = input("Enter your input: ")
print("Received input is:", str)
# Enter your input: pchen
# Received input is: pchen