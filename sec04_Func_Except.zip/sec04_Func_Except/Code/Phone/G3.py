#!/usr/bin/python 
# File Name: Phone/G3.py
def G3(): 
    print("I'm G3 Phone") 