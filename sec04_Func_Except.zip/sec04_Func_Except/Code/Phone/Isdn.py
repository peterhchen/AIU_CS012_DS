#!/usr/bin/python 
# File Name: Phone/Isdn.py
def Isdn(): 
    print("I'm Isdn Phone") 