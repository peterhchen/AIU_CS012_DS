#!/usr/bin/python 
# File Name: Phone/Pots.py
# POT: Plain Old Style 
def Pots(): 
    print("I'm Pots Phone") 
