from Phone.Pots import Pots 
from Phone.Isdn import Isdn
from Phone.G3 import G3 