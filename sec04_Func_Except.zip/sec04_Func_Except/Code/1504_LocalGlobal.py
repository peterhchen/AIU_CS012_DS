#!/usr/bin/python
"""
File Name: 1504_LocalGlobal.py
Description: Local vs. Global Parameter.
05/21/2022: Peter H. Chen
"""
# Function definition is here
def change_me( mylist ):
   """
   Description: This changes a passed list into this function
   """
   mylist = [1,2,3,4]; # This would assig new reference in mylist
   print("Values inside the function: ", mylist)
   return

if __name__ == "__main__":
    # Now you can call changeme function
    mylist = [10,20,30];
    change_me( mylist );
    print("Values outside the function: ", mylist)
    # Values inside the function:  [1, 2, 3, 4]
    # Values outside the function:  [10, 20, 30]