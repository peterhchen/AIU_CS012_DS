import Phone 
Phone.Pots() 
Phone.Isdn() 
Phone.G3() 
# I'm Pots Phone
# I'm Isdn Phone
# I'm G3 Phone