# import fibo
from fibo import *
print('fib(500):')
fib(500)
print()
print('print(fib2(300)):')
print(fib2(300))
# fib(500):
# 0 1 1 2 3 5 8 13 21 34 55 89 144 233 377
#
# print(fib2(300)):
# [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]