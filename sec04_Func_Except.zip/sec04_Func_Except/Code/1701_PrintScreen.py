#!/usr/bin/python

print ("Python is really a great language,", "isn't it?")
# Python is really a great language, isn't it?