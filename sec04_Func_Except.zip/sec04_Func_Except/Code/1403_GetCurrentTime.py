#!/usr/bin/python
import time;

localtime = time.localtime(time.time())
print("Local current time :", localtime)
# Local current time : time.struct_time(
# tm_year=2022, tm_mon=5, tm_mday=20, tm_hour=19, tm_min=38, 
# tm_sec=57, tm_wday=4, tm_yday=140, tm_isdst=1)