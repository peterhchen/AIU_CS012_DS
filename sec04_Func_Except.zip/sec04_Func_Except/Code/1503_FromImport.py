#!/usr/bin/python

# Import module support
# The Module naming convetion. Not number in the file name.
from Module import print_func

# Now you can call defined function that module as follows
Module.print_func("Zara")
# Hello :  Zara