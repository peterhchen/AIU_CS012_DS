#!/usr/bin/python
"""
File Name:
"""
# Open a file
# F_O = open("foo.txt", "wb")
with open("foo.txt", "wb", encoding="utf-8") as F_O:
    print("Name of the file: ", F_O.name)

# Close opend file
# F_O.close()
# Name of the file:  foo.txt
