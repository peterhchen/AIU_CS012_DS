#!/usr/bin/python
import os
# copy foot.txt to test1.txt
os.system( "cp foo.txt test1.txt" )
# Rename a file from test1.txt to test2.txt
os.rename( "test1.txt", "test2.txt" )