#!/usr/bin/python

# Open a file
fo = open("foo.txt", "wb")
print("Name of the file: ", fo.name)
print("Closed or not : ", fo.closed)
print("Opening mode : ", fo.mode)
# Python 3 remove softspace attribute.
# print("Softspace flag : ", fo.softspace)
# Name of the file:  foo.txt
# Closed or not :  False
# Opening mode :  wb
# Traceback (most recent call last):
#  File "1706_FileOpen.py", line 8, in <module>
#    print("Softspace flag : ", fo.softspace)
# AttributeError: '_io.BufferedWriter' object has no attribute 'softspace'