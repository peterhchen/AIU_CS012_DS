# program to illustrate timetuple()
# method in Python
  
  
import datetime

# creating object
obj = datetime.datetime.today()
  
# obtaining the attributes of the
# datetime instance as a tuple
objTimeTuple = obj.timetuple()
  
# displaying the tuples of the object
print(objTimeTuple)
# time.struct_time(
# tm_year=2022, tm_mon=5, tm_mday=20, tm_hour=19, tm_min=28, 
# tm_sec=47, tm_wday=4, tm_yday=140, tm_isdst=-1)