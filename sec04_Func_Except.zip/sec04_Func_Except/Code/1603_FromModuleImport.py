from Module import print_func
print_func("Zara")
# Hello :  Zara
# from module import function.
# We call funciton directly. No "Module" is requried.