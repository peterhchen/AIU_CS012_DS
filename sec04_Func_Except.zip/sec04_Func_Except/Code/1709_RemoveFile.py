#!/usr/bin/python
import os
# copy foot.txt to test3.txt
os.system( "cp foo.txt test3.txt" )
# Remove file test3.txt
os.remove( "test3.txt" )