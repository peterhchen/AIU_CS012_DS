#!/usr/bin/python
"""
File Name: 1503_PassRef.py
File Description: Test for funciotn change_name()
05/21/2022: by Peter H. Chen
"""
# define change_name () function
def change_name (mylist):
   """
   Description:
   This changes a passed list into this function
   mylist: in/out parameter
   """
   mylist.append([1,2,3,4])
   print("Values inside the function: ", mylist)
   return

if __name__ == "__main__":
    # Call change_name() function
    mylist = [10,20,30]
    change_name (mylist)
    print("Values outside the function: ", mylist)
    # Values inside the function:  [10, 20, 30, [1, 2, 3, 4]]
    # Values outside the function:  [10, 20, 30, [1, 2, 3, 4]]