#!/usr/bin/python

# Function definition is here
def printinfo (arg1, *vartuple):
    """
    Description: This prints a variable passed arguments
    """
    print("Output is: ")
    print('arg1:', arg1)
    for var in vartuple:
        print('var:', var)
    return;

# Call printinfo function
printinfo (10)
print()
printinfo (70, 60, 50)
# Output is:
# arg1: 10
#
# Output is:
# arg1: 70
# var: 60
# var: 50