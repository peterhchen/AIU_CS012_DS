# Python code to demonstrate the working of
# calendar() function to print calendar
   
# importing calendar module
# for calendar operations
import calendar
   
# using calendar to print calendar of year
# prints calendar of 2018
print ("The calendar of year 2018 is : ")
print (calendar.calendar(2018, 2, 1, 6))