from tkinter import *
# import tkinter as tk

root = Tk()
# creating fixed geometry of the
# tkinter window with dimensions 150x200
root.geometry('200x150')

var = StringVar()
label = Label (root, textvariable=var, relief=RAISED )
#label = Label (root, text="Hello", relief=RAISED )
#label.pack()
#label.place(relx = 0.5, rely = 0.5, anchor = 'center')
#label.place(relx = 0.0, rely = 1.0, anchor = 'sw')
# label.place(relx = 0.0, rely = 0.5, anchor = 'w')
label.pack(padx=20, pady=30, side=LEFT)
var.set("Hey!? How are you doing?")
root.mainloop()