"""
File Name: hello.py
"""
def main_func():
    print("Hello Python")

if __name__ == '__main__':
    main_func()

