1. Create a hello.py
2. python3 hello.py
   > python3 hello.py
   make sure hello.py is working
   >> "hello python"
3. Create Dockerfile
   > FROM ubuntu
   # Update ubuntu linux
   > RUN apt-get update
   > COPY hello.py .
   > CMD ['python3', 'hello.py']
4. Create docker_build.scr
   # -t: Tag name
   > docker build -t firstimage:1.0
5. chmod 777 docker_build.scr 
6. ./run_build.scr
7. docker images
   >> Verfiy the firstimage TAGE 1.0 is create 
8. Create run_image
   > docker run -it firstimage:1
   >> should see "hello python"
   > docker ps -a
   > docker commit <containerID>
