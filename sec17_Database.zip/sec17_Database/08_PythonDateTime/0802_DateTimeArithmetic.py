import datetime 
 
#Capture the First Date
day1 = datetime.date(2018, 2, 12)
print ('day1:', day1.ctime())

# Capture the Second Date
day2 = datetime.date(2017, 8, 18)
print ('day2:', day2.ctime())

# Find the difference between the dates
print ('Number of Days:', day1-day2)

date_today  = datetime.date.today() 

# Create a delta of Four Days 
no_of_days = datetime.timedelta(days=4) 
print ('Number of Days:', no_of_days)
# Use Delta for Past Date
before_four_days = date_today - no_of_days 
print ('Before Four Days:', before_four_days)
 
# Use Delta for future Date
after_four_days = date_today + no_of_days 
print ('After Four Days:', after_four_days)