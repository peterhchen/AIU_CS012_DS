#import urllib2
import urllib.request
from bs4 import BeautifulSoup

#response = urllib2.urlopen('http://tutorialspoint.com/python/python_overview.htm')
response = urllib.request.urlopen('http://tutorialspoint.com/python/python_overview.htm')
html_doc = response.read()

soup = BeautifulSoup(html_doc, 'html.parser')
# Format the parsed html file
strhtm = soup.prettify()

print ('soup.title:')
print (soup.title)
print ('soup.title.string:')
print (soup.title.string)
print ('soup.a.string:')
print (soup.a.string)
print ('soup.b.string:')
print (soup.b.string)