from sqlalchemy import create_engine
from pandas.io import sql

import pandas as pd

data = pd.read_csv('path/input.csv')
print (data)
print ('')

engine = create_engine('sqlite:///:memory:')
data.to_sql('data_table', engine)

sql.execute('Delete from data_table where name = (?) ', engine,  params=[('Gary')])

res = pd.read_sql_query('SELECT ID,Dept,Name,Salary,start_date FROM data_table', engine)
print ('result:')
print(res)