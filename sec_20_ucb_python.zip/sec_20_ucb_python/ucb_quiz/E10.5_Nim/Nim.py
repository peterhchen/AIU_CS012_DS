# Nimm is a 2-player game of no chance:
# a position is represented by a pile of beans.
# On a player's turen, they take as many beans as 
# they want from an single pile (at leat one)
# with the goal of takinf the last bean.
# The children of a position is a list of all positions
# that can be reachable in one move.
# If game is over (all the piles are empty), children returns
# an empty list. Fortunately, we will write children for you.
def children (position):
    "Return the chikder of a Nim poistion"
    kids = []
    #print('  children => position:', position)
    for pile in range(len(position)):
        # print('  children => pile:', pile)
        for left_in_that_column in range (0, position[pile]):
            copy = position[:]
            #print('    copy:', copy)
            copy[pile] = left_in_that_column
            #print('    cleft_in_that_column:', left_in_that_column)
            #print('    poisition[', pile, ']:', position[pile])
            #print('    copy[', pile, ']:', copy[pile])
            #print()
            kids.append(copy)
    
    print('  kids:', kids)
    return kids

def mex(s):
    "Return the Minimum EXcluded value of a set"
    minimum = 0
    while (1):
        if minimum not in s:
            return minimum
        else:
            minimum += 1

def sg(position):
    ## Your solution here.
    kids = []
    print('  sg => position:', position)
    for pile in range(len(position)):
        print('  sg => pile:', pile)
        for left_in_that_column in range (0, position[pile]):
            copy = position[:]
            #print('    copy:', copy)
            copy[pile] = left_in_that_column
            #print('    cleft_in_that_column:', left_in_that_column)
            #print('    poisition[', pile, ']:', position[pile])
            print('    copy[', pile, ']:', copy[pile])
            #print()
            kids.append(copy)
    print('  kids:', kids)
    min_list = []
    for kid in kids:
        print('kid:', kid)
        print('kid[0]:', kid[0])
        print('kid[1]:', kid[1])
        min_list.append(abs(kid[1]-kid[0]))
    minimum = 0
    for min in min_list:
        while (1):
            if minimum not in min_list:
                break
            else:
                minimum += 1
        print('minimum:', minimum)
    return minimum

if __name__ == '__main__':
    #print('children([0, 0]):')
    #children([0, 0])
    print('children([1, 3]):')
    children([1, 3]) 
    # kids: [[0, 3], [1, 0], [1, 1], [1, 2]]
    print('children([1, 0]):')
    children([1, 0])   
    # kids: [[0, 0]]
    print('children([1, 1]):')
    children([1, 1])
    # kids: [[0, 1], [1, 0]]
    print('children([1, 2]):')
    children([1, 2])
    # kids: [[0, 2], [1, 0], [1, 1]]
    print()
    #min_1 = mex([])
    #print('mex([]):', min_1)
    #min_2 = mex([3, 1, 2, 3])
    #print('mex([3, 1, 2, 3]):', min_2)
    #min_3 = mex([3, 1, 0, 3])
    #print('mex([3, 1, 0, 3]):', min_3)
    #print()
    print('sg_0:')
    sg_0 = sg([0, 0])
    print(sg_0)
    print()
    #print ('for child in children([1, 3]):')
    #for child in children([1, 3]):
    #    print(child, sg(child))
    #print()

    print('sg_1:')
    sg_1 = sg([1, 3])
    print(sg_1)
    print()