"""
Cal-Stanford games are legend. 
We always store a games as a list for a game as a list of two elements,
where the firs item is cal's score and second item is Standford's score.
Given a list of games, we want a block to caluclate the total points 
that Stanford has scored when it has lost to Cal by 10 or more.

For example,
[[100, 5], [80, 81], [50, 40], [3, 30], [60, 70],
[91, 90], [19, 10], [20, 29]] 

would evaluate to 45 (from 4 + 40).

Load [this starter file] into Snap! and complete the two blocks described below,
Make sire all your code is inside those blocks.
DO not put code anywhere else, and do not rename the blocks or 
change their input paramater names. 
Do not use any iteration (repeat, repeat until, for, or for each)
1. In Snap!, recusively.
2. In Snap!, use Higher-order functions.
"""