
# https://stackoverflow.com/questions/15772617/conditional-statement-in-a-one-line-lambda-function-in-python
# Recusrive and Lambda
# Lambda composite
lambda_above5 = lambda x : True if x > 5 else False
lambda_double = lambda x : x * 2
# rec_lambda = lambda x: x if lambda_above5(x) else lambda_double (x)
rec_lambda = lambda x: x if lambda_above5(x) else rec_lambda(lambda_double (x))
print("rec_lambda (11): ", rec_lambda (11))  # grow(11): 11 <=== 11
print("rec_lambda (1): ", rec_lambda (1))    # grow(1): 8   <=== 8
print("rec_lambda (3): ", rec_lambda (3))    # grow(3): 6   <=== 6
