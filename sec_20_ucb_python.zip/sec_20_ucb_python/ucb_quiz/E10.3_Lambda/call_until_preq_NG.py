# https://www.geeksforgeeks.org/function-composition-in-python/

def composite_function(f, g):
    if lambda x: g(x) is True:
        return lambda x: 1
    else:
        return lambda x : f(x)
  
# Function to add 2
def double(x):
    return x * 2
  
# Function to multiply 2
def above5(x):
    if x > 5:
        return 1
    return x

# call double and above5
grow = composite_function(double, above5)
  
print("grow(11): ", grow(11))   # grow(11): 11
print("grow(1): ", grow(1))     # grow(1): 2
print("grow(3): ", grow(3))     # grow(3): 6
print()

# Lambda composite
lambda_above5 = lambda x : True if x > 5 else False

def lambda_composite_function (f, g):
    if g is True:
        print ('Detect True')
        return lambda x : x
    else:
        print ('Detect False')
        return lambda x : f(x)

print('lambda_above5(5):', lambda_above5(5))  # False
print('lambda_above5(6):', lambda_above5(6))  # True



lambda_grow = lambda_composite_function (double, lambda_above5)

print("lambda_grow(11): ", lambda_grow(11))   # grow(11): 22 <=== 11
print("lambda_grow(1): ", lambda_grow(1))     # grow(1): 2   <=== 8
print("lambda_grow(3): ", lambda_grow(3))     # grow(3): 6   <=== 6

# https://stackoverflow.com/questions/15772617/conditional-statement-in-a-one-line-lambda-function-in-python
# Recusrive and Lambda
lambda_double = lambda x : x * 2
# rec_lambda = lambda x: x if lambda_above5(x) else lambda_double (x)
rec_lambda = lambda x: x if lambda_above5(x) else rec_lambda(lambda_double (x))
print("rec_lambda (11): ", rec_lambda (11))  # grow(11): 11 <=== 11
print("rec_lambda (1): ", rec_lambda (1))    # grow(1): 8   <=== 8
print("rec_lambda (3): ", rec_lambda (3))    # grow(3): 6   <=== 6
