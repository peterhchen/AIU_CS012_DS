# function which it accepts 
# as argument
def composite(f, g):
    #return lambda x : f(g(x)) if g(x) is False else True
    return lambda x : f(g(x))
  
# Function to add 2
def add(x):
    #return x + 2
    return x * 2
  
# Function to multiply 2
def above5(x):
    return x > 5
  
# Composite function returns
# a lambda function. Here add_multiply
# will store lambda x : multiply(add(x))
gorw = composite(add, above5)
  
print("Adding 2 to 5 and multiplying the result with 2: ",
      add_multiply(5))

print("grow(11):", add_multiply(11))

print("Agrow(1): ", add_multiply(1))

print("grow(3): ", add_multiply(3))