def main():
    print('*** Using if else in Lambda function ***')
    # Lambda function to check if a given vaue is from 10 to 20.
    test = lambda x : True if (x > 10 and x < 20) else False
    # Check if given numbers are in range using lambda function
    print(test(12))
    print(test(3))
    print(test(24))
    print('*** Creating conditional lambda function without if else ***')
    # Lambda function to check if a given vaue is from 10 to 20.
    check = lambda x : x > 10 and x < 20
    # Check if given numbers are in range using lambda function
    print(check(12))
    print(check(3))
    print(check(24))
    print('*** Using filter() function with a conditional lambda function (with if else) ***')
    # List of numbers
    listofNum = [1,3,33,12,34,56,11,19,21,34,15]
    print('Original List : ', listofNum)
    # Filter list of numbers by keeping numbers from 10 to 20 in the list only
    listofNum = list(filter(lambda x : x > 10 and x < 20, listofNum))
    print('Filtered List : ', listofNum)
    print('*** Using if, elif & else in Lambda function ***')
    # Lambda function with if, elif & else i.e.
    # If the given value is less than 10 then Multiplies it by 2
    # else if it's between 10 to 20 the multiplies it by 3
    # else returns the unmodified same value
    converter = lambda x : x*2 if x < 10 else (x*3 if x < 20 else x)
    print('convert 5 to : ', converter(5))
    print('convert 13 to : ', converter(13))
    print('convert 23 to : ', converter(23))
if __name__ == '__main__':
    main()
