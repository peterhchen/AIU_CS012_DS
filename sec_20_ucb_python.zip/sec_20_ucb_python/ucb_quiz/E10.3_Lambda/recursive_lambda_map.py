fact = lambda x: 1 if x == 0 else x * fact (x -1)

print('fact(5):', fact(3))