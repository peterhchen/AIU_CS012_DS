def func(x):
    return x + 5
func2 = lambda x: x + 5
print("func(9):", func(9))
print('func2(9):', func2(9))