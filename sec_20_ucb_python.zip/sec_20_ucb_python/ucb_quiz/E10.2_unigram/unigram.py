import re

def getUniqList (ug_list):
    """
    get uniq items in the list.
    """
    ug_uniq = []
    for ele in ug_list:
        if ele not in ug_uniq:
            ug_uniq.append(ele)
    return ug_uniq

def gen_search_pat(ug_uniq):
    """
    Generate search List
    """
    WF_list = []
    for index_W in range(0, len(ug_uniq)):
        for index_F in range(0, len(ug_uniq)):
            WF1 = ug_uniq[index_W] +' ' + ug_uniq[index_F]
            if ug_uniq[index_W] == ug_uniq[index_F]:
                continue
            if WF1 not in WF_list:
                WF_list.append(WF1)
            WF2 = ug_uniq[index_F] +' ' + ug_uniq[index_W]
            if WF2 not in WF_list:
                WF_list.append(WF2)
    # print('WF_list:', WF_list)
    return WF_list

def build_unigram(ug_uniq, WF_list):
    """
    Given":
    1. ug_uniq: top level main dictionay
    2. WF_list: W and F list for second level dictionary
    build the dictionary
    """
    dic_str = "{"
    for top_kw in ug_uniq:
        dic_str = dic_str + "'" + str(top_kw) + "': "
        print('  build_unigram => top_kw:', top_kw)
        # build_unigram => top_kw: love
        print('  build_unigram => top_dic_str:', dic_str)
        # build_unigram => top_dic_str: {'love': 
        i = 0
        for WF in WF_list:
            print('    ******i ', i)
            print('    build_unigram => WF0:', WF)
            #     build_unigram => WF0: ['love bjc', 'love bjc']
            level2_cnt = len(WF)
            ts = str(WF).split(',')
            print('    build_unigram => ts:', ts)
            #     build_unigram => ts: ["['love bjc'", " 'love bjc']"]
            #     build_unigram => ts: ["['love ucb']"]
            level2_str = str(ts[0]).strip()
            print('    build_unigram => level2_str1:', level2_str)
            #     build_unigram => level2_str1: ['love bjc'
            #     build_unigram => level2_str1: ['love ucb']
            level2_ts1 = level2_str.split(" ")
            print('    build_unigram => level2_ts1:', level2_ts1)
            # build_unigram => level2_ts1: ["['love", "bjc'"]
            level2_ts1 = str(level2_ts1).split(",")
            print('    build_unigram => level2_ts1 :', level2_ts1 )
            # build_unigram => level2_ts0: love
            level2_str0 = level2_ts1[0].replace("[", "").replace("]", "").replace("'", "").replace('"', "").strip()
            print('    build_unigram => level2_str2:', level2_str0)
            # build_unigram => level2_ts0: love
            level2_str1 = level2_ts1[1].replace("[", "").replace("]", "").replace("'", "").replace('"', "").replace(top_kw, "").strip()
            print('    build_unigram => level2_str3:', level2_str1)
            # build_unigram => level2_ts1: bjc
            if level2_str0 == top_kw:
                print('    build_unigram => level2_str3:', level2_ts1)
                #     build_unigram => level2_str2:  bjc
                dic_str = dic_str + "{'"
                dic_str = dic_str + str(level2_str1) + "': " + str(level2_cnt)
                # print('    build_unigram => dic_str0:', dic_str)
                # build_unigram => dic_str0: {'love': {'bjc': 2
                if level2_cnt > 1:
                    dic_str = dic_str + ", "
                else:
                    dic_str = dic_str + "}, "
                # print('    build_unigram => dic_str1:', dic_str)
            i += 1
    print('    build_unigram => dic_str2:', dic_str)
    #     build_unigram => dic_str2: {'love': {'bjc': 2, {'ucb': 1}, 'bjc': {'love': 1}, 'ucb': {'love': 1}, 
    dic_str = dic_str[:-2] + str('}')
    dic_str = dic_str.replace(', {', ', ')
    #  build_unigram => dic_str3: {'love': {'bjc': 2, 'ucb': 1}, 'bjc': {'love': 1}, 'ucb': {'love': 1}}
    print('    build_unigram => dic_str3:', dic_str)
    # build_unigram => dic_str3: {'love': {'bjc': 2, 'ucb': 1}, 'bjc': {'love': 1}, 'ucb': {'love': 1}}
    return dic_str

def unigram(ug_str):
    """"
    Write a function, unigram, which takes a phrese of (at least two) space-spareated wotrds,
    and return a dictionary, in which each key is a wotd W in the phrase (except the last word),
    and the values are themseelves dictionaries.
    These inner dictionaries have keys as the word F, which is the word directory after W and
    the value is the number of times the pair of words "...<W> <F>..." existed in the phrasae.
    You might find split useful.
    """
    print('  unigram => ug_str:', ug_str)
    ug_list = ug_str.split(" ")
    # print('  unigram => ug_list:', ug_list)
    ug_uniq = getUniqList(ug_list)
    print('  unigram => ug_uniq:', ug_uniq)
    s_pat_list = gen_search_pat (ug_uniq)
    #print('  s_pat_list:', s_pat_list)
    #   s_pat_list: ['love bjc', 'bjc love', 'love ucb', 'ucb love', 'bjc ucb', 'ucb bjc']
    found_WF_list = []
    for s_pat in s_pat_list:
        found_WF_list.append(re.findall(s_pat, ug_str))
    # print("  unigram => found_WF_list:", found_WF_list)
    #   found_WF_list: [['love bjc', 'love bjc'], ['bjc love'], ['love ucb'], ['ucb love'], [], []]
    final_WF_list = []
    for WF_list in found_WF_list:
        if len(WF_list) > 0:
            final_WF_list.append(WF_list)
    print("  unigram => final_WF_list:", final_WF_list)
    print()
    #   final_WF_list: [['love bjc', 'love bjc'], ['bjc love'], ['love ucb'], ['ucb love']]
    dic_str = build_unigram(ug_uniq, final_WF_list)
    return dic_str

if __name__ == '__main__':
    final_dic_str = ""
    # print("*************test case 1:")
    #str1 = "love bjc"
    #final_dic_str unigram(str1)
    # {'love': {'bjc': 1}}
    print("*************test case 2:")
    str2 = "love bjc love ucb love bjc"
    final_dic_str = unigram (str2)
    print('final_dic_str:')
    print(final_dic_str)
    # {'love': {'bjc': 2, 'ucb': 1}, 'bjc': {'love': 1}, 'ucb': {'love': 1}}
