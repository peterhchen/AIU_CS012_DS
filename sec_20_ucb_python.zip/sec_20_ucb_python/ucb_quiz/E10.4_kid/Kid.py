import copy
class Kid:
    total_candy = 0
    can_swap = False
    def __init__(self, candy):
        self.candy = candy
        Kid.total_candy += candy

    def swap(self, other):
        print('def swap...')
        if Kid.can_swap is True:
           self.candy = other


#one_kid, two_kid, three_kid = Kid(10), Kid(20), Kid(100)
#print(one_kid.candy)
# 10
#print(two_kid.candy)
# 20
#print(three_kid.candy)
# 100

a, b, x = Kid(10), Kid(20), Kid(100)
print("Kid.total_candy:", Kid.total_candy)
# Kid.total_candy: 130
a = a.candy
b = b.candy
x = x.candy
print("a:", a, "b:", b, "x:", x)
# a: 10 b: 20 x: 100
Kid.can_swap = False
print("Kid.can_swap:", Kid.can_swap)
# Kid.can_swap: False
Kid.can_swap = True
print("Kid.can_swap:", Kid.can_swap)
# Kid.can_swap: False
a1 = Kid(10)
a1_tmp = copy.deepcopy(a1)
b1 = Kid(20)
a1.swap(b1.candy)
b1.swap(a1_tmp.candy)
print("a1.candy:", a1.candy, "b1.candy:", b1.candy, 'x:', x)