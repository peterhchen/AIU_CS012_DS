"""
File: hw1.sp
Description: Homework 1
"""
def check_func (guess, secret, score):
    """
    Function name: check_func()
    Funciton Description:
     Project 1 Wordle
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
       score: The score of the game
    return:
       True if match: Game over
       False: Game not over
    """
    if score > 0:
        if guess == secret:
            return True
        #else:
        #    return False
    else:   # score <= 0
        return True
    return False

if __name__ == "__main__":
    # Test 1
    print ("joy, cal, 15: expteced false, result: False",  check_func ('joy', 'cal', 15))
    # Test 2
    print ("cal, cal, 15: expected true, result: true",  check_func ('cal', 'cal', 15))
    # Test 3
    print ("cal, joy, -2: expected true, result: true",  check_func ('cal', 'joy', -2))
    # Test 4
    print ("cal, joy, 0: expected true, result: true",  check_func ('cal', 'joy', 0))
    # Test 5
    print ("cal, cal, 0: expected true, results: true",  check_func ('cal', 'cal', 0))
