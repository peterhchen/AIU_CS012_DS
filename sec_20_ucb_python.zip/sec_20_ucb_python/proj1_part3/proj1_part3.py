"""
File: proj1_part3.sp
Description: proj1_part3
"""
def check_func2 (guess, secret):
    """
    Function name: check_func()
    Funciton Description:
     Project 1 Wordle
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
    return:
       ---
       -o-
    """
    chk_indices = []
    if guess.upper() == secret.upper():
        return secret, chk_indices
    if guess == "":
        chk_indices.append(0)
        chk_indices.append(1)
        chk_indices.append(2)
        return "---", chk_indices

    #print('check_func2: guess', guess)
    #print('check_func2: secret', secret)
    chk_indices = find_index (guess, secret)
    #print('check_func2: chk_indices:', chk_indices)
    chk_new_string = replace_position(secret, chk_indices, '-')
    return chk_new_string, chk_indices

def find_index(guess, secret):
    """
    Function name: find_index()
    Funciton Description:
     Project 2 Wordle
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
    return:
      indices
    """
    find_indices = []
    # for index in range(len(secret)):
    #print('find_index: guess', guess)
    #print('find_index: secret', secret)
    for index, _ in enumerate (secret):
        #print('index:', index)
        #print('secret[index]:', secret[index])
        #print('guess[index]:', guess[index])
        if index < len(guess):
            if secret[index] != guess[index]:
                find_indices.append(index)
        else: find_indices.append(index)

    print(find_indices)  # [1, 4]
    return find_indices

def replace_position(secret, rep_indices, new_character):
    """
    Function name: replace_position()
    Funciton Description: mreplace position
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
    return:
      indices
    """
    for position in rep_indices:
        secret = secret[:position] + new_character + secret[position+1:]
    print('replace_char_with_position:', secret)
    return secret

def calc_score(calc_new_string, calc_indices, calc_score1):
    """
    Function name: calc_score()
    Funciton Description: calculate score
    1. index of  minus
    2. count of num minus
    input parameters:
       new_string: input string (---, -oy, -0-, -0y, ...)
       score: orginal score
    return:
      new_score
    """
    count_minus_index = 0
    index_flag = False
    for _ in calc_indices:
        index_flag = True
        count_minus_index += 1
    if index_flag is True:
        calc_score1 = calc_score1 - 10
    num_non_minus = len(calc_new_string) - count_minus_index
    calc_score1 += num_non_minus
    new_calc_score = calc_score1
    return new_calc_score

if __name__ == "__main__":
    # Test 1
    print("Tes1 1:")
    #indices = []
    new_string, indices = check_func2("", 'joy')
    print ('"", joy: expteced result: --- (no macthes) => ',  new_string, indices)
    SCORE = 100
    new_score = calc_score(new_string, indices, SCORE)
    print('new_score: ', new_score)
    print()
    # Test 2
    print("Test 2:")
    #indices = []
    new_string, indices = check_func2 ('aoy', 'joy')
    print ("aoy, joy: expected result: -oy (no matches) => ",  new_string, indices)
    SCORE = 100
    new_score = calc_score(new_string, indices, SCORE)
    print('new_score: ', new_score)
    print()
    # Test 3
    print("Test 3:")
    #indices = []
    new_string, indices = check_func2 ('aob', 'joy')
    print ("aob, joy: expected result: j-y => ",  new_string, indices)
    SCORE = 100
    new_score = calc_score(new_string, indices, SCORE)
    print('new_score: ', new_score)
    print()
    # Test 4
    print("Test 4:")
    #indices = []
    new_string, indices = check_func2 ('aoy', 'joy')
    print ("aoy, joy: expected result: -o- => ", new_string, indices)
    SCORE = 1
    new_score = calc_score(new_string, indices, SCORE)
    print('new_score: ', new_score)
    print()
    # Test 5
    print("Test 5:")
    #indices = []
    new_string, indices = check_func2 ('abc', 'joy')
    print ("abc, joy: expected results: -oy => ", new_string, indices)
    SCORE = -47
    new_score = calc_score(new_string, indices, SCORE)
    print('new_score: ', new_score)
    print()
