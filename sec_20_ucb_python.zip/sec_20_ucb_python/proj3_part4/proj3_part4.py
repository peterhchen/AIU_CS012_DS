"""
The borad representation in 2048 is abtracted data type which
we can picture it as a table that looks like the 4x4 board.
Note:
1. The number in the board is power of 2 (e.g., 2, 4, 8, 16, etc., 
i.e., 2^1, 2^2, 2^3, 2^4, etc).
2. board can be any size, e.g., 3x3, 4x4, 5x5, etc.
Note:
1. new board size: construct n x n board.
2. board size: return n.
3. item (i, j): return value of [i, j]
4. set (i, j) to value: set board [i, j] = value
5. copy board: copy another copy of the board
6. empty (i, j): empty the position of (i, j)
7. rotate row (i, j): rotate board 90 clockwise and return row of (i, j).
8. rotate col (i, j): rotate board 90 clockwise and return column of (i, j).
9. display board: display the board at at time.

Part 1: Populating the Board
Add 2 or 4 to board.
1. Input: board
Input a 2048 game board with at least one empty space.
2. Ouput: a copy of board with an added value at random location.
Hint:
1. Check some exisitng blocks.
2. Keep the orginal board data.
3. Find where to insert the value in the board.
4. return the board with new data.
"""
import random

def new_board (n = 4):
    """
    new_board
    """
    mat =[]
    for i in range(n):
        mat.append([0] * n)
    return mat

def add_new_2_4(mat, n = 4):
    print ('add_new:')
    # choosing a random index for
    # row and column.
    empty_found = False
    for r in range (0, 4):
        for c in range(0, 4):
            if mat[r][c] == 0:
                empty_found = True
    if empty_found is False:
        print('board is full')
        return mat
    if empty_found is True:
        print('board has empty spaces')
        while (1):
            r = random.randint(0, n-1)
            c = random.randint(0, n-1)
            if  mat[r][c] == 0:
                if int(random.random() <= 0.75):
                    mat[r][c] = 2
                else:
                    mat[r][c] = 4
            break
    return mat

def rotate_row_col(mat):
    """
    Rotate the row and column 90 degree clockwise.
    """
    #print('mat:', mat)
    r_count = len(mat)
    c_count = len(mat[0])
    new_r_c_mat = [[0 for c in range(c_count)] for r in range(r_count)] 
    for r_n in range(0, r_count):
        for c_n in range(0, c_count):
            new_r_c_mat[c_n][r_n] = mat[r_n][c_n]
    #print('new_r_c_mat:', new_r_c_mat)
    return new_r_c_mat  

def merge_up_col(col_num, mat):
    """
    Merge the col_num to the rest of matrix.
    """
    r_count = len(mat)
    c_count = len(mat[0])
    new_merge_up_col = [[0 for c in range(c_count)] for r in range(r_count)] 

    for r_n in range(0, r_count):
        for c_n in range(col_num, c_count):
            new_merge_up_col[r_n][c_n] += mat[r_n][c_n]
    return new_merge_up_col  

def merge_up(mat):
    """
    Merge from column 0 to the rest of matrix.
    """
    new_merge_up = merge_up_col(0, mat)
    return new_merge_up

def no_move_left(mat):
    """
    Check for no move left.
    """
    n = len(mat) - 1
    for i in range(n):
        for j in range(n):
            if (mat [i][j] == 2048):
                print('You won')
                return True
    
    for i in range(n):
        for j in range(4):
            if (mat[i][j] == 0):
                print('1: Game is not over')
                return False
    
    for i in range(n):
        for j in range(n):
            if mat[i][j] == mat[i+1][j] or mat[i][j] == mat[i][j+1]:
                print ('mat[', i, '][', j, ']:', mat[i][j])
                print ('mat[', i, '][', j, ']:', mat[i][j])
                print('2: Game is not over')
                return False
    
    for j in range(n):
        if mat[n][j] == mat[n][j+1]:
            print('3: Game is not over')
            return False
    
    for i in range(n):
        if mat[i][n] == mat[i+1][n]:
            print('4: Game is not over')
            return False
    
    print('Game is lost')
    return True

# Driver code
if __name__ == '__main__':
    # default is n = 4 (4x4)
    mat = new_board()
    print('mat:'), mat
    mat_2_4 = add_new_2_4(mat)
    print ('mat_2_4:', mat_2_4)
    #rotate_mat = rotate_row_col(mat_2_4)
    #print('rotate_mat:', rotate_mat)

    col_num = 3
    new_merge_up_col = merge_up_col(col_num, mat_2_4)
    print ('new_merge_up_col:', new_merge_up_col)
    new_merge_up = merge_up(mat_2_4)
    print ('new_merge_up:', new_merge_up)

    test_mat = [[2, 8, 16, 2], [256, 32, 64, 4], [32, 8, 16, 8], [2, 512, 128, 32]] 
    print('test_mat:')
    print(test_mat)
    if no_move_left (test_mat) is True:
        print('no move left')