"""
File: hw2.sp
Description: Homework 1
"""
def check_func2 (guess, secret):
    """
    Function name: check_func()
    Funciton Description:
     Project 1 Wordle
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
    return:
       ---
       -o-
    """
    if guess.upper() == secret.upper():
        return secret
    if guess == "":
        return "---"

    #print('check_func2: guess', guess)
    #print('check_func2: secret', secret)
    indices = find_index (guess, secret)
    new_string = replace_position(secret, indices, '-')
    return new_string

def find_index(guess, secret):
    """
    Function name: find_index()
    Funciton Description:
     Project 2 Wordle
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
    return:
      indices
    """
    indices = []
    # for index in range(len(secret)):
    #print('find_index: guess', guess)
    #print('find_index: secret', secret)
    for index, _ in enumerate (secret):
        #print('index:', index)
        #print('secret[index]:', secret[index])
        #print('guess[index]:', guess[index])
        if index < len(guess):
            if secret[index] != guess[index]:
                indices.append(index)
        else: indices.append(index)

    print(indices)  # [1, 4]
    return indices

def replace_position(secret, indices, new_character):
    """
    Function name: replace_position()
    Funciton Description:
     Project 2 Wordle
    input parameters:
       guess: Input by player
       secrect: Intended Correct Answer
    return:
      indices
    """
    for position in indices:
        secret = secret[:position] + new_character + secret[position+1:]
    print('replace_char_with_position:', secret)
    return secret

if __name__ == "__main__":
    # Test 1
    print("Tes1 1:")
    print ('"", joy: expteced result: --- (no macthes) => ',  check_func2 ("", 'joy'))
    print()
    # Test 2
    print("Test 2:")
    print ("cal, joy: expected result: --- (no matches) => ",  check_func2 ('cal', 'joy'))
    print()
    # Test 3
    print("Test 3:")
    print ("jay, joy: expected result: j-y => ",  check_func2 ('jay', 'joy'))
    print()
    # Test 4
    print("Test 4:")
    print ("to, joy: expected result: -o- => ",  check_func2 ('to', 'joy'))
    print()
    # Test 5
    print("Test 5:")
    print ("soylent, joy: expected results: -oy => ",  check_func2 ('soylent', 'joy'))
    print()
