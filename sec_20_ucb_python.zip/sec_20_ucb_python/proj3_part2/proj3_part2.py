"""
The borad representation in 2048 is abtracted data type which
we can picture it as a table that looks like the 4x4 board.
Note:
1. The number in the board is power of 2 (e.g., 2, 4, 8, 16, etc., 
i.e., 2^1, 2^2, 2^3, 2^4, etc).
2. board can be any size, e.g., 3x3, 4x4, 5x5, etc.
Note:
1. new board size: construct n x n board.
2. board size: return n.
3. item (i, j): return value of [i, j]
4. set (i, j) to value: set board [i, j] = value
5. copy board: copy another copy of the board
6. empty (i, j): empty the position of (i, j)
7. rotate row (i, j): rotate board 90 clockwise and return row of (i, j).
8. rotate col (i, j): rotate board 90 clockwise and return column of (i, j).
9. display board: display the board at at time.

Part 1: Populating the Board
Add 2 or 4 to board.
1. Input: board
Input a 2048 game board with at least one empty space.
2. Ouput: a copy of board with an added value at random location.
Hint:
1. Check some exisitng blocks.
2. Keep the orginal board data.
3. Find where to insert the value in the board.
4. return the board with new data.
"""
import random

def new_board (n = 4):
    """
    new_board
    """
    mat =[]
    for i in range(n):
        mat.append([0] * n)
    return mat

def add_new_2_4(mat, n = 4):
    print ('add_new:')
    # choosing a random index for
    # row and column.
    empty_found = False
    for r in range (0, 4):
        for c in range(0, 4):
            if mat[r][c] == 0:
                empty_found = True
    if empty_found is False:
        print('board is full')
        return mat
    if empty_found is True:
        print('board has empty spaces')
        while (1):
            r = random.randint(0, n-1)
            c = random.randint(0, n-1)
            if  mat[r][c] == 0:
                if int(random.random() <= 0.75):
                    mat[r][c] = 2
                else:
                    mat[r][c] = 4
            break
    return mat

def rotate_row_col(mat):
    """
    Rotate the row and column 90 degree clockwise.
    """
    #print('mat:', mat)
    r_count = len(mat)
    c_count = len(mat[0])
    new_r_c_mat = [[0 for c in range(c_count)] for r in range(r_count)] 
    for r_n in range(0, r_count):
        for c_n in range(0, c_count):
            new_r_c_mat[c_n][r_n] = mat[r_n][c_n]
    #print('new_r_c_mat:', new_r_c_mat)
    return new_r_c_mat  


# Driver code
if __name__ == '__main__':
    # default is n = 4 (4x4)
    mat = new_board()
    print('mat:'), mat
    mat_2_4 = add_new_2_4(mat)
    print ('mat_2_4:', mat_2_4)
    rotate_mat = rotate_row_col(mat_2_4)
    print('rotate_mat:', rotate_mat)