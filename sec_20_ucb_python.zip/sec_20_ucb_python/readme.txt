quiz coing:
1. HOF (Higher-Order-Function)
2. unigram: string parsing with calculation
3. lambda: Recusrive, lambda, and HOF
4. kids: class variable, instance variable, and deep copy 
5. Nim game: children, mes, and Nim 
Game Project:
1. Project 1: Wordle 
2. Project 2: Pytromino
3. Project 3: 2048

