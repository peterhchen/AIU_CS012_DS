import tkinter
# import matplotlib.pyplot as plt

top = tkinter.Tk()

C = tkinter.Canvas(top, bg="blue", height=500, width=600)

coord = 10, 100, 240, 300
arc = C.create_arc(coord, start=0, extent=180, fill="red")

C.pack()
# plt.show()
top.mainloop()