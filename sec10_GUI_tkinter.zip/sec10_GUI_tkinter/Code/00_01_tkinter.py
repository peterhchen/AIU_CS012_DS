#!/usr/bin/python

import tkinter as tk
# top = tkinter.Tk()
top = tk.Tk()
# Code to add widgets will go here...
top.mainloop()