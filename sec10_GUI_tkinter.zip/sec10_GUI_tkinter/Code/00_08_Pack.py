from tkinter import *

root = Tk()
frame = Frame(root)
frame.pack()

bottomframe = Frame(root)
bottomframe.pack (side = BOTTOM )

redbutton = Button(frame, text="Red", fg="Red")
redbutton.pack (side = LEFT)

greenbutton = Button(frame, text="Green", fg="green")
greenbutton.pack (side = LEFT )

bluebutton = Button(frame, text="Blue", fg="blue")
bluebutton.pack (side = LEFT )

blackbutton = Button(bottomframe, text="Black", fg="black")
blackbutton.pack (side = BOTTOM)

root.mainloop()