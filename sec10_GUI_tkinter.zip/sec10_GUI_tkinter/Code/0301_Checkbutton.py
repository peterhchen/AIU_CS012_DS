from tkinter import *
import tkinter

def checkbutton1():
    print('click checkbutton 1')

def checkbutton2():
    print('click checkbutton 2')

top = tkinter.Tk()
CheckVar1 = IntVar()
CheckVar2 = IntVar()
C1 = Checkbutton(top, text = "Music", variable = CheckVar1, \
                 onvalue = 1, offvalue = 0, height=5, \
                 width = 20, command=checkbutton1)
C2 = Checkbutton(top, text = "Video", variable = CheckVar2, \
                 onvalue = 1, offvalue = 0, height=5, \
                 width = 20, command=checkbutton2)
C1.pack()
C2.pack()
top.mainloop()