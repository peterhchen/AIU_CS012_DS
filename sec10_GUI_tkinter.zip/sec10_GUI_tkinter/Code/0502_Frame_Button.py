# https://www.geeksforgeeks.org/python-tkinter-frame-widget/
import tkinter as tk

root = tk.Tk()
root.geometry("300x150")
  
w = tk.Label(root, text ='GeeksForGeeks', font = "50") 
w.pack()
  
frame = tk.Frame(root)
frame.pack()
  
bottomframe = tk.Frame(root)
bottomframe.pack( side = tk.BOTTOM )
  
b1_button = tk.Button(frame, text ="Geeks1", fg ="red")
b1_button.pack( side = tk.LEFT)
  
b2_button = tk.Button(frame, text ="Geeks2", fg ="brown")
b2_button.pack( side = tk.LEFT )
  
b3_button = tk.Button(frame, text ="Geeks3", fg ="blue")
b3_button.pack( side = tk.LEFT )
  
b4_button = tk.Button(bottomframe, text ="Geeks4", fg ="green")
b4_button.pack( side = tk.BOTTOM)
  
b5_button = tk.Button(bottomframe, text ="Geeks5", fg ="green")
b5_button.pack( side = tk.BOTTOM)

b6_button = tk.Button(bottomframe, text ="Geeks6", fg ="green")
b6_button.pack( side = tk.BOTTOM)
  
root.mainloop()